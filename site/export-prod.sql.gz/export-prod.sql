# WordPress MySQL database migration
#
# Generated: Thursday 22. September 2016 07:40 UTC
# Hostname: localhost
# Database: `cedreo-designer_com_production`
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Un commentateur WordPress', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2016-08-22 22:08:37', '2016-08-22 20:08:37', 'Bonjour, ceci est un commentaire.\nPour débuter avec la modération, la modification et la suppression de commentaires, veuillez visiter l’écran des Commentaires dans le Tableau de bord.\nLes avatars des personnes qui commentent arrivent depuis <a href="https://gravatar.com">Gravatar</a>.', 0, '1', '', '', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_nf_objectmeta`
#

DROP TABLE IF EXISTS `wp_nf_objectmeta`;


#
# Table structure of table `wp_nf_objectmeta`
#

CREATE TABLE `wp_nf_objectmeta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `object_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) NOT NULL,
  `meta_value` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_nf_objectmeta`
#
INSERT INTO `wp_nf_objectmeta` ( `id`, `object_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'date_updated', '2016-08-30'),
(2, 1, 'form_title', 'Contact Form'),
(3, 1, 'show_title', '0'),
(4, 1, 'save_subs', '1'),
(5, 1, 'logged_in', '0'),
(6, 1, 'append_page', '37'),
(7, 1, 'ajax', '0'),
(8, 1, 'clear_complete', '1'),
(9, 1, 'hide_complete', '1'),
(10, 1, 'success_msg', 'Your form has been successfully submitted.'),
(11, 1, 'email_from', ''),
(12, 1, 'email_type', 'html'),
(13, 1, 'user_email_msg', 'Thank you so much for contacting us. We will get back to you shortly.'),
(14, 1, 'user_email_fields', '0'),
(15, 1, 'admin_email_msg', ''),
(16, 1, 'admin_email_fields', '1'),
(17, 1, 'admin_attach_csv', '0'),
(18, 1, 'email_from_name', ''),
(19, 2, 'date_updated', '2014-09-09'),
(20, 2, 'active', '1'),
(21, 2, 'name', 'Email User'),
(22, 2, 'type', 'email'),
(23, 2, 'email_format', 'html'),
(24, 2, 'attach_csv', '1'),
(25, 2, 'from_name', ''),
(26, 2, 'from_address', ''),
(27, 2, 'reply_to', ''),
(28, 2, 'to', 'field_2'),
(29, 2, 'cc', ''),
(30, 2, 'bcc', ''),
(31, 2, 'email_subject', 'Thank you for contacting us!'),
(32, 2, 'email_message', 'Thank you so much for contacting us. We will get back to you shortly.'),
(33, 2, 'redirect_url', ''),
(34, 2, 'success_message_loc', 'ninja_forms_display_before_fields'),
(35, 2, 'success_msg', ''),
(36, 3, 'date_updated', '2014-09-09'),
(37, 3, 'active', '1'),
(38, 3, 'name', 'Success Message'),
(39, 3, 'type', 'success_message'),
(40, 3, 'email_format', 'html'),
(41, 3, 'attach_csv', '0'),
(42, 3, 'from_name', ''),
(43, 3, 'from_address', ''),
(44, 3, 'reply_to', ''),
(45, 3, 'to', ''),
(46, 3, 'cc', ''),
(47, 3, 'bcc', ''),
(48, 3, 'email_subject', ''),
(49, 3, 'email_message', ''),
(50, 3, 'redirect_url', ''),
(51, 3, 'success_message_loc', 'ninja_forms_display_after_fields'),
(52, 3, 'success_msg', 'Your form has been successfully submitted.'),
(53, 3, 'text_message_number', ''),
(54, 3, 'text_message_carrier', '0'),
(55, 3, 'text_message_message', ''),
(56, 4, 'date_updated', '2014-09-09'),
(57, 4, 'active', '1'),
(58, 4, 'name', 'Email Admin'),
(59, 4, 'type', 'email'),
(60, 4, 'email_format', 'html'),
(61, 4, 'attach_csv', '1'),
(62, 4, 'from_name', ''),
(63, 4, 'from_address', ''),
(64, 4, 'reply_to', 'field_2'),
(65, 4, 'to', 'wab2com@gmail.com'),
(66, 4, 'cc', ''),
(67, 4, 'bcc', ''),
(68, 4, 'email_subject', 'Ninja Form Submission'),
(69, 4, 'email_message', '[ninja_forms_all_fields]'),
(70, 4, 'redirect_url', ''),
(71, 4, 'success_message_loc', 'ninja_forms_display_before_fields'),
(72, 4, 'success_msg', ''),
(73, 4, 'text_message_number', ''),
(74, 4, 'text_message_carrier', '0'),
(75, 4, 'text_message_message', ''),
(76, 1, 'not_logged_in_msg', ''),
(77, 1, 'sub_limit_number', ''),
(78, 1, 'sub_limit_msg', ''),
(79, 1, 'last_sub', '3') ;

#
# End of data contents of table `wp_nf_objectmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_nf_objects`
#

DROP TABLE IF EXISTS `wp_nf_objects`;


#
# Table structure of table `wp_nf_objects`
#

CREATE TABLE `wp_nf_objects` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_nf_objects`
#
INSERT INTO `wp_nf_objects` ( `id`, `type`) VALUES
(1, 'form'),
(2, 'notification'),
(3, 'notification'),
(4, 'notification') ;

#
# End of data contents of table `wp_nf_objects`
# --------------------------------------------------------



#
# Delete any existing table `wp_nf_relationships`
#

DROP TABLE IF EXISTS `wp_nf_relationships`;


#
# Table structure of table `wp_nf_relationships`
#

CREATE TABLE `wp_nf_relationships` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `child_id` bigint(20) NOT NULL,
  `parent_id` bigint(20) NOT NULL,
  `child_type` varchar(255) NOT NULL,
  `parent_type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_nf_relationships`
#
INSERT INTO `wp_nf_relationships` ( `id`, `child_id`, `parent_id`, `child_type`, `parent_type`) VALUES
(1, 2, 1, 'notification', 'form'),
(2, 3, 1, 'notification', 'form'),
(3, 4, 1, 'notification', 'form') ;

#
# End of data contents of table `wp_nf_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_ninja_forms_fav_fields`
#

DROP TABLE IF EXISTS `wp_ninja_forms_fav_fields`;


#
# Table structure of table `wp_ninja_forms_fav_fields`
#

CREATE TABLE `wp_ninja_forms_fav_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `row_type` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `order` int(11) NOT NULL,
  `data` longtext NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_ninja_forms_fav_fields`
#
INSERT INTO `wp_ninja_forms_fav_fields` ( `id`, `row_type`, `type`, `order`, `data`, `name`) VALUES
(2, 0, '_list', 0, 'a:10:{s:5:"label";s:14:"State Dropdown";s:9:"label_pos";s:4:"left";s:9:"list_type";s:8:"dropdown";s:10:"multi_size";s:1:"5";s:15:"list_show_value";s:1:"1";s:4:"list";a:1:{s:7:"options";a:51:{i:0;a:3:{s:5:"label";s:7:"Alabama";s:5:"value";s:2:"AL";s:8:"selected";s:1:"0";}i:1;a:3:{s:5:"label";s:6:"Alaska";s:5:"value";s:2:"AK";s:8:"selected";s:1:"0";}i:2;a:3:{s:5:"label";s:7:"Arizona";s:5:"value";s:2:"AZ";s:8:"selected";s:1:"0";}i:3;a:3:{s:5:"label";s:8:"Arkansas";s:5:"value";s:2:"AR";s:8:"selected";s:1:"0";}i:4;a:3:{s:5:"label";s:10:"California";s:5:"value";s:2:"CA";s:8:"selected";s:1:"0";}i:5;a:3:{s:5:"label";s:8:"Colorado";s:5:"value";s:2:"CO";s:8:"selected";s:1:"0";}i:6;a:3:{s:5:"label";s:11:"Connecticut";s:5:"value";s:2:"CT";s:8:"selected";s:1:"0";}i:7;a:3:{s:5:"label";s:8:"Delaware";s:5:"value";s:2:"DE";s:8:"selected";s:1:"0";}i:8;a:3:{s:5:"label";s:20:"District of Columbia";s:5:"value";s:2:"DC";s:8:"selected";s:1:"0";}i:9;a:3:{s:5:"label";s:7:"Florida";s:5:"value";s:2:"FL";s:8:"selected";s:1:"0";}i:10;a:3:{s:5:"label";s:7:"Georgia";s:5:"value";s:2:"GA";s:8:"selected";s:1:"0";}i:11;a:3:{s:5:"label";s:6:"Hawaii";s:5:"value";s:2:"HI";s:8:"selected";s:1:"0";}i:12;a:3:{s:5:"label";s:5:"Idaho";s:5:"value";s:2:"ID";s:8:"selected";s:1:"0";}i:13;a:3:{s:5:"label";s:8:"Illinois";s:5:"value";s:2:"IL";s:8:"selected";s:1:"0";}i:14;a:3:{s:5:"label";s:7:"Indiana";s:5:"value";s:2:"IN";s:8:"selected";s:1:"0";}i:15;a:3:{s:5:"label";s:4:"Iowa";s:5:"value";s:2:"IA";s:8:"selected";s:1:"0";}i:16;a:3:{s:5:"label";s:6:"Kansas";s:5:"value";s:2:"KS";s:8:"selected";s:1:"0";}i:17;a:3:{s:5:"label";s:8:"Kentucky";s:5:"value";s:2:"KY";s:8:"selected";s:1:"0";}i:18;a:3:{s:5:"label";s:9:"Louisiana";s:5:"value";s:2:"LA";s:8:"selected";s:1:"0";}i:19;a:3:{s:5:"label";s:5:"Maine";s:5:"value";s:2:"ME";s:8:"selected";s:1:"0";}i:20;a:3:{s:5:"label";s:8:"Maryland";s:5:"value";s:2:"MD";s:8:"selected";s:1:"0";}i:21;a:3:{s:5:"label";s:13:"Massachusetts";s:5:"value";s:2:"MA";s:8:"selected";s:1:"0";}i:22;a:3:{s:5:"label";s:8:"Michigan";s:5:"value";s:2:"MI";s:8:"selected";s:1:"0";}i:23;a:3:{s:5:"label";s:9:"Minnesota";s:5:"value";s:2:"MN";s:8:"selected";s:1:"0";}i:24;a:3:{s:5:"label";s:11:"Mississippi";s:5:"value";s:2:"MS";s:8:"selected";s:1:"0";}i:25;a:3:{s:5:"label";s:8:"Missouri";s:5:"value";s:2:"MO";s:8:"selected";s:1:"0";}i:26;a:3:{s:5:"label";s:7:"Montana";s:5:"value";s:2:"MT";s:8:"selected";s:1:"0";}i:27;a:3:{s:5:"label";s:8:"Nebraska";s:5:"value";s:2:"NE";s:8:"selected";s:1:"0";}i:28;a:3:{s:5:"label";s:6:"Nevada";s:5:"value";s:2:"NV";s:8:"selected";s:1:"0";}i:29;a:3:{s:5:"label";s:13:"New Hampshire";s:5:"value";s:2:"NH";s:8:"selected";s:1:"0";}i:30;a:3:{s:5:"label";s:10:"New Jersey";s:5:"value";s:2:"NJ";s:8:"selected";s:1:"0";}i:31;a:3:{s:5:"label";s:10:"New Mexico";s:5:"value";s:2:"NM";s:8:"selected";s:1:"0";}i:32;a:3:{s:5:"label";s:8:"New York";s:5:"value";s:2:"NY";s:8:"selected";s:1:"0";}i:33;a:3:{s:5:"label";s:14:"North Carolina";s:5:"value";s:2:"NC";s:8:"selected";s:1:"0";}i:34;a:3:{s:5:"label";s:12:"North Dakota";s:5:"value";s:2:"ND";s:8:"selected";s:1:"0";}i:35;a:3:{s:5:"label";s:4:"Ohio";s:5:"value";s:2:"OH";s:8:"selected";s:1:"0";}i:36;a:3:{s:5:"label";s:8:"Oklahoma";s:5:"value";s:2:"OK";s:8:"selected";s:1:"0";}i:37;a:3:{s:5:"label";s:6:"Oregon";s:5:"value";s:2:"OR";s:8:"selected";s:1:"0";}i:38;a:3:{s:5:"label";s:12:"Pennsylvania";s:5:"value";s:2:"PA";s:8:"selected";s:1:"0";}i:39;a:3:{s:5:"label";s:12:"Rhode Island";s:5:"value";s:2:"RI";s:8:"selected";s:1:"0";}i:40;a:3:{s:5:"label";s:14:"South Carolina";s:5:"value";s:2:"SC";s:8:"selected";s:1:"0";}i:41;a:3:{s:5:"label";s:12:"South Dakota";s:5:"value";s:2:"SD";s:8:"selected";s:1:"0";}i:42;a:3:{s:5:"label";s:9:"Tennessee";s:5:"value";s:2:"TN";s:8:"selected";s:1:"0";}i:43;a:3:{s:5:"label";s:5:"Texas";s:5:"value";s:2:"TX";s:8:"selected";s:1:"0";}i:44;a:3:{s:5:"label";s:4:"Utah";s:5:"value";s:2:"UT";s:8:"selected";s:1:"0";}i:45;a:3:{s:5:"label";s:7:"Vermont";s:5:"value";s:2:"VT";s:8:"selected";s:1:"0";}i:46;a:3:{s:5:"label";s:8:"Virginia";s:5:"value";s:2:"VA";s:8:"selected";s:1:"0";}i:47;a:3:{s:5:"label";s:10:"Washington";s:5:"value";s:2:"WA";s:8:"selected";s:1:"0";}i:48;a:3:{s:5:"label";s:13:"West Virginia";s:5:"value";s:2:"WV";s:8:"selected";s:1:"0";}i:49;a:3:{s:5:"label";s:9:"Wisconsin";s:5:"value";s:2:"WI";s:8:"selected";s:1:"0";}i:50;a:3:{s:5:"label";s:7:"Wyoming";s:5:"value";s:2:"WY";s:8:"selected";s:1:"0";}}}s:3:"req";s:1:"0";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";}', 'State Dropdown'),
(3, 0, '_spam', 0, 'a:6:{s:9:"label_pos";s:4:"left";s:5:"label";s:18:"Anti-Spam Question";s:6:"answer";s:16:"Anti-Spam Answer";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";}', 'Anti-Spam'),
(4, 0, '_submit', 0, 'a:4:{s:5:"label";s:6:"Submit";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";}', 'Submit'),
(5, 0, '_tax', 0, 'a:11:{s:5:"label";s:3:"Tax";s:9:"label_pos";s:5:"above";s:13:"default_value";s:0:"";s:19:"payment_field_group";s:1:"1";s:11:"payment_tax";s:1:"1";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:11:"conditional";s:0:"";s:11:"calc_option";s:1:"0";s:4:"calc";s:0:"";}', 'Tax'),
(6, 0, '_text', 0, 'a:19:{s:5:"label";s:10:"First Name";s:9:"label_pos";s:5:"above";s:13:"default_value";s:0:"";s:4:"mask";s:0:"";s:10:"datepicker";s:1:"0";s:5:"email";s:1:"0";s:10:"send_email";s:1:"0";s:10:"from_email";s:1:"0";s:10:"first_name";s:1:"1";s:9:"last_name";s:1:"0";s:9:"from_name";s:1:"0";s:21:"user_info_field_group";s:1:"1";s:3:"req";s:1:"0";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:17:"calc_auto_include";s:1:"0";s:11:"calc_option";s:1:"0";s:11:"conditional";s:0:"";}', 'First Name'),
(7, 0, '_text', 0, 'a:19:{s:5:"label";s:9:"Last Name";s:9:"label_pos";s:5:"above";s:13:"default_value";s:0:"";s:4:"mask";s:0:"";s:10:"datepicker";s:1:"0";s:5:"email";s:1:"0";s:10:"send_email";s:1:"0";s:10:"from_email";s:1:"0";s:10:"first_name";s:1:"0";s:9:"last_name";s:1:"1";s:9:"from_name";s:1:"0";s:21:"user_info_field_group";s:1:"1";s:3:"req";s:1:"0";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:17:"calc_auto_include";s:1:"0";s:11:"calc_option";s:1:"0";s:11:"conditional";s:0:"";}', 'Last Name'),
(8, 0, '_text', 0, 'a:23:{s:5:"label";s:9:"Address 1";s:9:"label_pos";s:5:"above";s:13:"default_value";s:0:"";s:4:"mask";s:0:"";s:10:"datepicker";s:1:"0";s:5:"email";s:1:"0";s:10:"send_email";s:1:"0";s:10:"from_email";s:1:"0";s:10:"first_name";s:1:"0";s:9:"last_name";s:1:"0";s:9:"from_name";s:1:"0";s:14:"user_address_1";s:1:"1";s:14:"user_address_2";s:1:"0";s:9:"user_city";s:1:"0";s:8:"user_zip";s:1:"0";s:21:"user_info_field_group";s:1:"1";s:3:"req";s:1:"0";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:17:"calc_auto_include";s:1:"0";s:11:"calc_option";s:1:"0";s:11:"conditional";s:0:"";}', 'Address 1'),
(9, 0, '_text', 0, 'a:23:{s:5:"label";s:9:"Address 2";s:9:"label_pos";s:5:"above";s:13:"default_value";s:0:"";s:4:"mask";s:0:"";s:10:"datepicker";s:1:"0";s:5:"email";s:1:"0";s:10:"send_email";s:1:"0";s:10:"from_email";s:1:"0";s:10:"first_name";s:1:"0";s:9:"last_name";s:1:"0";s:9:"from_name";s:1:"0";s:14:"user_address_1";s:1:"0";s:14:"user_address_2";s:1:"1";s:9:"user_city";s:1:"0";s:8:"user_zip";s:1:"0";s:21:"user_info_field_group";s:1:"1";s:3:"req";s:1:"0";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:17:"calc_auto_include";s:1:"0";s:11:"calc_option";s:1:"0";s:11:"conditional";s:0:"";}', 'Address 2'),
(10, 0, '_text', 0, 'a:23:{s:5:"label";s:4:"City";s:9:"label_pos";s:5:"above";s:13:"default_value";s:0:"";s:4:"mask";s:0:"";s:10:"datepicker";s:1:"0";s:5:"email";s:1:"0";s:10:"send_email";s:1:"0";s:10:"from_email";s:1:"0";s:10:"first_name";s:1:"0";s:9:"last_name";s:1:"0";s:9:"from_name";s:1:"0";s:14:"user_address_1";s:1:"0";s:14:"user_address_2";s:1:"0";s:9:"user_city";s:1:"1";s:8:"user_zip";s:1:"0";s:21:"user_info_field_group";s:1:"1";s:3:"req";s:1:"0";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:17:"calc_auto_include";s:1:"0";s:11:"calc_option";s:1:"0";s:11:"conditional";s:0:"";}', 'City'),
(11, 0, '_list', 0, 'a:16:{s:5:"label";s:5:"State";s:9:"label_pos";s:5:"above";s:10:"multi_size";s:1:"5";s:15:"list_show_value";s:1:"1";s:4:"list";a:1:{s:7:"options";a:51:{i:0;a:4:{s:5:"label";s:7:"Alabama";s:5:"value";s:2:"AL";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:1;a:4:{s:5:"label";s:6:"Alaska";s:5:"value";s:2:"AK";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:2;a:4:{s:5:"label";s:7:"Arizona";s:5:"value";s:2:"AZ";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:3;a:4:{s:5:"label";s:8:"Arkansas";s:5:"value";s:2:"AR";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:4;a:4:{s:5:"label";s:10:"California";s:5:"value";s:2:"CA";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:5;a:4:{s:5:"label";s:8:"Colorado";s:5:"value";s:2:"CO";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:6;a:4:{s:5:"label";s:11:"Connecticut";s:5:"value";s:2:"CT";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:7;a:4:{s:5:"label";s:8:"Delaware";s:5:"value";s:2:"DE";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:8;a:4:{s:5:"label";s:20:"District of Columbia";s:5:"value";s:2:"DC";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:9;a:4:{s:5:"label";s:7:"Florida";s:5:"value";s:2:"FL";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:10;a:4:{s:5:"label";s:7:"Georgia";s:5:"value";s:2:"GA";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:11;a:4:{s:5:"label";s:6:"Hawaii";s:5:"value";s:2:"HI";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:12;a:4:{s:5:"label";s:5:"Idaho";s:5:"value";s:2:"ID";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:13;a:4:{s:5:"label";s:8:"Illinois";s:5:"value";s:2:"IL";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:14;a:4:{s:5:"label";s:7:"Indiana";s:5:"value";s:2:"IN";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:15;a:4:{s:5:"label";s:4:"Iowa";s:5:"value";s:2:"IA";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:16;a:4:{s:5:"label";s:6:"Kansas";s:5:"value";s:2:"KS";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:17;a:4:{s:5:"label";s:8:"Kentucky";s:5:"value";s:2:"KY";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:18;a:4:{s:5:"label";s:9:"Louisiana";s:5:"value";s:2:"LA";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:19;a:4:{s:5:"label";s:5:"Maine";s:5:"value";s:2:"ME";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:20;a:4:{s:5:"label";s:8:"Maryland";s:5:"value";s:2:"MD";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:21;a:4:{s:5:"label";s:13:"Massachusetts";s:5:"value";s:2:"MA";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:22;a:4:{s:5:"label";s:8:"Michigan";s:5:"value";s:2:"MI";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:23;a:4:{s:5:"label";s:9:"Minnesota";s:5:"value";s:2:"MN";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:24;a:4:{s:5:"label";s:11:"Mississippi";s:5:"value";s:2:"MS";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:25;a:4:{s:5:"label";s:8:"Missouri";s:5:"value";s:2:"MO";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:26;a:4:{s:5:"label";s:7:"Montana";s:5:"value";s:2:"MT";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:27;a:4:{s:5:"label";s:8:"Nebraska";s:5:"value";s:2:"NE";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:28;a:4:{s:5:"label";s:6:"Nevada";s:5:"value";s:2:"NV";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:29;a:4:{s:5:"label";s:13:"New Hampshire";s:5:"value";s:2:"NH";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:30;a:4:{s:5:"label";s:10:"New Jersey";s:5:"value";s:2:"NJ";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:31;a:4:{s:5:"label";s:10:"New Mexico";s:5:"value";s:2:"NM";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:32;a:4:{s:5:"label";s:8:"New York";s:5:"value";s:2:"NY";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:33;a:4:{s:5:"label";s:14:"North Carolina";s:5:"value";s:2:"NC";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:34;a:4:{s:5:"label";s:12:"North Dakota";s:5:"value";s:2:"ND";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:35;a:4:{s:5:"label";s:4:"Ohio";s:5:"value";s:2:"OH";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:36;a:4:{s:5:"label";s:8:"Oklahoma";s:5:"value";s:2:"OK";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:37;a:4:{s:5:"label";s:6:"Oregon";s:5:"value";s:2:"OR";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:38;a:4:{s:5:"label";s:12:"Pennsylvania";s:5:"value";s:2:"PA";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:39;a:4:{s:5:"label";s:12:"Rhode Island";s:5:"value";s:2:"RI";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:40;a:4:{s:5:"label";s:14:"South Carolina";s:5:"value";s:2:"SC";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:41;a:4:{s:5:"label";s:12:"South Dakota";s:5:"value";s:2:"SD";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:42;a:4:{s:5:"label";s:9:"Tennessee";s:5:"value";s:2:"TN";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:43;a:4:{s:5:"label";s:5:"Texas";s:5:"value";s:2:"TX";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:44;a:4:{s:5:"label";s:4:"Utah";s:5:"value";s:2:"UT";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:45;a:4:{s:5:"label";s:7:"Vermont";s:5:"value";s:2:"VT";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:46;a:4:{s:5:"label";s:8:"Virginia";s:5:"value";s:2:"VA";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:47;a:4:{s:5:"label";s:10:"Washington";s:5:"value";s:2:"WA";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:48;a:4:{s:5:"label";s:13:"West Virginia";s:5:"value";s:2:"WV";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:49;a:4:{s:5:"label";s:9:"Wisconsin";s:5:"value";s:2:"WI";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:50;a:4:{s:5:"label";s:7:"Wyoming";s:5:"value";s:2:"WY";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}}}s:9:"list_type";s:8:"dropdown";s:10:"user_state";s:1:"1";s:21:"user_info_field_group";s:1:"1";s:13:"populate_term";s:0:"";s:3:"req";s:1:"0";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:17:"calc_auto_include";s:1:"0";s:11:"calc_option";s:1:"0";s:11:"conditional";s:0:"";}', 'State'),
(12, 0, '_text', 0, 'a:23:{s:5:"label";s:15:"Zip / Post Code";s:9:"label_pos";s:5:"above";s:13:"default_value";s:0:"";s:4:"mask";s:0:"";s:10:"datepicker";s:1:"0";s:5:"email";s:1:"0";s:10:"send_email";s:1:"0";s:10:"from_email";s:1:"0";s:10:"first_name";s:1:"0";s:9:"last_name";s:1:"0";s:9:"from_name";s:1:"0";s:14:"user_address_1";s:1:"0";s:14:"user_address_2";s:1:"0";s:9:"user_city";s:1:"0";s:8:"user_zip";s:1:"1";s:21:"user_info_field_group";s:1:"1";s:3:"req";s:1:"0";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:17:"calc_auto_include";s:1:"0";s:11:"calc_option";s:1:"0";s:11:"conditional";s:0:"";}', 'Zip / Post Code'),
(13, 0, '_country', 0, 'a:10:{s:5:"label";s:7:"Country";s:9:"label_pos";s:5:"above";s:13:"default_value";s:2:"US";s:21:"user_info_field_group";s:1:"1";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:17:"calc_auto_include";s:1:"0";s:11:"calc_option";s:1:"0";s:11:"conditional";s:0:"";}', 'Country'),
(14, 0, '_text', 0, 'a:25:{s:5:"label";s:5:"Email";s:9:"label_pos";s:5:"above";s:13:"default_value";s:0:"";s:4:"mask";s:0:"";s:10:"datepicker";s:1:"0";s:5:"email";s:1:"1";s:10:"send_email";s:1:"0";s:10:"from_email";s:1:"0";s:10:"first_name";s:1:"0";s:9:"last_name";s:1:"0";s:9:"from_name";s:1:"0";s:14:"user_address_1";s:1:"0";s:14:"user_address_2";s:1:"0";s:9:"user_city";s:1:"0";s:8:"user_zip";s:1:"0";s:10:"user_phone";s:1:"0";s:10:"user_email";s:1:"1";s:21:"user_info_field_group";s:1:"1";s:3:"req";s:1:"0";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:17:"calc_auto_include";s:1:"0";s:11:"calc_option";s:1:"0";s:11:"conditional";s:0:"";}', 'Email'),
(15, 0, '_text', 0, 'a:25:{s:5:"label";s:5:"Phone";s:9:"label_pos";s:5:"above";s:13:"default_value";s:0:"";s:4:"mask";s:14:"(999) 999-9999";s:10:"datepicker";s:1:"0";s:5:"email";s:1:"0";s:10:"send_email";s:1:"0";s:10:"from_email";s:1:"0";s:10:"first_name";s:1:"0";s:9:"last_name";s:1:"0";s:9:"from_name";s:1:"0";s:14:"user_address_1";s:1:"0";s:14:"user_address_2";s:1:"0";s:9:"user_city";s:1:"0";s:8:"user_zip";s:1:"0";s:10:"user_phone";s:1:"1";s:10:"user_email";s:1:"0";s:21:"user_info_field_group";s:1:"1";s:3:"req";s:1:"0";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:17:"calc_auto_include";s:1:"0";s:11:"calc_option";s:1:"0";s:11:"conditional";s:0:"";}', 'Phone'),
(16, 0, '_calc', 0, 'a:20:{s:9:"calc_name";s:9:"sub_total";s:13:"default_value";s:0:"";s:17:"calc_display_type";s:4:"text";s:5:"label";s:9:"Sub Total";s:9:"label_pos";s:5:"above";s:26:"calc_display_text_disabled";s:1:"1";s:17:"calc_display_html";s:26:"<p>[ninja_forms_calc]</p>\n";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:11:"calc_method";s:4:"auto";s:4:"calc";s:0:"";s:7:"calc_eq";s:0:"";s:19:"payment_field_group";s:1:"1";s:13:"payment_total";s:1:"0";s:17:"payment_sub_total";s:1:"1";s:11:"calc_places";s:1:"2";s:17:"calc_auto_include";s:1:"0";s:11:"calc_option";s:1:"0";s:11:"conditional";s:0:"";}', 'Sub Total'),
(17, 0, '_calc', 0, 'a:20:{s:9:"calc_name";s:5:"total";s:13:"default_value";s:0:"";s:17:"calc_display_type";s:4:"text";s:5:"label";s:5:"Total";s:9:"label_pos";s:5:"above";s:26:"calc_display_text_disabled";s:1:"1";s:17:"calc_display_html";s:26:"<p>[ninja_forms_calc]</p>\n";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:11:"calc_method";s:4:"auto";s:4:"calc";a:5:{i:0;a:2:{s:2:"op";s:3:"add";s:5:"field";s:2:"70";}i:1;a:2:{s:2:"op";s:3:"add";s:5:"field";s:2:"69";}i:2;a:2:{s:2:"op";s:3:"add";s:5:"field";s:2:"15";}i:3;a:2:{s:2:"op";s:3:"add";s:5:"field";s:2:"61";}i:4;a:2:{s:2:"op";s:3:"add";s:5:"field";s:2:"70";}}s:7:"calc_eq";s:5:"5 + 5";s:19:"payment_field_group";s:1:"1";s:13:"payment_total";s:1:"1";s:17:"payment_sub_total";s:1:"0";s:11:"calc_places";s:1:"2";s:17:"calc_auto_include";s:1:"0";s:11:"calc_option";s:1:"0";s:11:"conditional";s:0:"";}', 'Total'),
(92, 0, '_credit_card', 0, 'a:6:{s:5:"label";s:11:"Credit Card";s:19:"payment_field_group";s:1:"1";s:3:"req";s:1:"0";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:11:"conditional";s:0:"";}', 'Credit Card') ;

#
# End of data contents of table `wp_ninja_forms_fav_fields`
# --------------------------------------------------------



#
# Delete any existing table `wp_ninja_forms_fields`
#

DROP TABLE IF EXISTS `wp_ninja_forms_fields`;


#
# Table structure of table `wp_ninja_forms_fields`
#

CREATE TABLE `wp_ninja_forms_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `order` int(11) NOT NULL,
  `data` longtext NOT NULL,
  `fav_id` int(11) DEFAULT NULL,
  `def_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_ninja_forms_fields`
#
INSERT INTO `wp_ninja_forms_fields` ( `id`, `form_id`, `type`, `order`, `data`, `fav_id`, `def_id`) VALUES
(1, 1, '_text', 0, 'a:24:{s:5:"label";s:4:"Name";s:9:"label_pos";s:5:"above";s:13:"default_value";s:0:"";s:4:"mask";s:0:"";s:10:"datepicker";s:1:"0";s:5:"email";s:1:"0";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:9:"from_name";s:1:"0";s:14:"user_address_1";s:0:"";s:14:"user_address_2";s:0:"";s:9:"user_city";s:0:"";s:8:"user_zip";s:0:"";s:10:"user_phone";s:0:"";s:10:"user_email";s:0:"";s:21:"user_info_field_group";s:0:"";s:3:"req";s:1:"1";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:9:"show_desc";s:1:"0";s:8:"desc_pos";s:4:"none";s:9:"desc_text";s:0:"";s:17:"calc_auto_include";s:1:"0";}', 0, 0),
(2, 1, '_text', 1, 'a:28:{s:5:"label";s:5:"Email";s:9:"label_pos";s:5:"above";s:13:"default_value";s:0:"";s:4:"mask";s:0:"";s:10:"datepicker";s:1:"0";s:5:"email";s:1:"1";s:10:"first_name";s:1:"0";s:9:"last_name";s:1:"0";s:9:"from_name";s:1:"0";s:14:"user_address_1";s:1:"0";s:14:"user_address_2";s:1:"0";s:9:"user_city";s:1:"0";s:8:"user_zip";s:1:"0";s:10:"user_phone";s:1:"0";s:10:"user_email";s:1:"1";s:21:"user_info_field_group";s:1:"1";s:3:"req";s:1:"1";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:17:"calc_auto_include";s:1:"0";s:11:"calc_option";s:1:"0";s:11:"conditional";s:0:"";s:26:"user_info_field_group_name";s:0:"";s:28:"user_info_field_group_custom";s:0:"";s:9:"show_desc";s:1:"0";s:8:"desc_pos";s:4:"none";s:9:"desc_text";s:0:"";}', 0, 14),
(3, 1, '_textarea', 2, 'a:14:{s:5:"label";s:7:"Message";s:9:"label_pos";s:5:"above";s:13:"default_value";s:0:"";s:12:"textarea_rte";s:1:"0";s:14:"textarea_media";s:1:"0";s:18:"disable_rte_mobile";s:1:"0";s:3:"req";s:1:"1";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:9:"show_desc";s:1:"0";s:8:"desc_pos";s:4:"none";s:9:"desc_text";s:0:"";s:17:"calc_auto_include";s:1:"0";}', 0, 0),
(4, 1, '_submit', 4, 'a:7:{s:5:"label";s:4:"Send";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:9:"show_desc";s:1:"0";s:8:"desc_pos";s:4:"none";s:9:"desc_text";s:0:"";}', 0, 0) ;

#
# End of data contents of table `wp_ninja_forms_fields`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=1717 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(3, 'siteurl', 'http://cedreo-designer.com.dev/wp', 'yes'),
(4, 'home', 'http://cedreo-designer.com.dev/wp', 'yes'),
(5, 'blogname', 'Cedreo Designer', 'yes'),
(6, 'blogdescription', 'Logiciel plan 3D maison', 'yes'),
(7, 'users_can_register', '0', 'yes'),
(8, 'admin_email', 'wab2com@gmail.com', 'yes'),
(9, 'start_of_week', '1', 'yes'),
(10, 'use_balanceTags', '0', 'yes'),
(11, 'use_smilies', '1', 'yes'),
(12, 'require_name_email', '1', 'yes'),
(13, 'comments_notify', '1', 'yes'),
(14, 'posts_per_rss', '10', 'yes'),
(15, 'rss_use_excerpt', '0', 'yes'),
(16, 'mailserver_url', 'mail.example.com', 'yes'),
(17, 'mailserver_login', 'login@example.com', 'yes'),
(18, 'mailserver_pass', 'password', 'yes'),
(19, 'mailserver_port', '110', 'yes'),
(20, 'default_category', '8', 'yes'),
(21, 'default_comment_status', 'open', 'yes'),
(22, 'default_ping_status', 'open', 'yes'),
(23, 'default_pingback_flag', '1', 'yes'),
(24, 'posts_per_page', '10', 'yes'),
(25, 'date_format', 'j m', 'yes'),
(26, 'time_format', 'G \\h i \\m\\i\\n', 'yes'),
(27, 'links_updated_date_format', 'j F Y G \\h i \\m\\i\\n', 'yes'),
(28, 'comment_moderation', '0', 'yes'),
(29, 'moderation_notify', '1', 'yes'),
(30, 'permalink_structure', '/%postname%/', 'yes'),
(32, 'hack_file', '0', 'yes'),
(33, 'blog_charset', 'UTF-8', 'yes'),
(34, 'moderation_keys', '', 'no'),
(35, 'active_plugins', 'a:13:{i:0;s:21:"polylang/polylang.php";i:1;s:69:"acf-content-analysis-for-yoast-seo/yoast-seo-acf-content-analysis.php";i:2;s:27:"acf-gallery/acf-gallery.php";i:3;s:29:"acf-repeater/acf-repeater.php";i:4;s:30:"advanced-custom-fields/acf.php";i:5;s:37:"breadcrumb-navxt/breadcrumb-navxt.php";i:6;s:36:"google-sitemap-generator/sitemap.php";i:7;s:19:"members/members.php";i:8;s:27:"ninja-forms/ninja-forms.php";i:9;s:47:"regenerate-thumbnails/regenerate-thumbnails.php";i:10;s:13:"soil/soil.php";i:11;s:24:"wordpress-seo/wp-seo.php";i:12;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(36, 'category_base', '', 'yes'),
(37, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(38, 'comment_max_links', '2', 'yes'),
(39, 'gmt_offset', '', 'yes'),
(40, 'default_email_category', '1', 'yes'),
(41, 'recently_edited', '', 'no'),
(42, 'template', 'cedreo-designer', 'yes'),
(43, 'stylesheet', 'cedreo-designer/templates', 'yes'),
(44, 'comment_whitelist', '1', 'yes'),
(45, 'blacklist_keys', '', 'no'),
(46, 'comment_registration', '0', 'yes'),
(47, 'html_type', 'text/html', 'yes'),
(48, 'use_trackback', '0', 'yes'),
(49, 'default_role', 'subscriber', 'yes'),
(50, 'db_version', '37965', 'yes'),
(51, 'uploads_use_yearmonth_folders', '1', 'yes'),
(52, 'upload_path', '', 'yes'),
(53, 'blog_public', '1', 'yes'),
(54, 'default_link_category', '2', 'yes'),
(55, 'show_on_front', 'page', 'yes'),
(56, 'tag_base', '', 'yes'),
(57, 'show_avatars', '1', 'yes'),
(58, 'avatar_rating', 'G', 'yes'),
(59, 'upload_url_path', '', 'yes'),
(60, 'thumbnail_size_w', '150', 'yes'),
(61, 'thumbnail_size_h', '150', 'yes'),
(62, 'thumbnail_crop', '1', 'yes'),
(63, 'medium_size_w', '300', 'yes'),
(64, 'medium_size_h', '300', 'yes'),
(65, 'avatar_default', 'mystery', 'yes'),
(66, 'large_size_w', '1024', 'yes'),
(67, 'large_size_h', '1024', 'yes'),
(68, 'image_default_link_type', 'none', 'yes'),
(69, 'image_default_size', '', 'yes'),
(70, 'image_default_align', '', 'yes'),
(71, 'close_comments_for_old_posts', '0', 'yes'),
(72, 'close_comments_days_old', '14', 'yes'),
(73, 'thread_comments', '1', 'yes'),
(74, 'thread_comments_depth', '5', 'yes'),
(75, 'page_comments', '0', 'yes'),
(76, 'comments_per_page', '50', 'yes'),
(77, 'default_comments_page', 'newest', 'yes'),
(78, 'comment_order', 'asc', 'yes'),
(79, 'sticky_posts', 'a:0:{}', 'yes'),
(80, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'widget_text', 'a:2:{i:2;a:3:{s:5:"title";s:15:"Derniers Tweets";s:4:"text";s:232:"<a class="twitter-timeline" data-height="500" data-theme="dark" data-link-color="#00b7aa" href="https://twitter.com/MySketcher">Tweets by MySketcher</a> <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>";s:6:"filter";b:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(82, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(83, 'uninstall_plugins', 'a:1:{s:38:"ninja-forms/deprecated/ninja-forms.php";s:21:"ninja_forms_uninstall";}', 'no'),
(84, 'timezone_string', 'Europe/Paris', 'yes'),
(85, 'page_for_posts', '17', 'yes'),
(86, 'page_on_front', '5', 'yes'),
(87, 'default_post_format', '0', 'yes'),
(88, 'link_manager_enabled', '0', 'yes'),
(89, 'finished_splitting_shared_terms', '1', 'yes'),
(90, 'site_icon', '0', 'yes'),
(91, 'medium_large_size_w', '768', 'yes'),
(92, 'medium_large_size_h', '0', 'yes'),
(93, 'initial_db_version', '37965', 'yes'),
(94, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:79:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:26:"wpcf_custom_post_type_view";b:1;s:26:"wpcf_custom_post_type_edit";b:1;s:33:"wpcf_custom_post_type_edit_others";b:1;s:25:"wpcf_custom_taxonomy_view";b:1;s:25:"wpcf_custom_taxonomy_edit";b:1;s:32:"wpcf_custom_taxonomy_edit_others";b:1;s:22:"wpcf_custom_field_view";b:1;s:22:"wpcf_custom_field_edit";b:1;s:29:"wpcf_custom_field_edit_others";b:1;s:25:"wpcf_user_meta_field_view";b:1;s:25:"wpcf_user_meta_field_edit";b:1;s:32:"wpcf_user_meta_field_edit_others";b:1;s:10:"list_roles";b:1;s:12:"create_roles";b:1;s:12:"delete_roles";b:1;s:10:"edit_roles";b:1;s:16:"restrict_content";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:42:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:18:"edit_theme_options";b:1;s:6:"nf_sub";b:1;s:9:"add_users";b:1;s:12:"create_users";b:1;s:14:"manage_options";b:1;s:10:"edit_roles";b:0;s:12:"remove_users";b:0;s:15:"wpseo_bulk_edit";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(95, 'WPLANG', 'fr_FR', 'yes'),
(96, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_recent-posts', 'a:3:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}i:3;a:3:{s:5:"title";s:25:"Derniers articles du blog";s:6:"number";i:3;s:9:"show_date";b:1;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(100, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(101, 'sidebars_widgets', 'a:4:{s:19:"wp_inactive_widgets";a:0:{}s:15:"sidebar-primary";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:14:"sidebar-footer";a:2:{i:0;s:14:"recent-posts-3";i:1;s:6:"text-2";}s:13:"array_version";i:3;}', 'yes'),
(102, 'bedrock_autoloader', 'a:2:{s:7:"plugins";a:0:{}s:5:"count";i:0;}', 'no'),
(103, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(104, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'cron', 'a:7:{i:1474531718;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1474533809;a:1:{s:24:"ninja_forms_daily_action";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1474541073;a:1:{s:29:"wp_session_garbage_collection";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1474551238;a:1:{s:13:"sm_ping_daily";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1474574922;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1474580304;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(109, 'nonce_key', 'OZFz]UrH Z]iIcS.DYtk08-h8<9/TNiW23=X)I6[][t~@Fsp2]uVYf)^9x8{79-f', 'no'),
(110, 'nonce_salt', 'PBf;kz0SB=S{y~J0L%$m<u8>u43-#nc9v;_!%_ xc&D!QIdi}Ju$Ad,2=oG43xtU', 'no'),
(111, 'auth_key', '`mv:^zLRH6[td#6b+-aL#h/coJt80`vkZ^Fejli@!teu.8h++lUEKo0;&C;}@mF)', 'no'),
(112, 'auth_salt', 'qRL9L$TmvVZ_9=}#<D[RYH,t?chI9JQCen:C  +3Rb-) `$ 9u@_WFI@Fd?Q`|FU', 'no'),
(113, 'logged_in_key', 'y6kPF3kVgC we@B!6xuPGZ~XsJyIG9oC@Q?l%d(m+i*W$OR.kq[B6dHtr[KD7/Ah', 'no'),
(114, 'logged_in_salt', '_>d~|-4D2F,`xZ`V+_/mVs38 =WU?04!]WY!@&xt(%VG_P+>8?D b8C|s_F4pA5{', 'no'),
(124, 'can_compress_scripts', '0', 'no'),
(137, 'recently_activated', 'a:1:{s:35:"autodescription/autodescription.php";i:1474031236;}', 'yes'),
(140, 'theme_mods_twentyfifteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1471896582;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(141, 'template_root', '/themes', 'yes'),
(142, 'stylesheet_root', '/themes', 'yes'),
(143, 'current_theme', 'Cedreo Designer', 'yes'),
(144, 'theme_mods_cedreo-designer', 'a:2:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:18:"primary_navigation";i:13;}}', 'yes'),
(145, 'theme_switched', '', 'yes'),
(150, 'theme_mods_cedreo-designer/templates', 'a:2:{s:18:"nav_menu_locations";a:1:{s:18:"primary_navigation";i:13;}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1474491436;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:15:"sidebar-primary";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:14:"sidebar-footer";a:2:{i:0;s:14:"recent-posts-3";i:1;s:6:"text-2";}}}}', 'yes'),
(151, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(199, 'acf_version', '4.4.9', 'yes'),
(200, 'ninja_forms_load_deprecated', '1', 'yes'),
(201, 'nf_convert_notifications_complete', '1', 'yes'),
(202, 'nf_convert_subs_step', 'complete', 'yes'),
(203, 'nf_upgrade_notice', 'closed', 'yes'),
(204, 'nf_update_email_settings_complete', '1', 'yes'),
(205, 'nf_email_fav_updated', '1', 'yes'),
(206, 'nf_convert_forms_complete', '1', 'yes'),
(207, 'nf_database_migrations', '1', 'yes'),
(208, 'ninja_forms_settings', 'a:18:{s:11:"date_format";s:5:"d/m/Y";s:15:"currency_symbol";s:1:"$";s:14:"recaptcha_lang";s:2:"en";s:13:"req_div_label";s:80:"Fields marked with an <span class="ninja-forms-req-symbol">*</span> are required";s:16:"req_field_symbol";s:18:"<strong>*</strong>";s:15:"req_error_label";s:48:"Please ensure all required fields are completed.";s:15:"req_field_error";s:24:"This is a required field";s:10:"spam_error";s:47:"Please answer the anti-spam question correctly.";s:14:"honeypot_error";s:34:"Please leave the spam field blank.";s:18:"timed_submit_error";s:31:"Please wait to submit the form.";s:16:"javascript_error";s:54:"You cannot submit the form without Javascript enabled.";s:13:"invalid_email";s:35:"Please enter a valid email address.";s:13:"process_label";s:10:"Processing";s:17:"password_mismatch";s:36:"The passwords provided do not match.";s:10:"preview_id";i:41;s:7:"version";s:5:"3.0.5";s:19:"fix_form_email_from";i:1;s:18:"fix_field_reply_to";i:1;}', 'yes'),
(209, 'ninja_forms_version', '2.9.56.2', 'yes'),
(214, 'widget_ninja_forms_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(217, 'nf_admin_notice', 'a:3:{s:14:"allow_tracking";a:2:{s:5:"start";s:9:"8/30/2016";s:3:"int";i:0;}s:10:"three_info";a:3:{s:5:"start";s:9:"8/30/2016";s:3:"int";i:0;s:9:"dismissed";i:1;}s:16:"one_week_support";a:3:{s:5:"start";s:8:"9/6/2016";s:3:"int";i:7;s:9:"dismissed";i:1;}}', 'yes'),
(218, 'ninja_forms_do_not_allow_tracking', '1', 'yes'),
(219, 'polylang', 'a:15:{s:7:"browser";i:0;s:7:"rewrite";i:0;s:12:"hide_default";i:0;s:10:"force_lang";i:3;s:13:"redirect_lang";i:1;s:13:"media_support";i:1;s:9:"uninstall";i:0;s:4:"sync";a:8:{i:0;s:10:"taxonomies";i:1;s:9:"post_meta";i:2;s:9:"post_date";i:3;s:11:"post_format";i:4;s:11:"post_parent";i:5;s:17:"_wp_page_template";i:6;s:10:"menu_order";i:7;s:13:"_thumbnail_id";}s:10:"post_types";a:1:{i:0;s:7:"secteur";}s:10:"taxonomies";a:0:{}s:7:"domains";a:2:{s:2:"fr";s:30:"https://cedreo-designer.fr.dev";s:2:"en";s:31:"https://cedreo-designer.com.dev";}s:7:"version";s:5:"2.0.4";s:12:"default_lang";s:2:"en";s:9:"nav_menus";a:1:{s:25:"cedreo-designer/templates";a:1:{s:18:"primary_navigation";a:2:{s:2:"en";i:13;s:2:"fr";i:2;}}}s:16:"previous_version";s:5:"2.0.3";}', 'yes'),
(220, 'polylang_wpml_strings', 'a:14:{i:0;a:5:{s:7:"context";s:9:"Types-CPT";s:4:"name";s:12:"secteur name";s:6:"string";s:8:"Secteurs";s:9:"multiline";b:0;s:3:"icl";b:1;}i:1;a:5:{s:7:"context";s:9:"Types-CPT";s:4:"name";s:21:"secteur singular_name";s:6:"string";s:7:"Secteur";s:9:"multiline";b:0;s:3:"icl";b:1;}i:2;a:5:{s:7:"context";s:9:"Types-CPT";s:4:"name";s:15:"secteur add_new";s:6:"string";s:27:"Ajouter un(e) nouveau(elle)";s:9:"multiline";b:0;s:3:"icl";b:1;}i:3;a:5:{s:7:"context";s:9:"Types-CPT";s:4:"name";s:20:"secteur add_new_item";s:6:"string";s:30:"Ajouter un(e) nouveau(elle) %s";s:9:"multiline";b:0;s:3:"icl";b:1;}i:4;a:5:{s:7:"context";s:9:"Types-CPT";s:4:"name";s:17:"secteur edit_item";s:6:"string";s:11:"Modifier %s";s:9:"multiline";b:0;s:3:"icl";b:1;}i:5;a:5:{s:7:"context";s:9:"Types-CPT";s:4:"name";s:16:"secteur new_item";s:6:"string";s:16:"Nouveau(elle) %s";s:9:"multiline";b:0;s:3:"icl";b:1;}i:6;a:5:{s:7:"context";s:9:"Types-CPT";s:4:"name";s:17:"secteur view_item";s:6:"string";s:13:"Visualiser %s";s:9:"multiline";b:0;s:3:"icl";b:1;}i:7;a:5:{s:7:"context";s:9:"Types-CPT";s:4:"name";s:20:"secteur search_items";s:6:"string";s:18:"Rechercher dans %s";s:9:"multiline";b:0;s:3:"icl";b:1;}i:8;a:5:{s:7:"context";s:9:"Types-CPT";s:4:"name";s:17:"secteur not_found";s:6:"string";s:22:"Aucun(e) %s trouvé(e)";s:9:"multiline";b:0;s:3:"icl";b:1;}i:9;a:5:{s:7:"context";s:9:"Types-CPT";s:4:"name";s:26:"secteur not_found_in_trash";s:6:"string";s:40:"Aucun(e) %s trouvé(e) dans la corbeille";s:9:"multiline";b:0;s:3:"icl";b:1;}i:10;a:5:{s:7:"context";s:9:"Types-CPT";s:4:"name";s:25:"secteur parent_item_colon";s:6:"string";s:12:"Texte parent";s:9:"multiline";b:0;s:3:"icl";b:1;}i:11;a:5:{s:7:"context";s:9:"Types-CPT";s:4:"name";s:17:"secteur all_items";s:6:"string";s:19:"Tous les éléments";s:9:"multiline";b:0;s:3:"icl";b:1;}i:12;a:5:{s:7:"context";s:9:"Types-CPT";s:4:"name";s:24:"secteur enter_title_here";s:6:"string";s:19:"Saisir le titre ici";s:9:"multiline";b:0;s:3:"icl";b:1;}i:13;a:5:{s:7:"context";s:9:"Types-CPT";s:4:"name";s:19:"secteur description";s:6:"string";s:52:"Les différents secteurs d\'utilisation de MySketcher";s:9:"multiline";b:0;s:3:"icl";b:1;}}', 'yes'),
(221, 'widget_polylang', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(223, 'autodescription-site-settings', 'a:91:{s:15:"title_seperator";s:4:"dash";s:14:"title_location";s:5:"right";s:21:"description_separator";s:4:"dash";s:21:"description_additions";i:1;s:20:"description_blogname";i:1;s:22:"homepage_title_tagline";s:0:"";s:14:"homepage_title";s:0:"";s:20:"homepage_description";s:0:"";s:19:"home_title_location";s:4:"left";s:16:"homepage_tagline";i:1;s:7:"og_tags";i:1;s:13:"facebook_tags";i:1;s:12:"twitter_tags";i:1;s:15:"facebook_author";s:0:"";s:18:"facebook_publisher";s:0:"";s:14:"facebook_appid";s:0:"";s:12:"twitter_card";s:19:"summary_large_image";s:12:"twitter_site";s:0:"";s:15:"twitter_creator";s:0:"";s:17:"post_publish_time";i:1;s:16:"post_modify_time";i:1;s:18:"prev_next_archives";i:1;s:19:"prev_next_frontpage";i:1;s:16:"knowledge_output";i:1;s:14:"knowledge_logo";i:1;s:14:"knowledge_type";s:12:"organization";s:14:"knowledge_name";s:0:"";s:18:"knowledge_facebook";s:42:"https://www.facebook.com/cedreointeractive";s:17:"knowledge_twitter";s:26:"https://twitter.com/cedreo";s:15:"knowledge_gplus";s:0:"";s:19:"knowledge_instagram";s:45:"https://www.instagram.com/cedreo_interactive/";s:17:"knowledge_youtube";s:0:"";s:18:"knowledge_linkedin";s:0:"";s:19:"knowledge_pinterest";s:0:"";s:20:"knowledge_soundcloud";s:0:"";s:16:"knowledge_tumblr";s:0:"";s:17:"ld_json_searchbox";i:1;s:16:"ld_json_sitename";i:1;s:19:"ld_json_breadcrumbs";i:1;s:5:"noodp";i:1;s:6:"noydir";i:1;s:13:"paged_noindex";i:1;s:12:"date_noindex";i:1;s:14:"search_noindex";i:1;s:18:"attachment_noindex";i:1;s:12:"site_noindex";i:1;s:19:"google_verification";s:0:"";s:17:"bing_verification";s:0:"";s:19:"yandex_verification";s:0:"";s:17:"pint_verification";s:0:"";s:15:"sitemaps_output";i:1;s:15:"sitemaps_robots";i:1;s:17:"sitemaps_modified";i:1;s:18:"sitemap_timestamps";i:1;s:11:"ping_google";i:1;s:9:"ping_bing";i:1;s:11:"ping_yandex";i:1;s:16:"excerpt_the_feed";i:1;s:15:"source_the_feed";i:1;s:12:"updated_2701";i:1;s:18:"description_custom";s:0:"";s:19:"title_rem_additions";i:0;s:18:"title_rem_prefixes";i:0;s:16:"category_noindex";i:0;s:11:"tag_noindex";i:0;s:14:"author_noindex";i:0;s:17:"category_nofollow";i:0;s:12:"tag_nofollow";i:0;s:15:"author_nofollow";i:0;s:13:"date_nofollow";i:0;s:15:"search_nofollow";i:0;s:19:"attachment_nofollow";i:0;s:13:"site_nofollow";i:0;s:18:"category_noarchive";i:0;s:13:"tag_noarchive";i:0;s:16:"author_noarchive";i:0;s:14:"date_noarchive";i:0;s:16:"search_noarchive";i:0;s:20:"attachment_noarchive";i:0;s:14:"site_noarchive";i:0;s:18:"home_paged_noindex";i:0;s:16:"homepage_noindex";i:0;s:17:"homepage_nofollow";i:0;s:18:"homepage_noarchive";i:0;s:13:"shortlink_tag";i:0;s:15:"prev_next_posts";i:0;s:15:"googleplus_tags";i:0;s:17:"page_publish_time";i:0;s:16:"page_modify_time";i:0;s:16:"home_modify_time";i:0;s:17:"home_publish_time";i:0;}', 'yes'),
(253, 'wpcf-version', '2.2.1', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(254, 'wp_installer_settings', 'eJzs/f1yG0mWLwj+3WVW7xCDe7tIbQMgAX4zlaplSsos1UiZ6iSz8ta2tTGDQJCMFIBARQCimG1l1o8xYzZjVn/tS6ytjVk9Sr/AvMKeT/fjER4ASEnVddd6+k6lQATcPdyPn+/zO+np3um/VaeD4WmnzOZFlS+KMs+qzhfp6RC/2D/t3M2nE/w8kM/jdJHSZ3oAfpiPO19Up3vH/GhvcZv17opyPC+zqupNl5NFPslnN8t00ptPljf5DJ+GcWbpNKN/7p52fnz75nXSSy5us+RH+Olb/Gnyxvw0eet+imudl8V4OVr03Bg8BK3jtLMsJ/Tg4WnndrGYV6c7O7iyflHe4N+H8DS8aHb5LruvLqfpLL3JptlscSm/2xs0f7eTjkbFcrbYwR9WO7qOajmfF+XicpHeVLJH+emu2byVC9w7iUx0XZTLabWzKOb5qAfj0jcw4Z//XJ3CFs/T0TtYr55Qfrp/MNgdHMOno+A48OWDvR9Nq9rG4yPBHj9/c05/h/cfZ9WozOeLvOA934WB8XRGxXQ+yRZZIuvoJjdFMU5g0Uk6u0/sjAluVTfJZ6PJcgx/StJJVYRP/FgUz4vpNCtHWSJb2cfpYF/yKYyuJ3IYO5G7eW9UzBZwcDvL+aRIx9XOcHewv7N7TM/0JsVNMejtDvrzGR37wWkHSCsrO1/gEcGguJkl/Fz/cOzoytP/8KC5jT14294kv87oxAe1k8Zf1HeV9od/Ed1euAGywnmZjzKhksHJAT1/hHR25X5wubifZ7jmw6PhACccRr6/XGQfFpstpz58Prsu6Jfwxbn5IrnLF7fJrEiyD/O8vA9J+WA3ckK/Tcfj3qLojdJy8eXgcLi7d/KbdDr/4mp5fzkr7r4cdHjX4RCyO6AO3M/d039jQl/Ob8p0nJk/wnqYgfBV2+W7Bgs95PscYThE9PkpbdOe8KdqUcK3vUWZzqpJykeQnw7ljZmF+e96nj/gY3uyYzJSPnp3D6Qwe0fT7AtXoC+RUGbpe/z7Ad0g+fs0G+cpHR/+9UD+mk4mvXyKFwC/OhIudVcUI7kfwXvhM8dyuLBL7/PFPRzptGo8dIJzHNdIeFEUuNd/pns2Lu5mdHl0n//cxjsitP4ADhIhcdipo5M1FD44WUvhrYtoI+wBvPYfs7Sc3Cf2+0cR9MFagqY9w8NssBF5Ch86qDOR/citdc/zBo+AZobpqLbBka0/gQ16+QEY5Ti5L5Zl0hhYZFtydQ9MvAD5XSb3sD/dBNjh+5x4N3LafLYslpUyanh0nOgl7UfOdu/kUTt6VN/RPzf5AdPhcAVr7snjveuymCr9HtWF8nAFb9R3S3AES9gb7/tgAC9/nr7Pkmkxy+5pw27TqppkuNM8PO7tokhSmnKRTzM9jH7yx2IJLHcygXMfZfl7t6CKBtJTwOWS9gT/yN5nZeMkUJAMDjcRJA89qv1Bk/hxDifxL0lSZGNmwX/+Lxb+t2Lhf/6z6IWHTb3wqDbUFehJdcXwqHYvvpJnIkR+IIrhVVrlI6ZEoMIKvjWqYaD04YTV34+aR7ykZVdiIu8BexOXecO1Mu94vcxrXcXfQujtbyj06rozbupKqVfXVfGtHi/2jlaIPRr588i9wcGjNvVwA7nHVuXexnJPqbgh+PY2FnyWvDeXfAdw636wwywci2geA8g//Pp6CbKusarXKhfF4MSnVSDC+aGfAOUn/LS4JvazVYG4HS8nIievlzNacDoBDrtSSB5+HiG5+zAhCTPEdMWNjnUvpjV+gtNEP8WnOc1PcYixO3ewu4kd8eA7efyRCs7hw/SbpoIxbFcw9jZQMPZX6A6s06xbWLuGEfmGuH5TxVs/SwpD1UTBQJyCMcsO/XcwRWeD9UcJ+uh4KKPDzl3lM6CyQEMRfSNJl4vbAjVNdn3Mi7usBLpOjG6ZeN2yn7xa8DMVjFDCOaWLjJxgTMQ5iJAcvWdJNiuWN7fEcPEq38Av+r/+1a9/9XQ8efZ0vHh2sSxnlXGE2sU93YEHno7Hz14CH7tPsgnNneQz8/xVBu9Ve6l+cnELK2DSRW56k1Ug6IpqAf9B92U3GcF6b8j9C/9eVgu86HCBePXANmcJEdpsUfVhFWNa6h/ycoFbNklxFrjZY7gPI3Yi0+/0C5wavry+zlAXS8bFNAUScW+Dxs4oxSeq+SS9t1tMv/zh+9cogUe3SVolT7Pps+xDinvZhyXtZNXO0x34W7fxzXXJ3ySw1fnMeS9BCWospYvPAPfouc9z0Ad0+f6Nnxcz2Iocf2npAGmmhIvl3ujHW9gwUDyS93l2RyxxksNmI4ejzafdkf2Hx7aA+VVZltzdpgvgfumkzNKx34dsTM/jtwmoKmwd4oYBzwo3yzFonK5Hk8OL3d3mSHjjfKFaDVIsv9QOkJ2o46NbeN9MhMTe7vE+XLWnt/vP9voH/UF/8HQH/u0+B592+RNYZsXs5hldLvgz0DhQErws7NA5GW3JhV9sF1ePfwMFryao6cJMSQ+D7+Ek0DhKZyM8CJmDbszt8NnXabWAk2oODysawlPNL+i26AonRfGuog2rgPd0k6slKITZbQ4LoD+OMuQP+SK5K0p40NHN5L7Pg5CN/i7L5ngOo3d4wLDbQKlspcJZlqBTVXCChb0BRATEM2gAYGA9ZKQ06SxDmZjC/dYx3Kli9AVEb0bcI0thGhyI2Add8Lv0vosPltkW7jpQejEzv/rTErkGCFuaCyUuvaTMskDySmlEWEM2ZiJd4Li1EeAvKOFhdOCq0/wXeLttkgM03jSfgWE3SWbL6RUcDeyIzoCjZuMnsl7QImB3r2FzaY4b0AdgpmwOOjuRDK0NBscR+N/AUWFJ3SSr5tkoh/Xz20Zmymes9uvCacpz4sbEzVPYggX/gJ73K0F/TQVX7Ed8TOmk6zebD4w3EA6GVSi3RD+9Pa6+UqslQzzC1+h5wKeZTCshWvgpGyTT9GfkXXQVPKtX4s15v9OrnG4N6l7KMJKJjqxL2gZ5BrxtkaPmd89n8CORZrIlz2yxuY6hHE+pcDbwVT/5GimOmWs3ya95e2H6Kb41KNa8lq0JMK6tBC1V3BN66BbEEe0crAZ41lZBoniray4QriJyU3E5OZzFD2CGAT0Vd8Qs4S4uJ2MiJnzn8PIFxHyL7jcSHkjJ6fhnkGu05mCvxk7kw6svcXfgYl7zPuhwNBLtaZepdURruILdT0gUL3Ja/SKt3tHWfouLpRcEpjpGVXYSnnXICpUDoYDLF83fbJGs2Eq2RWZ4IWJl9RMgWxU8nhT8e+iuVPQ3HLzLf8J/yrYGZOL2rABhlc8Wqt839w62DIXYXUmXFITZPCUNCFUcEnQ8UXVb3MFuFne8i8xV6UYipTxNk9syu/7SaOc9ejES50hHO6AeFMtFtdN5doGabLZIXvNfnu6kzxLWPd11+44u0XMSa3q3nt7uPfs6/8AqiaiBZQZf7uGXywn+7ySnR8YoY4sZbkVFtDhDriSvnl6BSJXTgA29y+DtU35svJxP8hHtDj3wdAcGtMP+jzeve9+/fZ6cvX2VjIgNFwm+Cglu1aWAmFOUjXAKI1AHdLRke5ot0h8z3Ng+fP0W/9ZN7ubmAykL/Acc6UlfV7BD78ebQO9ub9sbp8wmwz78n+wJPr3PW0ZSvrlLKalWMIgworyqlhmf6tnzr8HWm+Pyy+Q6zybj5m5gukDCvhjcvWCDhbr5l33z0++zqpi8Xz05fEVHzyd9+TsgqgT+vSD/H/yU/pzsNzcHXhdWvCwjb3w2HtOkoCgsWJewW/girW6virQcs417DSPc+hOdpzlYB+n7NJ/Qy+HbAme/BmlPqo9V5cyrvmL2P06mqBbgvb/DS16BnMQ7/XNxRQZ020jJNcxXtVJAhO0O+/ty9l9lVT4W1t6QRTyrV85Y40dOsghZG1z0EkwV0lvo5qWoI6D9s7w5pcXUCOomW5CmatiMMDB683w0uVyg9MO7A9+x1YHc6hrJDL8us5scFcNL/l30ApyT919k8KC/T1osvvXZaLH0ysVq8SrbRxJhiv9yutpyPsYnRTMIJhM2lZwXsj253WLSh5n+WJHw+8dSm47tNS+Z8ypoW5tbiTQBhDbl6/D9xWtnYaEoHsN6RZDQtvKqcC2o1LynbZ9lC+TRMMA4i+3hNxy8+BqDF6G1Pujv9QcDz0NqRwxHr3Y1sCwxPu/5oid8eiURUHB0bG/s16yRff0ktoHwKmcp+LmfT1KwkFHEkQYnJwcmlWMiE+EdEsbA43v7u7dJMRlnqO6A/nLQ3wtZGBAzXDsYCkgDrnvKfBw9z8jCJ0CFMxj5vYpz8+MfkESIaDDtB7UgZghordGRLGncqyuy7Ltix96Arlqmky4/koY/u03noEAbkwH+MVv0MlSb70DrwsWVIH5RAYD3zkfNY5V9e+tvdnwzHV8auV3VTcUIJy2dv5rCouATpgPBpUxpY2i11T18npIVtpxblnfd4maBc5osp0Sktzmw4hm/aAUSEv7NmiUYEcXsP/79f18k5ZJM5JwtSzJe8iwQI8zOYS3IOH5CR9sljJvZvDCe8SfxUcLW3XJwoFizxijh7m5IqGfvi3xsJUcJyiHJUPRTZGkJ1ggdv3tkBhdokYuFyzRNKkWRdNwzqPj5sTpmH86zxXIONs8vKLt6yYvsOoXL7Ee/Q730Bng2Cj/isiRa6QIt7DjG6p2hluc5ONkioKoPlSUiMaDyc0ezNtQCtiFK9LV4awB5WOBUCgeRGcxYP+XVJV2BS+R0209+AhY4pt0RvgZ3nTaoYzaZrAWJCbm/NqiGtDPQZYt3QjnLcgLUMgPWgZIHhNhlelVdotr6U7JNqs1tDmuEERfCbKtQeXli54A9L2ck89KKL+1MBH9KbhESA+6AKniTEa5X7wC+w0+vnr++fPHdtxeXr787e3H5+uzbb344++bl5fnL1y+fX3z3/eXz8/OflEx+WpTL7CezgudvLxIkNPTTo8cVlHsg00nglqIF/QQWxaU8CcMt4P1EqcdjLjM2CmgIOHoYNtDjpsRDAtVX3Yj3bJCiP5z4hRpE6WIB5jibf2VRsDvFDPq/iknoLiesabEUMZejh42F87jfoDqjPipbH8Fro5ZF6s7yapIDk79ekngm9T7QWmnvaZ7O+f1spD/AcXDGDt7NbIbqXzA5ekOcbwUvDhAJOo2AkdI5wwrOfn/2P2Az4Smck+hpT6mplYr4pX7CMS7PUOBfoolweUZei+r0FIkUruwY78gUtCY0+suf1BuHb3yD1AFP4FtOUaelR9i5lF+LS8fMSEoA+rlfvajIqQrHjstFNu19zPgN+p2fgOFErGIBzPUuvSfnuWpzZHsGg7/Ag51l+Ff4+YdiVkzvla2bkZo//In2E2/oT3SfSuB3fLvyGVzZCpVF4NwgZmH56oUiLj8j+S/qgBmRDO1p/oE8lAHnIELH41HTnBdKnnXQH7KyRJesv9RihvT3Yzr/D9+jgTpTdYQVNaI63MEM1a6A9MhR4b03vPukt+ANg70HroNxBL+l6nOHr9H4xkuYoInJTv+ceTVpaeg4mBXBfGT7TgrM7634Zgk3ucoCQ65lwgj7ErrCb5EB5RuM+M9CAKmjJNgYZU5XsMeoIMEfiKuIfJQ7aK8K0nc+my9R7F1lEx4PjgFMnAl7S5jjwNLykp/0ToRnyWsVSwF3g1dFUxMdXMD7fvrvv7u4eHv5/dmPl2+/O7+4fHF2cfYTc5uf5rfz050dGvanxg12G8UMkHL1xZd9Bgof0B8aYL1nyZtstqycqGQdfxJZmfg30LEgai6zeOJcz4v5PStWSjB+AXmo9ri/k6M/g8s0ZqqtOnx2E9jzGKNl5ZMcQjO8ZZ1XMzI7MvUodeDHIwkUhBoHuVbrGgrevBKFCeskXgGWUVdsAsgStgSQ9Rd4oL2XOJMo4Sjl+aYhQYgvplVy4C/sBqHgUMEpUie0369SoHwy0sNRnYfDejREx8bdIM1aSDwdvcsWJtYg/ue77Aqd5nArQTrctq8YfzbLPszpqODyz5awg9lUWKp6nwq2Fp17y2WFd87QoMJYFFmTHdFBYnKOJ2YiJflYFRKuQrKGUWjyqqZFElMQ0zWTegMJkWUfcnLh0w+rCJsRJsw8M8UQTkWr0ghDNPY7V0q/xcxNWAXyoJQMi62FcQPAPnOuYDG7zm/6H6YT1lOarww2AXl7sipTjQGNM1BeTJzRscHm78EAR0ncZJgwJMcYC7pLNOxoWRL3Z7vT/8jJVjP8y2qUzrMELcysxDzTcuLlGcVhHGPjYNMqlckSPrCUzg8zFfm/ZOMO3SK5U8Cm2UKEm0YaFe5u7U43/abn53Y2oFlaPJzlcgFsM3p7zv/5NYvcmtssVZUuDTVF2ATkS3GnmVhqz626FbXf/likIDDPX36HGzvNwbjvYZhk7jhT6GZnPkyrUjml1n3NmYxMtVV5bfWE/nR7D1JsfPWTBCeRaMiDR2uZF/PlhOf/CZ1njlWC0WtFbX0bvJM07h3g7ATyIt3B4VZgQNZ1ZQpKFwG9r/qhqnxmhKZrr+m/WO2+qOYYSRKjVA0eDvWRjkexEncHkBuwSIlYMcsZ68OiQII4RL0E7umIvYXG53bKjj1kb+Vy5qK16kYlhzn9jemAPXJwRDvjzH9QM7KdUCu4x/kougHfpznKil96Oaz0A25Ag7t0ia3gRVrlZ6eI0B2c2H2vyj9wUDDi/djrH7P3g1bwD2T2ZHDYqebIwL7kMzpUXSY99COuHHgHPwp6IL64FXPiD1HlncQDKg+FyUARwawOMT5fioT5kTncjSIvZ0VXv1B2HU4kb0hrrHkZQFBklfEy6NyizS8wxYT+IK6HtLxZanhXHVa49eSCqNzXwZRv3W7xWfioc8N5g4dU14NrGjAN+Sad4JXJ3FGIASIDoydDY+DouZ2kSMzA01Mxy+1+h74mOwufpz9s6+pUae0H1bSfzs4/Iv/DFLF/7NACgOkz8ybxzd7X7qaLaLwqLgTflRYjukbu12mixEWDjlgLouAbru/p/9LrJS8KCsNOMzC9zNITpC+ymmRTSX5jhvHVcjLJFhxn/W3S6z3rPGJvL4hKifLnEkRsvoC4Bzn3klzeSHbyO8w7CSkHVriAC19bjItYk92QzyIx4ZArBSRgSj/LjH4UXPm93YHYyah0cr4+s007yot6FpdPi9E3+EKEPvEzPE79gmM7I3ae0Gq9/ViBYgqm+QyVlvZ3oOByFSwbPQXfkl1zmvwATPUabAiULNeg9J0mu+QC1XTFPinwfbD68B0naG0M9/YP7Az/8e//x2tz5O7A/+Pf/88Gif3Hv/9v+mwvrXreI4GqKSgQi+o//v1/J+Ij2vJ/jnMH9HVEpog8Fg6rlKGZFKQ4O75hX058qD64JrFayi7OblO4FKUKZdiIW9D2K9JM4O3ZP4H+I3SQ+Xx99cdW0VMLRNGRix/FnfFB4PcfvIpV4bsIv/XxK08xzEi22YRuOP/EMNLkP/qr/3FFP3bRejsr5q1jyfRb0ikjklhWg+Q1TeeVBInYfFZHZsgqs6r717+EvqkxmHKc8IHOu0btTpCk1xFBDLcebh/bZw2Bwqs3tmXMGwP/r+7E/QfnYSNyoBwSMsnQSMAczrFSGvw263nW00UFW12ohXA3k11hhpol5xxmrpLf3Cy+SL7PKHZlV+BVRHdrfyYrFd0579NShEUGV5miwPCnHPcANhPs2rTyMSPMibtWo5nSdij32DtfKEPZJWwBt5sW42A3ztG4a5p/+XXNTTYukIfd1t7kp7s5ByRYvQXNHneI02+0fN9YypRO1DxI9tmIIbXU4KXkBJEet3CB0za24oPLNc3d3sVo7LF5JVXtnhUzRwNo6KFHR4oVJByyYq6GFdOcB/0bPaBvYJozVJ2cTVY51Y7dBGjNCG0aRyZaDOhH4Tyk4Hq/mqHpV0kABCXyHAeYZLMbzIkCE1pDca8LMBWBhdAtvUhBaRQFwpsmZKw1SI+Ikp3DTpcaZ5cvXl7SFk86dj2/y8cuKstJNw2FKEjJ4WtIzjHiybCmWhGK6BwUYOy0n0LcpG4ehXBAinnTjLqOWsAxdZH8liyXmFA4NEkFe/2D4NN+8Gkv+DQMPtnUhL1YYvQeiMd3nFYMZ8/Cj3xsdXwMTennMgJKoGMPFHn5jeeEXdJbDW/tFuUM8G/InR/+EF3lkzCn+qzSKhxcqOS9SvLNLfn44YE74FLFEpW3wP16L1np8FK5iP56RhuYmjkIawIIYScfrRAoJC/F8/thwfUQrzMMJ2BqQMJ5yZRrC5dA01D7yTkW5VUusZGyTSlLmCxq5PDzdIZvui020ZNu8hxoY5IyE/4alMfRbR90Nt0TSq3XvFYS0xKnpQtMvm0iKnm86ze/sff0Eq8kf8dlzt5rXfddKumUzplIZjS+vt5sXgWxMT0y+IG8U/xN/lgfHv0opUuf3kImcUPKJuUIklMx2Cm6z3ZJlCvbNtUoK9GWRelPNKaz3hQU3MI6F91YckvwtawW95Psyw7Mvrg9Pdr9xy86eBEXJf3vbfj1AX39kt9CN4cOekbcyzgLF7ftA1z4VyrsbnCMP8goiLEKHnpHlsj/O372L6OU9bl8/GWHY9KUMXKE0BBHwKon+c0MvsH/gIjK0GyFJX3ZGRzsdv41kuy6suj5YGewSwBEhHvUg6PoyVn2f57fdJ49zaeg2ZWjTzBgDxb4Yf+YxrVrBkU/v7ldfNnZP+5wAOLLDmbo9xa3y+nVDLTLBKaiqu6ebsLOM8rMxdx7Mo6ZwoQIPeF1leg913PqGXvNOMfnX3Zk0/8VjmO8wUEcDj7LQehOWaQBKs+s+H0+5kzWjU3HM9gdtp8PfLnRAeHmyAH9mBHvrrEjOSfiQcoi5AZFro5erOYhydXZIQbw7KN4Abo4dCmutGC7wX6frGEIMApzMjOI2fAnj7n0h3uf79LrKj/6sutAREVHh+1EdHS4GQ3tORra+k5OYcudUOFdhzjpw6/vwWe9vjneLJJnn+C+usH4gg5WMFD4crPNPXCbK9QahNh4c2t0vMnt+5H99i6YhJcalb6uU+LAjpRymbySWjdY7XKqiihajCyQbeKz495do8Fg4FPUKCpC9crWS0kx8ZobOs7rGq7RmqpFLqWSofbb0EfZc1T5kiyroC6sNiCF524JqHQqU+u7fGuanXKteRfqm6AKqChcDWHGMoxGucosr9xqxj2NGocFRuLCCDhzpariembcdc7ym4JV5Yhidjt89rviznpKahtameIqqaTRIlTjuAufxiK963zkjoDC9pOwROsqo+whisOyF5cWdFHEho2N2pUcE9ZVybUCtvk7vRvoEnQ2Jo8YjCb5Kf7V5Fkp8MDC6Wxm56ARAx1/Bfva31+lfeztPpZ98d4Q2KYupVdc9/RtBCKp+himtuEUPXiJD4Oarogv5lldXVnEfM7lNOBztE/C5563nHvtpDyXwzNwBdF4Q1sop25kSk18hc4ELOy/09I5TLRIPe9KhXtxrdxWJXYgxUz8+HQBKdHOcbfndULkijspEMBsAFcc0qjBmVOMQin3tXkNVzwv362nwf3PQoPuriNZyKI+huBi4xF1DfeH7dQFX25AXfueuuyZcLFSkWy9tnxL5t4KKYz5wOi2KKrsEXzg+G92Br1xnmJt4Kc+Ch6WT2Rvf8WJ7O1vcCLH7kRe0LhS2CB1X/GbKytpnEvCSxMNAf3keItT9odGS7NTDRl6KIWWk+VaAMKuTd9liZSIN0Ls11K3Fcg2J8Ep1EWS2k+sFVQvNYGNnXxlht8myxkzsXGyvZxNUIEgFUjcK8LgZLInUmRVG8llw15fS+zlXkqX6dd9MMkx2wTH/d3ZCxyW8/Sdl0U1rKsMgZNaVJquZ5tek9RNNEVUrFwayARy1uJ+uAw+MfNN7p9VFV9duy3wSioO4rl9XobH5nxfoBfcpFQsEqh5Tb0LdCCMtHXtRnG2MBIgZXDi+8EgbkGtji8yewjwsWseJL12UaiSo3vmCDRUobLgSLtAZuTSt9XinEDLZ+SpWcZtulvbvK2oAb6JV3i21ZXmuL3XKaZXkT7ovNs36MzG6AePxAr6XXqf3GWm6iaSdUcyOZVMUAmILKdLTirAGCJWA43oSuM4HpuHMwRoJI/xoFQYXXMXF0OHwUEtKudxMBISUmXMTizFp/jMlLTBMpO02KKcYXw9reja8iIxAIcBSoOzEqDzIM4OvMFk4ip3RRTFchCZ9cDRFSVDxyAcSVrmhYM3wFo/Bi1xxQ+yXrZcsi3M3PI60bgx1xzEIRA1cV8fZVB4rqC0wKMjIM/94VUUPEUyrpc1WpFp1C9fTfG9KPM5U0UMcwxk+hly2wVeXmTmlIAXrISuP1wF4GsCnYCpq1x9oSFHuBeEEgFbQghyYAA5Quf6f48yI8TusTX2lKQ5cneNPg0g6DKTVHHCtlzOcsYDRKK64WB7QjHQUYHhehELOCRtGdlsmIVMZHebTTBzFRMxYa8s8QHDo30RbIY7XgOhTOCJ33NtOWXl1Up+XdKrSz/ElEKuVMwp49kHZK+zsgyK2hrJvHUYA1prqSHfCguwlhNSyJHVuJIp/It8J3VXkURJoPyCkORV5HfOxmOfBW5rVdw9ohngon3ZcbAMHSwFK3MgPERjjKX/2pSc5OpqfllhIPJSMqQvKY6ItThSSo7VQJIjHeSk6p+T/u1CMOtM1lpaq1iLqQi2sM6XQcG7ztL3+Y3UkGLyO7LvKw5msuJAExFhaml2MzMa181FTD55hvbrNgdKxKA/Bs5caL+ShQdJXGE5qKQj05KaaQcYREZ0tF8wmRGOgVaLsqlSHwLcjSvEZMEC1HFZzBErrlNbd7Uik8XLQT8p3DVUUdk0i1BVqqk0mE8X1MvZUjuKVjPeRFDhU6vO0B2gTcPwI2UtbJJzLW/whzy7i9G+vZzXyfkFP33xBmWD0tNzQQVZuiwyV5NXXP0MpHa5KC7Tskzvt58k1xid43y5xvIcclOQAw9sVXIbqaayWpjcV9YbTdUaeryKUc57o4KVf1rPFdEUxFptKpnuDHbBW80wML52OZ16n1WJZkR7DQDnGyUvvkpe8hv9BgTEh3wKFkb2IRstmQsjx7dvHOBteybvCR5kHwno09N5mV1y1ggl8/pFU1YJY2GZX76F3UEEkx48t2BFW2pNMHrMRKP1pwG5jYp5LmZBUFAnGSWc0bMQiIJIuRoXSWMOsZa6SEW8uzkdVwyMTAlZXbP4yWbmUM3ibT4ZB6mW8dpYZAvsIZkUktbE+WATui5UsOUyhLSW2lUWBbXUmBtFaA9FpBLGGVGUT8MMUWA+uPLbVbwrvF99k1hDkeIuNkQuvy+KxSVh43AZFWoJvHyBSORydcz1I/1u9ZBCaEK/CJO4nAUFUq+ew23IDN773S1GYjiiacamalxgT5d0CiUlt3FOu+6CqVXVzCNOV8e0C0GDdHeUOHtOr0KQKYbMave14+Pjr2bKn0AGdhTnRrPFpBphuSgqVGJyVEuvY3JX80sFBuh9OlaPGhXqRYq2EUmjEhvZMB8Uh6QwpZp55GikkZ+/soCIIB6wuol0Xcm3o3pdjA5WNTgFeDNEgGRjvXETUsm5Nxxb6hlZH1RtwZYkSK5Es26Z3jifvZeNq2XhVbHdlck6PsmYajhO1cpzJTwduSwcv5G6EZeCiEVry7KONyToWP6yz9tYXAzUMwDODOf4LK/yf/9//q/YsOju2q6eILtdFGAr0BuvWSwL79hooDa/80pBsDk2lX28LB0yg19h+1u7kjSUj6wFTyaWf2vJUESLaEHuMsoFJ+7VlXiqEWVNp7XYVJP+1JJNBWRNqsekDhzN2CrZviWTHD4LvPOT+p12udGkciBdW7HYxgIEWShhaCEFbUxL9O1MSXkjEBlK/hOVGUv7avK0NnitPtFdRSn4prd2doeUSXgnVCC1FEvQFVvaCmmqhPfU5lFZw/CkCESWGxh1oLT9VXJXMXiNxHIV1KhuI9APDkiJhGzQM4MyZLpq/J/T9ynzxmjuLnsccDwGB5itYrkvyOHlilLNZjeL/sMnMI22Lh6EQquaRisCySPJ8kvnMwddZfWElTqNwCwRpxBgQMO8NhmS8QYdthnDcjVhsxSY0DofFJ3QlydanDrBkKLUe64SIOxAFCt380tgZRMwA3oCxkEeYu3UFvZkM21j2Jfredd5NquyHHRoUC5qUBcv0oUUyQI9A9Ut7hBsSVnotjGEQ7xnfuDJqa6rzi+7Ii2xwojgIlUJZW1xOdfMApehbe7fmEDESDnBKw+vDBoWB5j58Ehbt4Ad+NfQThUUV19W6moMPZV2BWFtvYrBa9rCEoNLk42+pfBS7EsFO2RqCn9NqBLNMAMqVQTauitFaNTxzYNc+Rp5W3g+y9oZjZolwjaVpJawpOUE+1+gGw/ZC2rc3YBGtHPKE0vTnOg8NBU1+Okw+HQQfNoPPu0Fn4bBJ5tKrd+EKLpfpdU7YJy95AxPVRRsloeBiPwR7+3LtMrR58VXbc4VJq8ckqw64wNAbSRHCRmAcfYKafWaD5PEDbrE7qncQj2nf1rmiIbroiHA17GiP3nFyN5VIeDDGS0mKIhGKwLjMLZm9N45Y+1URQhCgCjP5E3tP92ZM5eZa7b5ULLNxWHK9tg4hJ/gaIOVjsEaKaytIQa0FyInwLUkU6wwmOTvJKRxWxDwG9fZoaXU024Fik1RccwCwSO8vFSPH1fKlyDtxyZFCNghewivaOZ+clZJgIXM5q7Wv6AAv88QBi3MtMaicYeTu0VxxRm1slTPY/PtuomgLOSU7yQNAmQX62ObI7iQEETrfrHggfXy+6EtPQnIgdO028IlZioL1clm8kix6pHTOmIgChwDE3I8KAjTWIYR4CXoWzc2kmMMNCO53JjwyZGByiIXoUSojWCJEd5b05PK5WymTskyrwjOGR05BSE7zJ9JkApjkXY/z2UzKE+dg7hfA92YW66vjtbqPJu5gqdYzEWRU4pyMu4H8+imS2TyfS7xHvX+Zx7HWApoKH5D6DyoMWBljXQ3+eaHV/3ke/JzEaj1naCKY14b/v7V83RG9T64PTjK80mxHKMJhql47KJTABQXfFDDg6nlrrDIh37tMNi00IIkEq+WiBhLiP0gdsFjh2srroYPqPxTMTRpFBgKuW9gO1TmZCj+SjO/B72UvaUCKj4b98g3RbV7HAXKZj8X92x5gBmYpdMJWYZAp+R651yBVXTJqkUdR5Y4OqrJAZv0fW0pxIP4gOTe0VBhbWj/Wj5eNOw6u4VUfyrrWUVmpKJRMZldioSUGcaHXz/y464xw1KvCLKYUPbuAc4wyohNPiYSd10CDb1JhUMrGrI48FizW/oK7+tiAlzK3sy2QOVdhvjfC0mSUIunzMzVfSvdi4Nr1VN1zSMpZ8lzOpAPGBj0+YZ6lU2JkReCFhfdNTAR2ugGxWqi7PWTr8igdXFUX8s3VTwKxWjk4qyRLOo//v1/Y1D8LeEWWP0DJpgaJr/F1ABdKQHdgEFegsWAyu6CqFy+cMuPim1u4yKWL0qRaYbqYl5NNVoV21AS0I03SLVM1bXScgxa8CgSSYqj6aXcr5JUU/2Jcsc45DXxFlI1KOVCS9vcS3Y5oZi0Ayne8ckkvimJ34gmlH24HJtXgawTl0Z7PeFCRT4vYjSoY5AH2Ywl71sH7FJmQPzI3uVIQrPWAtuMXHY0hY1s4Kw81UQPW9k5wahFLwouIXSK4EyCfg/qpYfWJU0iu0lH97UfBAyST1/01TEbiojbSAX03HiL7JbKKA9oPj1ghaL0klJIvD/DZeGFFGMNFWghE7QVF5SR9QOxvtgMKClRYWumRGsvE5e8FKyjK86NJUXyrjkTk7WQt797u0Jnlt2VbidBbelyxSqrwqfRM3qRSUsB3YtZNEZFa/V29BpBldtEzxdsl3vDSy/UZv2dBHjvGU8N3aglFzE+56ZEnnu+mnm0EUnNqnxuFuUrucE0I95ALsENu0FuJmHSEMEqxL0zXYY4uQO1XazOR9vyNhUYBdQwehmlp2nGHOfWcKIUpjrgjgUS0opcVxVwjf16mEeee+wOszVwZMwZmH3pOwXqHQVjZLn4/AQrI3EKAwcSbFIuVpOOZrPLnCz1pQSByoE6MzDknNw1Tm2AH4mjQGwZl3Nj0uw4UREsktSnHLMEC48ksEPu5/zHbuho8+ctxeli91HG4TUFzzEMxJOophX0IHkiOVFb5BLGWnZ2yBD09oyStkCTfM8oF6h+i5snk64p06zG4h3dnIGhIix4BkpGmWzf4f7ns3dP2Prmdll+5WWmFQ6Fboi2KwmIWNRytHk4q8vfqh+Ai5+ByubyrSmBxwmpM/bFe/cBLIOlpBR/qCfBlAuEEJzeFSw5iHV0yn5yDnJDDNOrZT4RsDoiKka2Or8DHbW6xToHUm407YoeYdgBDmKCoYGYPcCQpEII39wlVP54ey9oqRPOmC1lRN3dWAEL/D9CLasBC8qSftvOSYmaFZFDpC5p/d7uzj2K/VwReu6JifrtNCmeRHj33nDC5Upmo7rSDGrbbOx8WvAkGonmSz4DUzNjSOIrvpMBmlzDsqS8tmtuReZMLOBs+Yg3FK9Pg/X2k++QwWaS4UkpEekVWsKDHQeS/uIrFyckaRmkONQicIQ1SxYiEs+iWHKyGl81SVeUYbGEgaUu6+sgjmcKXzxNEb+cHT3WHUAmHJKgqdaSbl3STksYoFO7fcBXsNRZHVWnQYUMkhaHMpLwUWaL0GVp0/OoRS0FgESakgKjV458uZQq6NMvXNuYufO8BzgT4pHeu3iefEdZNclzTvCrHTGhyZA+jJzIB9g5FccDyM5orL4O5oFlTceyhJt4ptLtZnw/S6dYzUSvtE3KsfeSPXFKOhsMDGwiVC62DmV/SjcqbmImWNs8+TyV5NFU4Tv9Zghts4cBFDL4N1iTRmG4di4yIKJJMRcjsG5ekP0nGdBTMS2ntGNmw1x5IdqJZOCzwi7qhKt/2PktrvMyH395uDvcG+51+AxoYekz9n+Qtwk0atZQt3a2UGnd8krNdRFEAiYTTTKlBnmqm41Ea8S+NJJdVQFDv85I3opX6jovMaMTIRzx7WHS/PpSH7+kBG0wBNVNR0HSoizZeUGXmQiTmpIHnhasOoQzI+vdTU5Qs1TiqPnNbChRu0HjaNPUZtHQOVGZs3H9nWbnrdEcOL8ff4fXP9APxEsdJk7D2sg3RS5DhPEvJFUdFz0uRoRJKEYn9TtjTuMy1fLKOZAL0dGIhRFwIKfYjDPQ+Se1G0pp6XSGJHC1OZ5Uho3DdPMh91UF7iEeTE1rZyKgAcTUMyaSe4jbnyHICF69Wj4t/ZrarleXRPaXDHN5nV8vwswd+yTfikvTmrceAqRsGvH5UW7LI5azwUJWrEB80+RSTLbo3ZiIt3j1W0SKpeQaeKWFaxRkuX1vGHIXv3oxQ+VEAvdubFNPX1mYpLAdJScjYo1oVmoccZsTQchPjFlU6eyJKAtcpcsuVyLlLCey3trWhOMnW2i9b23Lqz3ZokIO8ny79kd8A0Ur4GiYroCMX1d5uggqjGlyPNorcUPoPp2aV32KV6/tlBK/zKc79GBjk3x9jDqWXX1iIuWJfrUSp+ar5s6hG4xjt+yxq9bNbC4amPW7bL6QnXJknrIbdjkXJU5rlQjVFWQ4Y5LbRfvSlussm6BtkrliiywoK+aKYrEDtnRD+dhloVu+9gXXyvHFQf8kiGHi58Pa54Pa5/3a573a52Ht8yD8HHw6rs12XJvtuDbbcW2249psx7XZjoNPR7Wnj2pPhzsRrixcl13Vbn/YS4PPdtRd9+9hsFfDYKeGbp+oW/dpR6S6fJJmxNIJnGAVsc/3yWlnuDs47O0e94YHye7R6d7x6fCgE/R93z+K9X3XJuagbhwf/0Ym+9JMM4ARkN56xax3B7rbDbZPx77ux6cd9Pe6ruXru6kP96SbOxOrRXiJ9kHfk07lzQLheif0VQPH26AfYHdnqSE+k5QI479pIlERRE+gyGv+RmgpktCudWpG5BqFYSEo/FOMtBAOC9dgczPrXjFzzfFemWC6RHszavHd0hqeW32z6wFnhxmfaYFotMCaPHfeVrbJMZiYBko5eelEQfelcuf8pXCyEsvIynFPi8LF5YB1JwyhgLoR63AipPAnxjHMjsT+tODWAaLQqx7WvnJjH18FA3ICPclsHKblfPBNXth3I3Wtls3AxfFlDxOyUjLcL5pIYhoSFFA2zm0Kto1eubheUOx16WmG7UOXVcnWj3g6sDHCE5cgpIYjYv85LBHpZs8Ni+18XfbX54uJhjxBzexhfKYfa3U+OABm0WHeE/YWHPregvLJ8rA95eB/676DAp/4n92oT7N/hh7afeVOGCRRh83qWzrktSRAysl8KNJ/y6ScmlUz18kv4RqYk0cEyaa1+WiAPc0jTnOt+wNSQupDOwkDQr5wVxov2wi0Nhahh+ygf69tBFobPTCUOuU72ibl6ICFBRGfvs6wvY1a+cE+YOjBY1wKZEmMuI6CS3cYXEmL0zkMcDqHAU7nMMDpHAY4ncPgOZu8NgyS14ZB8tqwX//dMPhkx7ffDIIxBsEYg9qTdgz7b1Cs9sOPe+HHYfix9tvd4ONJbeiT4NNx8Oko+HQYfDoIPtXWZz+5f1sdONRgQ/3Vaq+hrmo11UFAGlZrBZ3VrAc/7QWfhu36poiE9frmyenu7gP1zZOh0zfNNBvrm6t0PlQ2j+R7iyPo25RGFc4jUTjj1QV1pXPdBFHFczA83PWaZz2b0JQyqIaGldKUg9LMzGR3cA0o9+9H9Xw6Bh42XriEVezKVmA/Hfjb0/GYqg6ZmXOKBqbsoKswn2EXBv9aHChh3dLnBvr0NMa8njGjp+R5h5Ll0qMovJpSMWd+M1M8EoR5DrO2YP2wMlz1c/hdSTlo41qChMSV5S3O+AUYNcklnmMJPKVMIlgDOyY0x8FIVvKbUsk/CLwgQQHtdZYa4iPgQNBs3JLxRVErfet6BuUCO6Rx9jWCuLtXtJT3p2VG1T/yVi9TA7YHa+FeMfQQddUw3dfDg+B8FB+WKN5xnj7VtWFklzKAKBfhLs19M7CpX9Y5Bsav7nv430i3JLfGH2tBd3ZtYzCMUkoXtoreJhpoBZiJn44NEo7mjWLkFxUSQVJHHFBqz20x5zjRjis5XND7D3m1lCl/dwEXBunA7PqZ+gEb3eLdm7VvKHnXxbVOKXrSmNHFjQ1cX5ChIN5JhzFAjVZck51I+5LwWOlu6SKaoM0aYeSI26TK5HV3gAXEbI7hHnLPFsWh8XkQfv4vq0N2YpN22q4vDpWeEXckskNmqI0ZXVNAbqKhbMT0387LKtTUP6qxp1vTco4ViJ2z+dwU22peae+ZFY1gHwef/hlZ0RPTxyGtEu2zUZ+m8xxtB3STdtiMuCo+PGwaKoWfUSb3hPJ10OWKzK8+leAOJZ3X2AGPEjwCsU1ANQgHg5s3Z+QIm27o0GPwl9UinTqUvAkOyEAyQRcgYg9j01UWdgEdOf/j9auvv9Ymolpj1nw30+qN4pEVlf0aFNJ6Dm+jk+jDzCXX327ztnhqcdp2OYrTuSU8+X6ebRF/bPajrPWIal/AivZ6fL5xRQ2PENgaQvhUFWVUZB8Ub8g3iGvmDa9sBySHCGS2w68AXxNg0kPI9vEeg79XU/yHKm1pOxl2rLmGVRP+ipxJWMxBG/mw3pe//pXapNYEHAQm4CAwAT+NnbvKqAxt3uFmBqc1hulj+O1J8Ok4+HQUfDoMPh0En/aDT3vhhG3mb2DiDoNPjzB4zb/3g/XsB+vZD2baD8bbD3ZuL/huL/huGLzJMHiXYbDiYbDKYbBO9a40DfEDNMTh/1aY4YODZLB/ujc83T2smeEH68zwfWOGyyQbG+HrbGAwxAdHzlAH6XXfIxU0Zn4Pjly8Bx9MXvODgdHdMljU1D4+MTGeCzAuWWxLPfFEdGGyK5ezKzDO3nEHoat7QRrUog9N9tAQs0C9aEv0vx+L+y3nREmGqjYfJiy1VEDApTaEYbBSzcDQul7sXK5obfhvbyaYhK9XL6hnjGDUBVmoC4eNRMH0m4Kj7dhPLZ3coY4jCJ8LB5uXI9ZKfn2vyVXqCYf37HMAC1MnOcRPtlkp6pcenyYKyiIbrzKTyovULg9DMq6lNpmkJeu0lVQj49iK4CWVgdL/kVblqjO4+zStwKV3oQm6tQTNeouUdyWWyiBskjzCWjCyrmiQMEPhXrLaZNtcgce8h824nCnXt/DPCowKmwVH7rObKVlN14+u5uUINTSHsChtLYMDeg8PM4ziuUwdSVE7ONnvPLO3lfXHm2WO3dvSZ/F40y7yrRYW+18hJbcVD4kpNSvdmcJc4t51kTDHlMPmC/X/Pwoi62e0b0chRR2GHw/Cj/vhx73w4zD8GCoAg5B0T4JPx8GncEnhisIFhesJlxOsJtAbBsEnu65Qrwq1p1BjCnWmQbCScL5BsJJBMPsgmH03+G5XvovqN8QL1us3h6d7ew/Vb3adfuMm2VS/aVE3UKsZyjejadWbpe+jCs1QFBqQZcm3+EyoyzSGiKoxB8cnXo15TsWYlYXNFOAzV9Go+b3om+Hyydk95xr8/SgqGhr4Cl3io3I5veL2rD42wPUA/NdAELt2uqHD+CotzaZ477x0efNFKiN+K98JjX5Lr8ZFCAuDasR+H3RwIlQpQrxfFaXDjvQreFEW8x7SHGEa1d7C1Lss4LEJJpOrGsKFxnmAPMhpJuNgSM3PqQhAsEfZziHGACt2DDPlEoEZJ4qgqtZ4ZI+Pjr1Q/i8x7A3CUAz/zycZ3YtY1r8fysX9UC7uh3JxP5SL+6Fc3A/l4n4oF/cDubgfSKP9frikcEWPtOBbZeRDrXD9FI4yDD6tkrurpGKbHDxkOTg4aRWEh73hbjLYPT3YPx0OaoLwcJ0gPAwEIc+ysSRsCCsUgrvyR2xykUZF4K6IwDf8RCgAaz+Pir/DXVghu1urZgjcR4lpAqlzEXNRulZNuLWTVKozLij3/MAcJvxZsk29ObAL+HKcg9EKV5jM5mwx6j8Jy8xqcLVS9YKg05xzXWY9HtyDD7qQWmA5wl0FW1YWQBE5h5vLa6E3CtID6IWKa0FgSqkvs5skr8eEnfnre1RU9bpGlN03mCRf3rOsBhlYLhbpTdfvFe9NkCqP/GsyCSfDl2sumSGfcKUVVhQLmNlYB62H36lrrMIDte07dQevTMiWESqicP0USHdo33ZlLznIEDVRBwd7Gp6Emz38L2moW7FJ8NUkOip1yruGp59wnQOey/UkvUk6Lxwt1x6s0XWHopf5zawoPYyntwQfYscqijmWiswW9fXy3aTrgyEppSJpDmcgGv9uJT8dms13GzjlTj8ehx/D+MYgDHAMwgjHIAxxDMIYx6AW5BiEH8NVhYsK1/RpQi7tQRYr1FuDCK2KxWMVhMcYyocYCECOtImCMKhbyqsVhKP9IxsJ0Fk2VhBqwhzVgwP5EzDiHhf+RnWEA9ERsCr0lTwWKgqxgeJ1HaCm8BAh9qfJmnLCr598r7bsj2/N5MlvuGtJTDLsD1UurIy4rfJ00E9bz2+vN9hP4H13D0/36wre6oTKo+HucDgwJ7j7sFhOdJMxkRLWaerdgtKeaBYl/NvCZr4Jng9TKFcOHT3gE1REScnbupkssy3V9RhnAYFzNbdeYDgYvCYgBoPDaECC//qXoAkdbjJQCpUz0U4TNux4R5jtjln3Tocbs8wKjht1ngV4w+kz4uaN0fUIm78G6uNqb1CF+MUUe1Qg2wstgA9QebqM2uLCCpKXFuJAUC22H89heJlmfkjEPosDPgQi87Uiw/g0MK+lvcsREIFS2xvAqQGgOw0lOZaJjxiGCiHKNvntqmCW74IT5FQE+W8GxsbtZvI+LXPRF7kdkslroTH+1yyb+x5PBnvfdDkjwY42gODz2d+fEz4ERlQmFaP05gTmQJEXThx1B+BafNbAdflluEQtx9xEarRDOZ25tADD2SmAaXZMIpv1dB0a7SX10/DIdgiwMruZhJDITGXc70LRsdgvhvqMVTaSKKc8PtkXJXrPVXP+igjJIPQSVAisGJYzDfqISaiPsUFywVFV2P0qg6/HmCVcW5AZGRM2w+40Mk0TuB7ddNgPEHfgD44k/IBfMZj1qSfkRkoXKvmGxFCllEZKrLpNUwY0oFIxKY7R0dKqlolC8KCclwlvEVmHo1vpHYOzu2gmUVRR4Im5/mp06StBedKYKXpVgT79+D9omQrWxtcSqUI0cLQWTrGHC+6qglxGd4fsP94CJKKeHNi9WkYCtW0AxLk7GoGHO+A5hd9xLffoJ0h7v/qVUth+ncLcdmGLFeyQ49DeBEL/LhXrLJ2Mlpr8qsfGKJtNOku2GRbfN0qh8HAN3uZJdIl79SVy3le952DcUm2wRuF+gu54XZShlHgfoWTJMxs5HFGT4l0tr1DSXmUMw9zApKpfsPbWT/ZuSTL0W13Zc0dHBWJaoUWmx4EB/rRcPKlPlMamas4kUyTwjpQQt5yZpGZucdAYerN3QNScggozdYPr4xCgG0OLbDLgV5wVEGMxETh5ZBDUGiFTuBrKfNS2YlvS54jImSAE9NY0ZadEQ7pBBW45MUxMkFciK6uxYc/2pJ2WsBp/ZwI4/Fo3oXBo+l3L8K2X01xJ2S8kaoSVAwZSsTfFJoQo54nMLw0UUs/C+BIScLdsuGuzgEULYeUFSivM1cAmR5xXWO9JVttJ0svUm+C7Ysz8pD4rl9+t2buF4JPcX/1eIxVk0/lCE2povMgiPilTjIzv2wA5ll/dT6+KCc3gpZW89Za0KLq6h4sMEmVLSDXKR4etrJ42T7EwjFgUgCoOjPGyfMcSpU54rbxd9CvocVQoOHLVUk95rWtgcAsEeZb2PaQi6cnQmMk2HxJCW+neg5qH6Tc40JOVNxHdeVmbCmL5O8NHO5Wf3zcvR8spOr5G8VvpfwsvQJlgMhU2uqSsEkLGyW4JHgn5Y7mkmvOw/1mYPgW0DRZZ7K0Wxeid9orDncBFMs7bOu0q2FUeR/2/q1lswB+YS95zUDu4ma5VC6JjK89r8ND6kccVK6JQPu7btEI0eC6eBqFMtW83HGq+CwQGPdIQ4wYE6zTZuhtNJ5dyyJesG1wy1W7Vf1lxw5HMlQdYUiF8V6NUoN1L+ZI1mzHU87Q26zHy9YKm/B4XdK6kvdff/af1Kn2LKqDIDshJYDAWMMAJRgGHc62D8Ftkh72QVcZegaYymkYP3v3UownpPfSkEeVfg7gxtPH7nf2cfkiew2KF4f1pmc4WwLoajCiQ5A+cRJUUy8qv5G88DW9gaE1IKUlxc0NNnrUmLsQB3cBYM4sizLUxGr6YtHhRLEvG2M4ePsqyXE7jv22nVEpGdRqgU2RNBl1NmcBg1002Q6xXvGuYjalU5q5Qs9rFn9w0HSOEVv6nZcz281xRRBLDKqvawwezvEL/AE6/298d+FHepLWSSqlmdQuM9bthZcQViYGEFpZpLDcHJGHDThLdUimFzEQwfucWT7R5QRpmkqnV6Qrfo9JSgrlERCwuvEULStk6sVAGaNs3/K/REz0zxtVtTMP/Fqt4TSfRmHeq5oHiqWDs2S2+Ihf6AuOVVnShLS1GOQ4dmsh+qJeCIxj6CDDD2T/zakqOdyypXqC5JkXBtS5eTNdy2Ocsa10cKwwjrmqX9f3L8wvGpNSfnWOm1s3tAp6+Qzh8ajQNtPkLfhBXbJtX2FI5t5t/JdBtpffrZtcw9IJ0/AV193Adc1WBtWEwR5Ui3NRLTpLG38ICeBi3OJ9oznqCXc71kbpvgjU2Tp53bfcWaomD0rbMqg2U5AtDQnZTyFHoMe7QdYKY4wTxmBnh+u0Snkdvg2uzxtiSTG7SUa1xrY40mmduVgwQ1ixo2D8EI917urk/K+IJJQtxITrwu0cZ7THRvx3qt3Ujs2lgxnTkC6+cxdXlULv09kh4ehGJ5aaICMvkN/9t7/iL5GxO2jI7dLBJKszyNZmEL33Xvng5YWSePxZY+hl6ewLrexbRyEKFrEYGLc7YNHSRfnX2/ByYwz355W9gK+/S+8C24joYowbnMwkvENcpp4rYddMQt2Jwbagdyv60vE3D8Vd/m9w2E4y6606TN8VkkmfudYE2botxZV0idbthS37yln+i+Uhu4VuhilBbdMMV6MnK+BrS5GZSXCGYgAoYeAOCHbu7xYQNynwJXRcEidkkYIG+h+tL+i+nzLj9YD9cEHhYd5dXn9SpdYFoe4T7vN68LW0yWm0xzP7vR0zMqRJuP7DfAnfP1r0EztUNrgtaZjACGHeuZSfIrmJWf6ix1ld1gG7t9im3pfK8nPBkb7B5dVkzzXPrAldLkW1CbmzEv1LMLqt+OJb5SzHzWG9EuIE5qeVZ+azO3ePE2fCvKB2gvKFMatJR2W1XzCUUyU2Xkv3dfe0Jzp0HJdWMUjrDUwZNYUbbQzySVEuk0MpuOjfea2ggQap5rdtwO5sOfkXt5hry2njSlMdKqqBzOsQ3rWHUBe7NuAISOG6YwubYwMdZHnlAJ22+04Dd4usI9G1dv2ikT7Y5bJ2JnL7PxjHpijGlueqYHQqg0SXzb0b9eqWb90rfWcfN5hhtNuE+5RTCsBsWs4c48zKcir1Cnjmi0q8MQa45TuaH09wttGJJf42Y/XYnfQMZn7pH6T5OH6YoVjhKGNNyDV5XXpGaTJYKxnyWWlgHt+vU+oHMNd/vpZX+xfkTp+bdNhbA4bmaYR0N/YlltW068WFcEis1RJ17iNb4JpuS14xcqwgddUOdMU/rUQ5EGB3dInb13N9i3w8OuFPLJWLdXspFlCS9uFcXiCj5Pi7uQ5qYlppEeVAQAJHhKpEZr2x/Y8/SVwdA8tZgS4wDesUFFflUOqmIz0C9gUXZlbiKuUksKGmns7F7d13aGCNSU0KzrzNHO/8r+/bdiES1iRg0uFfH4Ry2ML0B7F1y7G413Kz9JhFZ3aMY4fk4/c13m6e7Qb3qwx41iJsdNKLfijlHHGxrqN3G7akLbhrxJv9AMvoNtgF1nqTm8lHKooYq3ozUWzCwNjE5Kczk8wAcgEu9Q7PCx+hOK2Hbpu5xER+64M16SPnFAHgfFrDYSqrl9TV2l6e1BYEdpqEHXPKwYZv1s343i5u0Jy18Snwduu7gCkvKmNca2gKU9bEKcqxw6+qULxQw2hF1dR2r0mPMBO7zpXhKNVMq/j4N35eNHXitUNWJ1RKewjOuy2KQzraOZBtu4GTQPwFeTn1lyNlK/Cci5aySztJRheVjnQTnnJnAPjiJFuc3sx4o6deZj5rp8QpvHFKCWN2V9jETh4wFpwXt/uaGNPrxsnSSopYQti7g9rXbz03tndq6XHSua1z1uEOyQTHF67FbItZu8o0Q8akQuY2AeENnxwEh4aUoZm5vViU1eeuUZseOZI1kA4dV5bLmvIV8JwZ0NrZx/JhU9uzQZo3ymlF0lA5nqnOeLYweK4fl478abuyoWiwi1lU0tNm5ftfzyYpYzHLyLjmnwKZBnqLIcU06UiWFU9/Jqoi5x+BV3ptlycFRc2LeBLzXDLwJL4Oq1tyEkFs0qEX6QXCrOR9C6SDuZTDCxaVYtJyIdxjki5WaBrZ7ylNuhlktGa6EugNlzCpV9y6zawRil8TMSNjOAUYtpHSMGHtB3gTBvpOcujzmkYzz9qM1ssqJXRUuIcMhO9XnK9OLfA2rpQsYDWq5kcMe6gTMneKKqSFwQqFgzCRc/fvWdKL6z8xvGhacZnkl29Lu3YdO6kfAaQQ+WcYRjiFojmdzDJw26BKl4qV2hvLNmBr5h+QMNvZaFqYDh5nVjJ6Ifv/owTbc6uLkRKwXDpxzfqu3l1w6RN2rCDNic8PblOJ3pY+urlJM2NiGO+rko3zwpJ3OgRNx7p/3C2ngG/OAJP1HO+ThEWnCjBTDt0mOtWHXNURa13cDt5KApBa1Lg/eErJwrMaDsW32VcKAe/3BP8XyMo/akpPT1e4AHNX5AYChAvVhM6htvb3m7sZYsGoFHqyYjMO6KUSajchD/9Y9sFFALv4j3tp/3LKFfOTiJUMtMqfLyfH+UUbnJRyBxYINbC57Q1Z3hZFJ7jI0Viddqm67ZNuKKDrz0+Tk8HjQ1PNqhEogyTgCaBNv8YKoC70lNcdcF01/tMmRqUmPFJrFhJzVq+BABeyub+z941u2BU+TrbQs0/utWqqa3eVbB9WJQ0Spam1cwrhPwnAESwK33w1X+nJ+U5JAi87bkmUcxHObacSGD2873xvR4RPQC1I1Iq9BoRVfTsx/vXoqH3hNr2A3KQWA2PN2izf/E04NO6t1HmADUQVnFc6rls5neN8rimsjOmwazqkmLge+HzE1VyU1ElioTMisqm24etAqkumyueJcEQZ6xBeIl3Rcgjz3fgqHzI0DzZdX6IyIupqbrrOIHuKxzshCpTyvJ0YNHs1I9JVFVW3kTxeQPGyhI7kbzt7iZqJyoPTviD8LZ9b2gZFsSPfyDavAJ7IG4V7iB5p8GIXlBRZCqcAj7iHOujbXvo2Keb7x69e0pLpr3gUoTLlBILL0fD82JmBy2i3Re07u+si2qh4cN8eeSdtNDkoyxj+B6YYxIU1JlWS0XhazS2fOaZ5ldZnPLklXoor0mRfQ7tGxF/AI3eOEjbFJQ/bdCL4Jj3H5r/7ikv2ntfJi+22Dag98MywHWXX0Dy6X8omBYTog0okDK766byS2RxJjHzx3JBFvO24tCcJidsdfjeo1HKtUMuOmx7NdFDhsLbAeXBFz29RXbpQF67TQRL3V+dbNAKFjka7OAgsSK9TXlpOsrjhdLylXUn4Ur+dw+mcOagzfXuuCIQueszyc/slOjbpNx6dUT1QQpoUJhtzvVnpAe9smWv5CLoJgb0kJws3X5BLHY4LHvKeJWqiDje657VjqZhQOsdAec6B/ztNYMjo7CeSu3OZz5vQNd45phm3l2QStxbiok/qAfvTqN0LIz1vih1EHLb7hpqJcVVEwaQumbGcqt+qesSWvVzXVMxiAuTg7rR8kaplkCaQ8l9nH5h+MIFGLZNtU7rNt90+PdS5HuJmg23hj0mSfYcoAMgBs+6pLiHvLjz/Bksj0YgYGM2WlhCtUE5D+r4HTH8uRHrc2Mcac+9rgiEa0gmzG6cBqkDWiiRxA4lAVhx35UbBzUqyKjj44Lla5SDcv/zM1XcyySfj6nAdkni551zUV527n7u83KZfSxpK8G44afAmti8GxEOJFBrryKIeOKVhmnwpoLysRhIc8omA5s4+Z6w5YD+5Fuboru0ImpC8MqsGC/Xwulli3bZNRViKrbgtTeHyhpi+kNW4XS5p2chXNoWYKBgamQZtl3QmBDsOixjWJGUFoJKZXw8SX7Lbs/1xx30Nm2amU8zoYaOwASoqdNuBps0/S0IfTNekEq5SGMO/Uq47k1vc1sYEICQZwP47pMop4Ig8ycJcPgzuvqlZo4DTvfeci6urDGRz16oX2NNNAknuNpK4TsFKDOcywY5JTkCYURuXio7YoW0QCHUYSr7xWuZFfneNFszBYKY2UVP/Ylg7ZMf/hYSRbxm3D88DcCR0rJqyFeVaStQQaxjsXZj9HW0/S97akQ05ks9/6lKC6xcY6m0uOUaA6TQYFSQKywnOb3Li3uFxqHmc0W2DgzdlD5mlrcVckHNJRv7VjfU1PN7p4qdbun/zyeLVKaMtyQk9Epq+fcXvcuqeiABfnKt+csLelvijnOeeEBl5Q7rD3+d3FJMGFzb8iqFbRUoMYXETbfoCcwwW+zcbjSVq2+dARx5eKXOlXWkocEJ8t9mua7vUc1GpTjltzYUnWAe6KpFksQebHOMS5i/+1+JNYxZCwyPKm4bdK3Qs6fbs12Y3oFBM+Yr7aw2Yaib9atZsbz98UuJKAjxt6jwCoiF+onlc07O+LjRDZMQ9O0gJB4gLnJuOr4d6VLl8g5YwtJhd22pY+tggyPqtNnTthkpotmKZL1oVV13bTCTWToSKmnTfmENyTYhZB9mPQ1CGWtBVQhPsZizCQmOheKSjHBr5+8fL8eZRUmtVpUo0L+jm+GQIub2C2YcvTD8l243i6Pp0jJtZfOf1OU11x00yOIM4TrarBKJvqEZN7yeLBTg8i8PDdDmJTtnBVhyqq8aFUmapnAVIU2hUWK6ZTozZe7ZlWwm9ZQnAJ2C8rK2CO4PMUeYVNk5yfQxWJH9l8bjeTWgskBDF6pnc9EIQaUF2Jg7Fqp9PGjLaOo7njbhlzj6dhqj5WrmOLU03+eXG/JU0vlT1PCmpdlzeMGKPVtOcVHzYdBl5Rchx0E6gFb+Y0BWs/yfo3fbRFkj98+0Ix8PHfpy9/+N51Z2NzCKhmb7e7u7t7OogdCLmjPEJKCLIEOxDBCLDi1ek15m+L9MaGJ8P9ackkqKVlej0W62s1HGs17iA67YPT0Tkb0e+XYtrX2acjyZC/ibenVUkzi/chZNpYKaesJY5q/lajrsndI6Z2UOciHqXIMs5I0sYjU+TKAAHgj9SlxujjLB+6je2os+6ITEZH4Gqd0V4c7DzH3i5UGo2vAIsu87GYcg4QWQFu6GvtXojPqeLGtTS04+iDEZRktPNWgZydF9OWhH5X9I8nMysMlJliK7jbG1Nul3OOmG2W41hXK7fpUtNjbelPT5KIXjzlTLY00KoN0Nx5NquyPLYPxAMFWuG+iUFyxwlrlNeDG6N+askLq1XYNcDWjO0WpgU30SRqhWP8fTwo7Eb9ht3xZ0bti2S55REdidpwRPSOemgkKFwO8WFqs6zK2MMq+Q/wbLKVbhFrJEVdkzfrkCMRlA4/kq88k/gr1nx4RTASpo2WjLRdCec40xK7hkTwqv8qKKeIcrZ2v9WCM4EkDl2IPlwtp1MUkw6WzuFBYFZVkmsNgNcYiWlXzreuUatFQSh7N/HojC1N9YzIcDDSwWR3ux5W0tQpuNMl5EdSkSIT/YASt73GpQFXZgrn6hlEKbtMA0a27YCLpgXX/j8JDH3rrMxuJQy50bULj43+yUX9sFh0EArkQ/sNX+cVCCKjDZybmjMSXYAf4CDQh0L3IBWRizhNLNBQ/ZbKJ3Rgs9KYcwAX3WQjctDjZIyLgMQM3LNI4864dhDGt2lZZXw9T5GRYuIpfeomy5l2bk4uLt+enb05++OrN5ffvvxff3jx3QX+O9kOS7jJ5xa3jupQXm2+BerQoHxgrih19SzCOohcv1XJWVPQXpNm0b1r5G1Z9Wm9yld3YCIIL3fTJLq9aNBtOHs7ptqZ55fckpB7QKywc0wGfjzsFxODdSgVwWxsA1sNUQfJlkRa3hTczAjG2DyRKbawBbXsxJYD8Z9lMWl5wSGXm8pW1EXYl07RkBw154SAxLTM5AH21AaxwShnGgZhEoZ+GafV7VWByq7UPW7XHALRW4ZzEspROqbOmvnYZ1qn7PLAOZ0HPajtxdtwN7qEyRxYGempLfNsVeRmdj3rkXXOsRZByh5CJ7NRaBSyJLjksftrlXGnEIBaN6eCg/r6gxLMzcovo2mfVToDBvVLdslJZrXAAIz9Ah6obikW8w2mv5rDf0NxMnxPTJVk8OzSVyQujJub2np4CngOJ8KIQH4013WDiZWTfzkEfycQH6LLdlGRELKSrjJxzF/vaugnKzbEBmGcbVur1+S8XENICrAIb+kJdShpH+7plEOPrJj7X3DmMLzqwmVuxzIxDpuZGLYML9YpvpGfxXqVSgRt/CLpCsPIruDIqCWMJGDF3eg8EAVDik3CytMVhZ95UOjpswfzcaa2iwYH8UyzcexysJPaGeMEcavchlNptQqRuJYDGgkexFluilnWT84Q0ojUjsAJ41KoZL4y62nMJrt140TXN4sBjeJ4TLlzRPxxR18Hs2ESZnRQCig4/Jqo8RZbgNGr8yDoEgMHNWG+NHDjueyu2BRsH+EaKOdAB2T5KtAq7encVNhjshGq2BTOb9/IrG1lhOg3Ea1tVaGBBzdwhDnHN2kKhkbIgvE5KETP0CXUFiEeFAmiMs7yY9YSZdQJN5Fw3qVKy1xQBpuKOqLy5Sx9D0o8ztLvtIkQl2uXjO1+uZ0oZqHjyQGXehO15utyXuoV+R5ntbgOu3cmS3jB3Y78y/vB68GRSEqmG/lNAYobWgJfg+rhrV9b4CfpgQ20y4bNqN2TouJC+FCQSc4pzgxkTMG/KJuOR2IoeC06OEYRx/nCxRAr1RlagHEjulc94/4xkbD27X5rGzcbOKHT5Dq7Q8TZq+RPy4z7XiD+BexiP/lhjlPv7/4jiNCKe0TBuZQ30s/E3PDzGojfFpLSVlgvEwP2w2CNTVL9zr0wyQ8rcLz2SaW4RVmn5hanimoBDOsYBq634LrOMpdf6akFll7MeywUVzG0M4K4d6kG3LBLU2JiXq9IZLABlIm/VbDOuknpilljq9l6NZPS2q1atFMNAMxAsv3sJVzkXBKkZ1OzhzYVti2xSdq6c35T7MfnjD/5nUBcMoLdc0wCpJ5IlkcXIbF8x57OFU4zNg3xhV69/Ra9Oq6kVtxXXvJ7A9e78XyIXCU3RT+4fiw2p0kmVZekhYHxFcfrAGF+tLGUhmpVc8KLitUNqV5r1jjHxUN76+MxjnbQDMbIkrKxyyVKaz7dILurVm3SiJ/Y88OMofd+xXV2dwFqcjzdzyIWGVX2PANegA9hORsogAoWYfjIG8UNe5fdJ7b30+UIWeBkko0vSQW7VDW3ExTi+pFekltNC7u53okLvonEeB80DdznjreVevNZ/+a/HQ8Hh188Fwqjj0dfSN4Vkn+xguTxiNQxk16hEqG1tTy3JOUSHcut1OvfhKAPo3ncHdqm/oRU0+Z2I6pJMX9Ren40OSHZhDGOV9vvJh2+xdj5BWGhYueDimXSfmuy+EHTw2UG/R7Ir5QMJes56/wRlqxGG8WyO1zzycK09SS4tgft37HBMqvLu3hGSPurRxiMMhMxyKgKBr3pq7ZOyrpSChFqRN17ydsj6AdNP90a/JZhf6//IbqW1h3HzL4Ov01ardvn18oUR8VkOZ3FXU9NgLLoWOoDpAZfjq3Fa+ga0MvJVpX/km1FB/661k/UFfZRmqtjCsgByZRYpyFY7NaLVmL5bkZ5NphTvrhFJbrOuZ1V0Q4IaWnv1qjhIfDNyuQzCpw1kcpa52godiGG9LZm+rOmoAn9Pp//iW3P6h0UkRqCICEvXAjmcQO/RCaFfBMvv2kxNRcJwwgBru0Kcp+4mw+HBC2MOi6jUN4yPN1kPot2F2Jm1VzDgtdds1/jU2q5Ygzcp7XGTW8BEFbTnYijnkVKsFIvTAKfiEtDV62y9dhbSgRszNFmbWiI04EdSSsVV0VQ76YSsrE2tExiA9Ym8lmwYgdh5vhVFAu4oTs1q5EcJqQ1+mIRRjTpzJlKsbUB2La46KMNxEmyfe063DQM+66a5l7HxPDBk8YKjOHpcxFqWZAzH9gSTyWlJaIOEqdSNR+aPgvTWCKWACsoG1SQzPFcVIcxd9o9aSjvyZrZucyysQbDyTBoQHYOPbr9hN7V/RG7HsjfNRphgnqCDp8UkkIdMaRwNT8aEmd8AtM1U1YYxv3lIqDHU3pryk1gZzRHitpvXSiZtJpKerK73us4ZQFMvsyBDGaKAqHicFVJt2dDZFhjR0vXMYz8zCm3lnwHXzh7GV2GjlPjg9mtd1506yUk7FWX9qGr+GDyM0g8Ls+pu/2VzYT9fIwTlfZ2hcximcS8YUXURm/t2q5gdtmfjnEzLo9WTVCg3eaNCPBW3SPlg6rwSdDQ4AWorJYyghzEYCOprIXKrRVYLDRJwTGfGqTe2jHKDDlszafRqJaNb4oxtb1dySWpFNDuhnJGazRmyVb2YU7loRUjW2wJTcHdrkJKDOWAD2CUN8upmEFlesfdkgQ7KiJe9lfaLz4xu1kJySmh6gn0b9nOGsQQNRpLzRatuWUaqgr5vaVdZpwGzt399Rtioz2YMqhCQQNAnP0jULWY+9ZiWJByJhY8+8m4fFXYZdjHpC5VWjdkuPvFHwShrh4mR55Ljwy+sAh8DSNBOouBkJ6Iv9Kp3xEbuEVg2agfx9HzkRyJaf8WO5JWy8el6bt4mK8hp5hhXileacTLXr+OQj0VUvvVvVIOOxhvCjncq0mhZ7PidnrHL2+XJxaqLdecLrX4cu1CM3HU1IwFUuQqesGa2Bcj1K0Kib3G4q4W294HiMJh26HZ21TpYsp+QtdVeSEVa3RIzT5hmtW2ukcry1vUk8DshP+mMd244cs581fOqrKBNdyGAdtggs1ckVh/H+3Cx0khrpIm4Fs+ecRM8oNLtPVVLzbcIle+WZTU7p5km6zxItIh0UKhVBgu1DaWjXCibZcV2qLxa/6qtYGlo3ypfzV638ZDhQ1nDLCFhsqcy3JdDJrcSqxWCOfbevmB0kB5QyhFecuJdI6Lq/LhVI9+cu4eNg4RHqht1mbeUYierpqAB6P3Hg9+VDxCm7zjxW1YTlotSriuCHOCnXDnouB64MAN6wEtGkc44RvBdI22h/XHI7iVzCbSgNqS7Wbp9xNMogHRGJ/zZaxfCja7MiW89K3IwwCoXAUg4ykILq5sbQ3kXE8sFoSIsCBWhDEP0WTO42n11hSHOnzE3/y3w90vkmF/2P9/RKdsqFZr3ZpD69Y8w3Q0BcVe3fOCnU5kaVEfuWbm1lvnI6yaPw865HGSaPoO+7dRylsbufU10djMougQBBnQyEDDaHXXGPI3XANrrXvv+iR4UNgkoAaJLJBN3oDNRHS5Zj4otzRXFXwlmDj68TRlus6RNfYh+jf36mrkKs3Na9cjMWL+tLWJPE2+wh85Hir2uXoaw1wlLzRbcEuN0iV9xjC8Wrfu2eW1rgFAzCIOb1xj8iYdNZLavV0YaR7cjgUSmUBEqbMIknGREazFqJjf10qCwgqe8JbGGwOdJluvveVIRLAlWcJVKNSi+R/eSy3LDCpLYn1lTSU0tuGTNBRXNZKayqSa20B+/oaSHM8I8JQsQNcHM8BNE63W3llCqcUCC2qHSTNcG6/cstI8k2jiczB8kx4lvYtEp+a5BgmnmyBw6JE8x6OVQN/WarOxxYP0glt+tskOvRXKyL4EHj/8wmYk1bOWz9DVlGzZsC/b3HLfLrmVxFaTcRH/b81kjw9NPo1L5FuXeLW3iHe2PQHEg6rtY6Z2NOWwH/IA+sGoop1xmTIPR52lg0fqcOxk+85Rv28B7MKQUng9vAiQOt0Cb7Vbffu9CRU09TO1tkaPZ9NL21cjHTfJq6lc8jzM0NMUJsmK5DQmcePB1fLJWHijI1nLTfQrGkmdT6yURdraNvnlc8Z6SKQTfTPw0RQkZz7NDG8+gnJ6SzfsQbVanQ/ZbMNePW/0WKidXA1a39afOeA7jdL0mzqI0zqo1Lm3HnRVnsReWv/3//X/ZZ5CAj8PMhE3zJxprqiqe8Dr6dU9n8yj/mj3RBDf6YQDdXg/XIKrNDjKKlym2i3OjdOoy7goiyX2Pb0tChZokXaJEks3mjKS33fx3uRBql4xj4AIh1rv4J984oH/LTB7xE5fYkkh+ygcx6dHxZDwlAKnF+y5KUy4LcTj2CjiJZKwmQLtpYwBPdepuT3nsXB9pBEbjFREifo1UxqpZJFcZkvt4jeqYQiYvKOCMqbfczvmb354Rc+/CUPSRR01TJ9rOE0qLJRB05hLWtCSbajD8VBd4x5p4A+bC7iQOrC/WVCH27JlbJE8f/P68gJraE5PHee/1AkuaRe30/dFPrbNFLj5oVn1OZZPMWe2xYrSbpkcPq0q54tsjijUHKnhy7Oi8WJZA28c2LZ32IjByB+PEY6v6tQ6n0VJlQym3SGmM1GuLeddAIMw3OVFwc0QSFnwKhw1MfKhJsYWar6lItQBxxtNshQjcAmlJYmWBX8n7gL/rXAzTecSeAH8FqU+WqmBf1iSDkJW8kaMKE4kw9DfXZljY29veCAIznw66XF6BrfkpChs9gFlX25E3GvMZIcFvJATdNo+Lkocu6xAxJVM29bcmyKNmmgGyHQ1zxlbpFXWMPRElNUZTM3B4Bs3oy9cMW7yaDuPMKPlR+pXcjuHTcGOWX9aEsw/4g3Fczokv4CeIsvZVFuEfhqzvJpPs94kJ6G9pdbdbksDpxglMUdSwhl4IJUAdqG1AC60PC6MzFWVLUiUNqswWww0Jhm7nF4fOF8bkpqUVOVNtyAdNPvRxbfbDFxnACSvqVbAJ6cuZyH2gChBdSPtDdyz0tXPhlYG9w6gWw/0xVDorUqjHxI2TP7YU8aIxxOHQ6jvRT8Yh9itroYudSE2m6xG7gKekRuaMxTQu0q2CHxntGhpmc05p64rUSWRyfZItTO6pQMfQ2T8P7PZE630wlyBljhYe0nCPy9zoD9ybIdVnXIg5KqsX114o+fIRlETnmlsWnbix+eX5xyivfxdivXP5ekpSMztJ8E2fN3schFA5hPOAcclYBLkwbJjwSjOJ53Xc+McXhULQU/pQJX5hL4ps2sQS67Lau3gQfGAJZwh1SvtpK7zQeYLLBEE0CxIVW8TsJBOgbFrZ3L+qb9Z3L2j6k7DRWoKQinzlxiFb58FH0006ZWXrvhCeLHI6xlwvFPCx+eMSVZP4FTToCOCVjHBRmhmU20ITMyDB2EWigxP7/k8cdYiWp3F5jJ87/5CZWzs4glbvgTHT7O9dan3hOV6S2kEClPZkvm9oaWy+TGoYqxC7NSIM3Q3Cs8YZ1ipUXPzrMvWPCUVAyuPbLYI7ia9dRFmdYuLUpKVAzOAvmBibg8D+xa7gv4gacNsU9yCURBWorqntWdWDNw4jgug6pOXQvEDV8joZgwlsLu+Jij4dHFbr0+XHizZVIyq/ocndRpyr1xStp/x5zjE3ABSpC7+6wN+U1cP+Eph9k+knOU0eXFlg0HS5XpN5kRYe+aZfW3omI8/i4QVLFRk4C+qLzVzkTRjKlGOhXqB82tisCDZqB1AvIDsWhPCbC9eOG3MWYP/9GvT+qiqu1lc72hSTLJxM+cCE1Q4XSlw9nqDLiznq3VBc2vbrhnmTRr61Pv8VvvIOa9SIzrlwp/qeHcGkw8xwI9aeu00RHDNQBaZaqHf4VwiXgC8ogL/mjfTvL2yT3nCUSEmDaAii3xOSL3iC7sWsw+h4xsabFg0MLotKrxJockSmUCpg8u1lChcQFWOb8djRTTtJOv+GDbdeVFrJ+5hk8HzRbMLziPCscP+bn+4G1vkBuFX07A+IHyjuIfkItkqp66AIMC/nVuknQ3GaABpe/nhR226ieqgwRSaCwKnybbvL1e/wi9ZF6c7aUpHG45y0SQwYwhbtbLxZgrG4nUvp2yQSRc6zsFEqz505q6H5mc1rWaLczgTs4045cOgyEWdxiuYV+C9IYxrjR+qhWidlqja1gb7gXSsLSXtrZDzjhDtAlUEpJNJ7uQYI5f6X9XZIZeQlhlW/VWmiSD+1gGgFWb36mRib0DT525yrWoK2XYOJg57vAgpQLfwSfLVy4uzJg229oXDePwrUNNfozcO3YPb85ZGbYYwv1vpWLT0TjjexhRZqag6+qF8d8qZp+ZyVS2tPFsgW71FQy4X3AzpNhpj8acxcefL8dwNif6USxdvuDWIC2iwFRKENCqBuLsneqc+dJUUTc4jiQQ8+vninuAllOYIdEfxkPC1zsr0Kh/Vf4tKF/ZqtI7wAN2N7ffolE2sCpVaLF64FE8MV+raFvqZbD6fGdYknk8c8Iv6mfTLF9SAj2A6I+S/27wAIAe507Hpx/HzPy8xluKaBU1AsG83esnQogLLzaEHE5mP1/s/G1SAh9p5bvDe0bLoBN2ho7+2eS6SholL0VbXPcSMi7JXcadUGYJDPmlkMcpYJAmqeTGzPXWNslcD/WpkFEiJwSS/mTmHPmhPDDe0g+0fUJeSWE4doGJtGgBvwYsGjYUEtipRP6Cy3GaOsAfYwJjEw48mPQZP8BX7hNlH4dBzJJJJEIPe7L2HBV8bvJXvs6qYMNdY0XEYBFcFduZVWgapDCSvrYhSTKD2zSSQM/SPjCgNcLvW/9UDBRM5Nn4evxavGnjVybbRZIhnBR22JZRKNTl4lZ7YiLR5MBPOR5WQpv2gvKDhHC99GdspNumh9PWGNbQ5qX2vfd7DFGLW0LfVGZhq3B+Tn90EGMEQ/ZDSyp7UNh0ZhfSRYBszSL2gANL2PzHa1xO4zJjR53IOtX+YefXJiONCOVf4mXxUuJaYHHA7T6hOXX/wijwW1/d632E972YYwdF6Mip9RVcMvE0OcnEJpO0wl7B0vbW2Ptm26dw+uxr9bfgXmCbWbqbZa6bUXEaMV+K/MTJwPSnu4ppIllb38Vx6I+UNnHsYeW8mD8Qj9I2VD2NZnnAxQCpQQz5yXdn8pGhlZnCnCNVg7vO8KhtUmAg0BKMShAHGzIJHKOaJ4Ec0mr+HP2VHdKj4Y7TPLUL995QwWavwOUdcb5PTWfmrjXhkBO2uNzp8U7GW05/TD24AFk1JULBUO+sAvr2kvmtOqUu2n6bJbZldf9m5XSzmpzs7d3d3/buikPpI4LA7ev93rujHOx20OL/szIrrAmOonWcb//LpTvrMcMRXCH9Yq2iwovplU5zRHrCDK7VlXEvpV4OUH0M2JxozxhTXo6AiIaZXGO+OEm7DPqaTTBHOTjU4yR6wiJ9e5TUsSJC54arjENtjFGbEiwpgQE9UuBApEXH6eJaxW7VrVpDLon1egxzahsbIeLL4SyxsLGcYe0IrOESgCC9zM01pGEtTkvyXWcQLgai1B5EGBMMmT/g+E9jhoIP0zPgWOaijKLdORvE1DmE0w1KdM1+8mVGDe0l5EcvHK0gMIC7qRg0zJF+gXmJIWRvj1XOUMCjMh920gShpiYws193O4mgTYdqoVoDPZ0wpY9WnBjqeUuBE8LYh0L+gXEHBcPUuTl/nUnvvIOPZD4OZJ0Fauml6IcmQAW5+OrVeB5tZ4CNTzNKaCfdx0woztXEDZul7V1aSBz5g5xYNWbHazirJnteZr6XTBgt4q9AKDpVeA4gaWnIJ23HpJTx9ar0rBk1tIcFP8o5wMjA87R1udnGNq4hqnU/mUZeZ66gq2kuw+QEv3pIiTnJQSersa9Rz36ZVBRJ6vBWxrH1OlhjH3uliL63/jU9HPU3mGHW2xQDSvYI8R0DXMOMNWJuI7LlgkFDM2avigxFvrZcTuBAV5oKVFrJgGKPHVz7P6pTxwn9/vvP8/Jy5NY0VdIW059FQ0nB3QvaKywtBE+JUYksI+YekHKKi2yLs3CkgHD+Vw9FJcH9Xe+R08502QWknurIfnydhgQ3Sk2rm2CWwFooSJS68YzqDi8dKdUAVm+G5plSNfLjTb+mgie7Bl3+qVVp6YQwaazMdxkjDi/SdpAQuyGZluPStira22W+OcRoaZYhkJBEIIAu7WvuAVYqAoa/KBgDWSmH37pGji/epC39Jt1myCNmPVnH2GHV/MJDF/uACCKCaToG2hMCCNgBO+bKBCAgpnZWcqQWqdHlAtexDkV4+JOiSQajuGJZtRtEMvSp7T1jJjt4IxVWSeo07C0mtXyNBoEA3WYh8RGDapDjBZdCKZxG5TQ1pEKnkpbzDei/cLcrdVOBFB5uzVU9BcWZ2oxOJi4aFSlP0t7IzcGY9DR6t/zlxFRqidDe+DqYsBXOUN+aTQwIw0hpkjWrOXq2l/iGNimxRa/Na1p69i7SxEiQ3CsPOueosjA+ueHqzYtZbkeWFrzvXYKvLa/ClpRjTZJXplpol1dAmaDEe0WJOVr1O5++UL2BNq7tsMqlfUi5kVsDMKHZ1a3fJ2lh4ss36HTSwfbx4+1o7AiIffNIcoLKtlTEpZTnRNsfW39w6zvcZprBGOl8R5zpl75//Yx6kctQPv8vs7ioDdoWxs7TKs7LOCBy1m54ZTKGiFMUZkGSZMb9Qc35zPmRZQFtPD0o4ttAAddshlmRSZ//shETWz+7P2v2NPi/IRlziIuXaLsJV61AqMq9N6rgSGw5GuU7rbouMq6je44p9gNhhIC2zFm+LGD3KDhodOu7YlXzFxTDOO16PzUZOpQkzQbL8NpvMr5eTZFyMCBdGToJ871Vd8E9BfWBdwba3Ni8SOjLrP583dmTFwVmyzEJkxNykB9ctM6G15vJUsBovcYsuCd80+s1Iha21s2k0QumLef4GUfMkG9fDqi30FjGrzTuFXp9GB7iamhrLieIHf3/u4eIbwHb1h6Uz8Q3hEront2eF65qtltYTvpv1AX6Y9ypg+dXOcxRt/G/1520rxNFkElNhG2EF7MR91wxCMMxhmc0lV8iuw55NzFTBUb8nVFMKMy9AedtKfvj+dX1qL1MU+7sO+KHGNyVaRGOxNmWwZLYNM+kxREJpsQHcGTzgp6xzU0FvAJjISzEDhS9gEh2dKJeQKzeraezxbrO99NcUhQD5lvn25viDzhfV6dFpRwxl/HRw2tnrH/cP8N/7px0USfjP4eC0M9wdHPZ2j3uD4+TodPc4nSbfvLnAL/dOO8tyQmPBP9FFW53u7Cg8QtW/U62kX5Q3O+wL2DGFsT3rkujT9P1f8jkOOIABr8ss64EGdTeHn3e+yE8H8MXxaQe3CCMftD5Ya9uInS/+DA/Ai92UoLEt7jELuao9kZ6enP4bvbEb8fC08w3/AHu7gmb2JvgFPYx2Gz28enR4D9g/o6bSru3Bu50xGp4UdHLnGfQRBjN3TT/N0HtTgNQYkUSdVv1f/+rXv7rggRbUbII2uouZkFuIrJ4BZYrN+RSUwWJ28yxWZyxfEafT56yrnFPlUJr4Z1k7q/rJd1QxxvVR2MHnptDAZ2wol//gRuoj7kqZuUVrpnvwpt0EcVnuGwYE7urJaYfDw5OCTuboBChFlKP+gAWD+8i8SFf2NWOHy6df0+35tRhqCNiAAjbR/jMubSJsuGP8xCjIuEUa2aEa5vs13zz4j0xkau3iszuH78gtQ1dxda+gQ/TVNCVDrWvT+smKrO7hM7Y4Kd4t53YZuhUn4U6wZGwu5x9kPRMuB0R1RPop1M4igFFyr7zhS/+Dta2XM/Z6JWNb9CduBFcWRKz+lOkeVbVyOat8mINoGVlzaZxpGuCd3eyMM/8h8FXalctOHQckdBR8Ogw+HQSf9oNPe8GnYUiW9pP59zB4bhg8Z7/xfwdJYEbAT8PgEz/ZFALA+vi61KTA4MRIgYNksA9M7PRgL5QB+4deBmC4nZj+b1UafHl8fDz8jcz1pZ8lyuh3I4x+NacFTj+AX9g/9hZFMaliLB6fDHG2+cmAtbcNF+XpgyN4+TekqucLiXwXXLTJsUqiRAzxl9I8pa2kAxl1P/ljsWSrwwLdUYKaqQOVsNyMmOUd+u/zummAQXr8Aq9Shby1RNUU19HCNlH6NSlrt5Vi9pBihq3kst8bHie7J7hluwc1cjlYSS77g+P9gSWY4UOope3w/vxnIZTAyXCJpUZIKAMklMHuaYcgP1M+XfpzfnpyeDCAfw/pkSG+7H11KQYLTgm/opnhteSvl4JQ5L7l2eG3kqDmJtg9/Tf5ZpqW7zJkR5ejuf8G9vYWRCZtIDw02h1d7x9mo8OD673h3mh0sn+d7Q/G+4dXw3R3d28XZ6KDorfOFu7V+Iz4VelFYLB8TKcxcE/3hBH2gEJ7ToXrjUGDnRRz5P9y3LrZ+3AoF/zbpJe8lYSVMNmk9mt8VS2U1GGO3CghoQx3LaH0MB+PQv+q/uF1unyXwWlMnYZyKb/dO4j/dkfspx26izu6JIlMXWLKhDlToBdsJka4DrB1h0gOewcng8Nd+HQU7CPSllRLq7RMy/vahuEbkcrXS57XH4swF1kFXCpKgdF3O9xveTf4IBxiBwxv1MR34DYOd3b3d7g9Rw+jKIP+nAkXtojMetKwBywFuBwJ/zI82D0cHMsmiGnor0rL2yp51XguvXNjY2LsdA/WwC0//kl6LCXX1NlAzF4iLhptkmNcw3BMRGiScklRncUDRhsk6cj0T034Qi7KuEzavsTWDPRlj8ijRYs77ewyzw/ZyCVlisKWHRwiKOrpcBj5/hI9UjUaaO5IfWTEJ6AfwRfn5gvNCk6IX92H9+agjT5+m47HwBAplPzl3sHg8ODgN+l0/sXV8v4SdKgvB0LzQALZXcoilPkQ/HE5Byk8zjwN7J14ziFf9jAnqRcnjKMaXezvumvfTeT3pq9rlFrQ0zXk2gfLeZt0dHhgORPbE1wFl8iFJkoCjb1H5NXKr+z5o8jbP1lNAfsn+486i+Hw8Lh5FjiPqxC6FDhqlnzC6IVld1hAsUiENdM8ajkjg6M/9JjKSWmCw3P2uj9nuH2stgQDDo2MAEOvBLW6R4mkboaDxgMk9P4MbOR4cHJ80GCXsPRJCmrJoqqxSPjitf8idrSwuS/YBAnUKtfKCNMAZsgcEgTD6sEt7yEshoGrjjLVNoGxgqnKG6zgqnsP4qp2UyKcdO3WyH2wNAsbfrSOZA/31zKt2tRtbAr1vz9maYnRcvP9Y9gT0s3R3lr2xNLowG1cT77E7w7qkujQvQU6FOS5B3KWA/jT2cwzLOrqytUs91j9jX09Jc3Fx4SrhiyBZe2d9A8euzPHg/rO/LnJpVnRO/ZXc5JfZ45VG0qrs+a9Y889KbIHv6vx6Boh/qcz5uFwtWgeHu0+hjEPj4eHR4cPY8yw53tNybhiu4cnbZLw72qXkZWs0X8eJ/1okxsE/UDpBwZii/izXBUIISoQQa0XHqjnxg7OnmBd4BP7wuCuESYAc8h76vakrw9E11VGxMpnXvG3hyJG9dvFHezw/XV+vciyGT5wFH2gyj/oA8dfhIwO23VXOa39RN5Jvxrn73N6+90v2HLWL9L36Th16j6+jFstJerCimd0koOh7L91sWO+3t9YeTgY7O82bS2YSA8uuEjw9zP39xjvhq14Lgo/eUd8XQxioVTkUxFLoJix1wSVi7jC8DmssN0H6QtmHyLqwrrdOII/fV9MMn1jNYW8MV2rgnZVcezU8r2fGtINTmq4WusAfnywVusI3+DjlI69jfTw45OTow11jn3d/JUqx4G+wt+DxjHYb2gcm23Lye7ucFOFAy14vc7oSAqUDrIPPc02FI+jtYpHSNL/+XrHGpHY1Ds23vGTB6sdRy0GefuGD4/bVI+/s30erNHvmqrHxvv8QPWuoXkcbG53s/qxWs3YW61m7P+9COa9k5OGYAbKGtFOhZ4ekLrfv3zRJoZgzU+reTp79tUSa1MpyBP2UqQQiiC8awiEiJTA5XqYWDeXUiQaKCquhw8X1/guK4T18EHC2u1NRFSv3qFDuG4v0yoHAceOzS6D53EmLN2tlbvyGJ/AierD7dLZLvpvJJsjVzUqm4e81ysl8x4v/+9BLkc8ARtzr40dAXv76+SykmdDKh+slcqWejfewIi76lGW/MZ79UAPK8eeoxK1baswihqXp4/aob8bO37jLY4EFB4kTI/ahCmGTehOE3cD5tbjhJPPb9PHhS2b9MhFaFX69d9eCh81pDD8QBYZ0Cb8+Q/655gc3nd+9UUGROZKnhWCSWVMPkuuJ9kHToHCzGKMRWFqJGbfEyDM797GLeY2KoqL4MEOSGF6kU8WtvQ7ExHCa/ZncHQsD7hG0YHUpYITBZU3+0aJIQi6dQs7+p7S+e8Jq3B0WxRVRkl8T7Pps+cy2IVu/tMd+Kvb/RQBJG4mkiJKqXrwNa0nfBCRwLio+/HCf30UM9isv5H0Xx+sZOm/J6e8Uvzvywv8zy7/dzeW/wfr5L+7Gg0F4HCtAhDcnP90a/Ez6hAR99AaHeKwRYdo3e7hUZsS8Xe0y59Vi9j/XFoEpa14Ee4UB1UQ0rlTHGIKhQZK2xWKg9UKxWG7QvE31RtIRkZi8i5vrB54NglaUdkIf2PzXWLyd9mVZDuqbKx3d41pDckFpbEvy9EtI4ZQd9CK03a6iTBsNtvUrfqG6wQFz7WbKKV/VRQLLCedY4L5lEWmxNM+WQKAC6y26Sf7B3X9ZLepmnBmYcRtGs+nijDjhxlYJ2td8+sTAlpX8WkymDbWCSJO0k0SmPiPtQjip+AaYbBxf43hctDCZ1T/auczR6v5DAULW4ORJ1+sCUYOdqNPmGjkQFlMJBw50A1qxCP3vmiLR6oh1haPXGmJDf5zTbFGxm0kcWc1/4xf1A2TzdZm7ti5/0aqesTT0pa4oxu6JnHHKUT/+er60UeE0RoZTRF1nbMrj9ap64biHpHAUyPI/3SVfXDwWVT2wyP4/z42teS/BMN/CYbH6dqRiYaS6VkjMEtckcIlU2lxwQ8FNUv+t3H9vPF7AW/zPizO6yBENrmwXdOcYFTDRYYvNblecT6RaT63kBPRMqP9k6FWGg3bOxdgSxVGbJQ1v1Ia3gQ3jWv/pdifmgYtF/PlggFkuhY8Bt4iZW2UUHcmC8KNkFTioLcPNpqYEnPDd2uiNOGeXOZTKiKhfr+/5PNLqsQ8e/tK4DBafgXnkCOk2yXDy1wSZV0yNj3+WLD+qUcNXuiU4LdoewJ8TWSEcDuyPhg9o1oJ9iIfvcsWO4Oj48FRFGJz0x8jymYDJso09MDbDlxd0MSIyBhtiHA42HE6xipWosJeNc9GiMUE394QJEYTTtLBqtg+NamCryNBkiWBOARwwNje2zUa5DZbaHltMQp4HUnH9FPF4UvpYI4IgVKFQuCD1Fqn6piGQwjJ4tvOaTdbopiKEfVyAqxZTggKpmVK+N33F69D/DjMZ6cGgYzIjRNxewVs0ThJCaUPtm+EhbQTfUrhwrlHIN5pwXhqe1ftfsAIOPjkbT6n47lXYJ1VXeoaYyGWniyBCnWvCuyUpIild7f56Na3n9cqnSvuvt6Af7GtSP0UKiV900AcZ9WiCPZW4G8UBhERaMxWSSabAvtjITHvtkxCWOBaU4xVx7BnO5gruENv7GgqAs8Vx0zEsuagB4BwuAZvcPCMBfbZw9Zox8Ph7hdfu9j+C14h/X3wRWM3Qg6D7OeSjveS3v7S3swVHOrV1CnELz/QPy2Goz913ke7sY2hUt/KGuHN7G8FbBaoGFEA6crVIa9oCEWJ4Z6ljIoXdFhQUCN/UU2i4j0QOwNEodRsLlAFRs7gwMnX9DZ09+ViynKJuKTFnlaegQoJU3HjAdBfpzlhaiGGD3Eh5pDaE0AAEpCOWleBmEe4ERPTX8kRg71uxWQ5RbgqblAhyJPYpnyK3cLJlKmon4bgF0gvPZCBuFN6RVetw+8m0bv8ksAvEZ7YhQfRDPhgLpyQ7Fv8+df8V771DKeEYNS8eAKPxKeQ57o3troId0VUWq8YRLebILZK0JmD2IuDXFdILR5wFUVKGk3qaSWfRSVG+y8tA175Y3uD0PNKy6R7WiLcQck3dPuJa4JhAQTl9BgNsfMtyEyQttSlAj9cgd5pnv5BAAnlIH4k8mAMRvSrMniCIfPG/jLjJoSFZFLAzCW3H00TYPCM8sjoC9LIAztzljrdt6l4XY3CJTO0r3E1f9MV0a3za1IS7GjstEObe7UEptbLDQFX7RM/J4Gqs1GvJu4hmILmWunETkgwZhffcWz26Sm1wq4vkXn+hRbwr9z/HHEh6yBTgRRiFVRCvtw4OAD5GFObePkmMptcUkSgRzySlCFRbwfBILfDyC+lOBYYajargg7ZkYfffnfhMZpQ3V0lj43KxtYG8SPKaPMqIWtPI9WcVElgJDIaoRfoLGu1gJmSIW7mcpKW/BcMkIf57PQx0A1oKU5tYcWgSlFsVkHTh8ac/CYc5+CTqDTLXht5lUmJufe3pN8RmDY5Z8aSfYs/ZTTMgp9cq8lxfbReBZi4cwa8MPlmgoTdsXcaeeaCVdirgjoKYyQGXqztnWAwBxsKqvEL17U5Xfie93BNQI8f52PXY8GFeKRJNT3xiCnsz3nZE8o7qWlqXhzU1oQ/Wbaf2MqpUVPgTb69n9/iOTp6WFYqZML5Vp2UymyutGBczJDK5HVy6RrfUKbiQ+q1UTzwlAGGS4HU4X71MvUGpoFVzhR20y+dk4AcF+m4HUOXc0wRjvZ+ImQy6iB2mihmyGC4YlGGEyUe5URDeptgZLdMahoMfp+9T6doYrFUfG4Oij3Gk4matgX2Gm1qkc1VigbVrWmlVl9o2hFuPFWR+KKXBJpeMcwT/l5UZ1QhXMOVutq48qhHy7LStqgENEoEE/bIEX2VAEylNdGEoOXnyzbTlg0wuj1Nhj5jtaXxU8SdpMafKl5bTX4R6puIAvV6C4QpclfF7Br0T/DdBgiM5HeALg3NWFXaNUsNi4YfjMFeU/I7mIKolWTMjUnAYii5ER9dojPlIeSBwo7MpBhiRlnP9wI0uXhyjYksWwyv5oGguwVh5G7TMh1RBwTu5OCZjiMj7qomnbbIILrQr1Z5UTadBom0OYW3FcTwslNZUMmTVpYyDq73Xm/3uL7Sn8FCYI0UbyueBwoXQghoKAEr3EZqdoZWZ5MiiUS8fggqWbm4ylB0Yq8dvGGNoQWLHy/ZJEdbEihkuGv2c7VAQFNewOI87K53y1iJcQ22EgMglwzHKV0Pmm9bo3zq6YVnF1UzGj8HsxUImC1gAbKfK2aquU0Lrso0OkSgyNd1+Jr/zkHHpqYxMe+lu92iO4DunY5u+c2vigW+mrA25Jwrla1UWsLW9qPJ5gjWlPTWzjnBlwoHk/3ntHD6C5vF3uek9vD3DWLq1FemBjysfjnjnpd61MmOwKbCP4AF5oVzYGA9J7Y8BEskyjPTWWxTG3tauAgq3ZUVwzxO0jSlTMACNhHvwx76rHVZ32Z3p56NEQ8ia3Y7xMom35Y89cS81Zv056J0AoUhPEuDK2L1CORtY9dQkt0fbKcbf0inIe6JnpwzXI1T1MEu4WYu1D5FliLf4Z8vMenYWcqFJ4oW580qh0ZJS48Zz9ahU8lsXfdHVDQiy3uDKHZNs5+nRThJgQrv3M1H15fZB/JMEC7bJXGry2JGsZBLacdJNofDUJXnE/QnOQ+SXC0aEGjXDGacKtQ9j2CvkYzfF/lY6ZyHUC9HRvP4Dr/u1q/0cIL8xp5+hBKMUScbTOqai85dfFydG20IK4vcSG906/d/tRdK8CzNwUXVkedvL7jMnV3dODrpEXRb7zUGwk2syXzFbszm929hZwuxlATlLhjPqXDUXI97IzT1PFynmhcFOz7mZTHPMP3EOXPAdCw7REodWAi6SToOGpmef0+uUOy6rgRf60rAPSyFWeEVsH29bDe1umy0W02kMZpIqAc3Bs3xygFRM7o4IwigT1M6ctFKtWgx5W9BHqMAZO8mdpQui5rP5K3uQlaN0jkXFHADr7Sy/iKMB1o9Rht1iGU50aXagK2nh27SKDbAjmDOK1GJ6sviMXBtBl0+K+otwb9zREwyrhR1SFYq3l9uH8xKETo+aDPzm1ts6TVnas75vo0LIAwbgBYsOHraHs/LDxQTotvqyzKoi7zPmHZE5rwScsmbStG17EMVRg6oV1Q/OZvgqoj9hGqWE7lkj7FPgBV04h76LfGCRiePRaFMsLmeq3tqWIKDioIxQ0ZUEdDVdJpSYBpbV9RGpg4j6U0+S5XZ4WYH50C9UESbcXRyqq4hVgctHTE63pzR2F1wKrc9phcp91g5qDfwgSG+RbvGLElCl9rmBv5pV2faoiy06bQ0n6VmqN96OiMuucjFy4eVNbcYQP32nwb+GUvPtI/83rVl1lMaMgp57XBY3znO8lB7TG1YmJgRqS2UBiJme4oW75UP9lgt5lgxqlcpMge9wbC3e9S0QKIosratSdDca2Wj79hgzmjZ7+/bUVEoGJyQhmTa4pyFLdXnUKdGuoCxshK1PkwwUM9AOlOFmRgd/IQUEKN3eHUsj0VaaRPXO3tgEwe9wXF9rYH+gcbgJe/ZJcdk/MQR1xbOvF4N5Yl3m1Ecl9XiPBLkjThqPon9huDr4LHj6HKON1vO7tAqqxK+AaFziULmkpRb/USi/B2Sdz33Zc17HMJyoms8aubsxFa52xs2bHdp5sAtNsnXwBYOUYsws5w7rdFFRa0oVMzlXaslWXxpWYKugVyW/jHNSg6zskY4KSruRIJOtrZ32ej6wrvs1imPuL1IO7wBrp8EvoHw/ML+tUpAXKPpXHKgUxprtSxss2UNGluc1jbYxatQLYtax7VfYCNQWHF1SyHcP56/+vGP3wgHwpvd7FA3lvMCneSGwZcxzZcOKnmKUz/LR5PLxfaTpzv0Cc9Lri1/jYijl26jLjlsdsm7I795CNkeYWYrWkLjJawAO61kFbfQ03y0s7ev4rt+uBFp7570hidrdrEjmPzJK8w766zbdG0QIHeAFEeNmIWe0fqCN6FfXPA6QrnJFpeS1BjYWRUnR/ndZuHQcp8OH74ad6fh3YG+iJuzwCW1pSP7SR8uQYe5RB2m47x91mPHtb33kc0mDZOep629yq6x4eBSan3hwiIEe1G4NAhqTCkXG+htPJFwO8x6EfVi1a8dtwqecdf64CiziThmODCvNwy4Ajtj6Ad836QvQ9Ps/xF/f5cRtPwPqL9LnguaffUwBqfbpNfXsCD4iiyEdcuv84rwkButNuOHvNsIB9VmUVsx4P5yrE73Eyfs9YK1V9E/173Ag4dGZ1orM250amx54cF/3gvTJT37/dn/0ITTbdDMqH+z+mmAoDBhFv/IteuBP7ObZItRn/7nSXQPIn24m3tw3NtbtwcSD/LRILEV0iXYwBJWh5vROaPPLVrbRlz6uDds6Nyt19REp16+J+cdGaD07+R5OgEzNZUkWYxTc0JsR0sPWrTaDVd5sNEqhxyswu70fu+iE282rfWs+ma1xislVGJ9oJzGzEFNLhShA8SFvY3GP2tDirpHxqzm61Fetuuqhm9GrsCWjMhwPIp5FNcS1VykeEg2WhP4b0kIgHneGFQNYKe0pcEPm567WdLBeFdHrWB1JllzvGi8kbqT4jlpM8kyFLccjRkuX4UIWc2zRZlH9ju1Tlnx4ZJpxK1qL8VvdrmN5tGTNsduJx8VHRZEHPCumCTRg6B59JHD0TrZ5F12jyYiqoQrLUjzjj6B0P/twgYzm7PJteg4Z6CLCupBvHXhwIj+SAASDiylI9o4+fjr/rVOxN2MLeFmFXbNrXdU1ZNgAyF6jm4slQiUpszmDnZApocICmQF32fBjttr43LX4hwT0tRYlM395EKlbr3fOSkSskZJoYJBUEcJ16+p15qoudESwzrvJLyGUa7HObbSe7vj0q4vbyhWeZnDyVWdZuZzfAnphAoDONCPrizyD5Jvn8jSVR+YMpH1ez+pN1VkSRaQH3rjOLC33aj3cP1zgEiW02pnUczz0Q47MHqUIYHXL0iTqHZaC0AeNRpWhDyJvKgLjxdkzOZj7XGNUoDOB+v4Jd0wsNA5MNg5X9yTH/slV8VpaJnytaLkBAcSoUCr/4IR4m+O9NhEIL2bVNrmkTeKS6OU+V388e3L88sfzl9enl/88fWrb7+5fPni1cV332usCy8xyA3G+CGoAGCT/fntvM7inLHbpGTzTp6NmYIqx8fiyvwbGtZ1EHISwHHPzrfYCvB32WT+2w7KxWC7MaMI9xtz77/N7jou+wa92JOJnVObVynbuo+cG82HUd0e+02Vu5pHL0DoYugaxO40v9Hm56gt+TSY8IjflkWnm1DIwPU5pBCCRycms8y3vKYWfC3DxXKkVcB8DZw7ObvLSB3GHIdYdu25d4dRZ5pyLIwfXx7lJz/wlWxki7fgaDPXL2hau6sUPJMj9bsLcqOwsRqyoNrEm7hLceL9TzzxJt7SzzHvhirt7l593tB/xe2Hkv3+sL+HDGlZosiUNqsNCU6rc3VLnN1POcS1wGi41E0cd7tHveE6Owlp8RsJ1JxTUSpcTriXZZ5OWqbeyPlyFLgy1zrT9gNnGrqpfLCGFSEMKCxHt9oPXf1t/9MucSPvxlFvsM5qC1ngNz4dzVbgYABxmwTYEy6/qLCMsykkKdeu36wYDUrnA7nvR6t6+UwqxXt0D6h1W9XTCqze1fJmlVbxiWZATSO64Rt5V456uycPoIlBdKaNfBiHEYM8dO2S4XA2mXQSybCgrA3US2IGzcOOjctSUer1cOQeaCI9MgxnxSIfZY85p3VDth7MRl4W2K6A65JQrW2YsyQ73rE5r1slEZ+oNKWN7F9Q4SwlWfK6pMErGRYLbIX4Dphob9C+dY8ZrXXXNlIKYNfWeUedZvrq+evL81cXL99+//L8/PIPL78/f/Xdtw/bEwaiGBz1+Mh7eHVRS0ZUBZ6lhzEaxPyiIS61Vehjtuyxk5kdfRAlUQKLJOM4U+HvnGRQjXYJ6JIdYwJoINH+GJozkthjeh7e3Rbc8WQ8FkRxyoVCxtjkQd2aLZKbP5mEbWOGvUGd7JsgJz2g882o3EpJ78Ej51CHs+RrHiJ2DDk/0dW99+Y9iI8iN+HvejlCsHB63biX90ZIgOw26IFaBaQIz1zdw99h+4vyHmUZrKgHY2MoFNS+xzDdTzp/SDh+Hx1IBqVVBqm4XJhXaSmReig3MVMbivDVcvJOK2XV17YoouRjC1ceOI5JAP2IUTx9rx6FHMm6Y+Kqw4QCdmqxL003rXOBjiJJZlR/hi+U9m7eoHqAa0+jE4+X80k+St0LxB2hmxwNLe/lh1FWzhfKEuVGPXee52qFM50TZxhVgAEVp+mHy7t8vLhV55oWz3LaLnFbig4Qp2F/GT1PyYKUddpWvuSnlffGkABhiNxLMia9bVrCdr7P1lBuwAxW3kWZojeaL3oydg/H7qVVj72+8Rv+sYPWru1kEuRzUXJl462CrXP1xJFUf1aBKz1tyZwWY+OHV5KBXOUY22TxtM7hWl9LXWYEIEENs8YvWtAWqBHIHVVUUO/vX/AGUVTT+hPhuj0gmJ46HJ+QKijJQjiR3MgG+Xdldq7NJtpXn1k36Zxj0iHp9HTL8aNzpfWTh0geYcrA6kkPAHaPSsAV/IuNlh4tAyRAWS166Bl+jHh5+CR17Sqyz1Rt1JuguiH5Pq5u+q5k7Bp67m2yjbkaoKvMb5+wm2SR3jxkj/xMPfTGs7IEYrIEE4UzSntuhh6Wvz9mjx4+SWyPgh3StN6Me9mA4so6yqiYFCV6giXq17jWLbG/Zr0OpWRz5rv6ge/IURrUHGB5+XQ5lcRUFFymWE+xQqgwvcwo1TWmwh3i/22oxu2utog1X6RD+tsD74tiRvQEIEbaUN9X+d39DVqrj7og60dtseBwWzbyAR0EbqrItvwwG6VLzI//PiMv9yh7iWb3KVEBsvWcD0rMo/4DRNoMCBrG6N2Q9+O+d1UWoCn2luUNAh0/XJqtHm/FTm3kvDmIlIbrTjEw0Y5AFZEi9PZCS84sHl3LAjby6exHUkFC2cfgglj2CsICr7G4lige8JYjFm9bqlkPN80b3F93kb5GE5bFGCtdkoLGlQ9ak5KNPS73WxNqRE7zICNp0DuE/6uybFoh5OYVMIt3DI2ozJLMGA5n9oCv9NJZz5i3j7mYHz3nCmLcyPWyHwkTBIeg6qeDDagXi7bQwIaTt96EWr6uYaqUWV/Pxn0Iu5hiGV8PB+zhiOSWYFjFhWON4r9VDsn+i58rdhU+gqV8/Jwxccwp1FKVJxvHNfRaB7AQa0Zsw45zEeHV2cF8OHE4PuCizIv5EhNBeqyKykLBUEfrqbec9iha/ZjrsOHIMQ+ATdUia99xzkLhMl3vvbgXtXVV+SwdjZYlrkvFp2gjfDu1XEzUml6KZtBjXv9xE8V2wwZ1vYHR0LWiWddywZ+fnxuAHwpKCiAY2vmanSPZ+xX3WvLFpa7+blWlJ2HnSQUOolTR34Tf2Fr6VWNU2QLW5HC80N+DjiIPOPageMN43BP7kICqtdr2cnRlgjpaU/Wo8MPDZlhD6biBaHEc2JpcX1vZ4NctmTyh8H97wZBsDwzVkImFxhUSJYIx44vwQD0GKuiV2DNqgYJOkgz5+0ft40dMF91U4ZnOhcDEx2yjch4aTJYSk1qyN8dlMUdMZNprk8oMu0fOpHl5CXOCBVNxkhZD71CBDpC4uuyQM8Uep6eLmbqIHnQit9lkTi/PTpRlXt32nK+tR69GocoG+MxjzuPxk61j5pKdHfiKTK5gTsmltpbduN1WU7rkXYRVJjQlOkvwcz/5zqVProIcYI8ps0cq+GvmOdYyuhor09rRMJcW/t9NI1Z+J/UOo4nZGYYHQz9TXCE72EwfHPaGjXQVH1eeEz4gbJHUxqzeX+kW7pCn3BZgp3ZQRYjvaw2JJGBq9EfL3R6g1nE+Q4+cB1XvGo5vwqpTD1Mc8jK7ROTbHqPE9Ip5RgJWvhv3GGKBpr98hIL3KWcPr4SG95eL6SWpkU4DZmRHxK2p5cZ02oB8B5ua88NokWc+CyuMuuSPRcNQbl7JgKgOwI4RDdh6o0pmQv9Y5lQnnk4ieUbm6hM8bBOlqojWOtF1f5gWW+NEvXGRVWBl4RJNhmhGBRA9wXbE2JT8Jaso5lk8TtH9VJMjrYgXV7R+hAnhf25vEVnJnl/ifl7ms8tg47a6ydblJVfIX9KRbD35Yl3lDsabcMZJamt14gcTj7bIWl3aDxafdX7b8dj0y3LyMCWdXb827SavyMxC6CK8a/wEwvH38C16rsLuUf7Uj5ovJvNM8MsUOnZD8A2RRW7bCD+A0uU1ZOxOQ1ENSXKQXHiIiQx8rKepfaSoNimW3RSiwTzGJH7wHBt47QVmKdQXZBPZHGI2ZFDdIjD95HFWDUM9z5zlHioiaPwwdgDlXyvw66oUcnZtwXmAUYbZYG9LFacP4l70i56O+igeVBsitrsOCUXBfBoioM85pAN4AuspM/QZktaMW3OdvuOQAKqw1TzElYpoDGKqZiYm6AFZ2Af1ECqW24lDoJ0F7HMOlirwUWSiXvbmRIaPoOCHjR/ur8ugJ6xANLoImJ4+XLgUdQZTm2IWpGJaTDJFx2Bk3eSHVyv31Lc+QJhtFsUOecWCMvuoSbKd3fSTr9FJf/vkIVQZ2FlqhhFC+mMIdMVoLXtp+wYTMwwu601r/s4mnvt9Qr5o1lAGuHCKbjm6r8NseuwNzluyBgsn+5HPn1CA0RJxPu1OI3z2w6tOs9QkthqVGgaKx2VTi7jpUIOOXbV6telzR8xbVOQU1bqWllF3D6y+KbKCUGCqzoNWPJUb9oAeR741GNiTkg3XQ0f58DFX9NNMTFrW5q/LqU5ubp/9xiZnz3gvdnEyzHDSrX/ES37UdFGhGpDR29+9TTh7UYO9i9sSXR5EtywNgIh++P41MSzSewRbmqCqH7BxmI3bSJTM4V8fereoHOQa/WgNhH664WMbQ4COH9Ipt16ZqGkDKjcjgH1TFDdUDjX36Uc+tdEkDTHi34yAsgqquaEENePYSEGxmGsI3QVwV6QtcRaY0+4JKjCetcT6OwOWqvFW09oZ41b1/LQ16tNCMgzSjVoA4S9yhoAYkQ4MizcQAc2pFW2DUlA65KN0NilGoBf8kvWRXkew+bd/oqMFpv8z8Khq52jvZG/3cKBdBOGwxwV723YGxycHh7sHB4c71DFthhAaLYLo00/1KK6BDEecCRQOrHrcLq6HeY2UPks029OnD3pHj2YZj5lrAyXcZ/QxanYhJeKcINVpT0v++CM4GgyOB8O9v8Vp16d64GlT5iuGA1C7C8TTY4ypVaNtcmKiJJr2Jorg71uDXVO0Z9Z7CTpjXt0GTeU+z9U9gk0+2f2bXN3aVBvsWT0fUAAVMmybgj1d/MZF8qBsChS7yjgfzwO2N8YnjTBtZFM1OHE2vcoY/fW7i2/OKY6nCYLsGU/hqj+wJuC6WIICgd1gqtssW1Q9Yuk9Zts94BVaGfioGoGNR9/kVBSf0vQUCFqevI/KmQ00SFYURa3KHpXu0TpWW067yQz22HBGi++8LSmVXvr5IWjlEhFPNQhFdc/ygZ0pkQTzmj3/ABZGnUg5W6Uop0F9B7u8eHW90eIx2tqDht+ANMTAAe0Om0DGcgA+mo+cDICJHB4M/gYsqzHVBjvAPgCNu8DOM0PwPsc6GHS8Fsu7J713MoB7IQtXHZEOOOx91oB2fVuSP1sCfVUWbX1p5yvC2aKaxOpSFPlGU0yCZCtMwcp6Lr3UtfTU7w0FPoKeP9nU8QD2+B6U7XzE4HDwlw+JQE3vIPo0cIWbgnuJ2ez4h6ZHcNqJTNXjmXofejITTdSDiVBpTKl38SOTJB4+T4tLKLBthIiu7iViQo41kEqjHEgvmvSw2kHleoCQSX2VYWIX1foW15yWgMubkzKMrl5qOPRh8Rj97tFTbaL8aSOWEPiZ9A11EyAqoPtewTvjrrT1Oaj7hCG6FxN46mzHCEf1zpvK6ay6o459lBKYVMvyfcY1SddZNqaMH9ay8pLzQ31hA5N7m8PMQjGUmS28MUjhiI8yOPqiCvRj6vsgUXvnraOmqqzU2ST3hzut2YlDs/fMrMgIetwqsCctOClvaM7a/wzhT3LQKogvPt6l/UlmX0N6br+lCZWZhrt6yK4vgga2rtuoK3J99EarMmZm9txWX1PmtlbwR3oiHzPdJlvJdyXcOW1PvJxh42vOW2KXP4roRkMdE3dZvc2bHCtzEezv6CI63FPGL+8q424E5D8aC1wnhpq0YzRHK/CRyqlvVrN/kG+RV9gbij+UHR+P8SLGBwrPyAG50rKxtnsk2DzvskvpiOBwZZ16ejcfX52eIlo1Phfrmtq+34GW73T6Fe2+5ujiJlWBbU/v7iOEl57p5bHe/VdbEB0U69mCRCceYTbDstmfltkyc/VpZOBhq5wH2qU4Dc/SG1VVT4ftwdWaL68m2E72Efbo2lFbs+7XFz7sE8hlEzB5PCaYaXScc+pv/QkHl8r7XNneDy5Pvqr/Cn33DKUYNgeJrn59hhivvpG0j+Hs63S0KMr701OOF+GfiJCC7+Ql6EvpOl1Iw/nqvkLDpulXLmb30wKsWndbAuVFsuWZKTT2zB1kf1RR6wxKF5zcc2dbz1OEUjH/fN7wp+BlJc4X7LxXLdzuxzb14VsazfIFXa5MXbqowQzPps8aWf5Pd+Cv3Iojc02+O1oCsCrlSgLtjYZg7o2pD73rPkutZifLMp3EUSmbYKdse2K7tW0PTIpwhvi3JysLTNyo2qZaG1cENmOI5xxpi2AybKkXE/tMGt2YpKLbPMIZvsRkd+LWsvTEpq66v6QunUfDGz4igh1sCuloSi5VZNazQbwpnr701dJ0Ts8mc2xrUuYZeQv523h/Y6FibnmvdwfUeb5whPlZlGmJ3YpASOE91VI82o2MgljcbB4zOebZjFp0wdOITAFLiIuocELF14xPdr2cTFwtQSuSpvQu0WZqhlZW57XLBcDSAHIBLgjlgNsMESQo8MiDflslkvzae1WdOMMX8kSMVgdxMzxPh74bLTUPR76R3E18edeVjjPE32X3lUZZb1BUlz4RJyqGw5E5M4mtXMIQxDSca6A13xam4D8SfGUjudkZ0bLzrJWZVuquQxbqlxPWF+Wip/qjNuRIOTqXskH5y1KqPzI9jE0X6DCdI56QrR6lMs3JMuP0aXYuYYky48vWmtlpirKGpvB6MBQsQzDV20UpPiS8b04evJ3lzP2bwQaI+rMQBaPygLnFFXr44KV+bjSZ1MH/X9kVsPxJfkX3hVxqkomBNKDdG2Qz5DELTHmXpe/kEHbkMtbApVDuLm65oh0z3rin61RWjgdXp68KSyrgUBxcIOc7+8d+mCF8BZXs0WiM4q+LlbTxOG+zMP1cGkc7mYcE4xEc6qN0NOGqYzEV0uU4L7rMenEPsdGaCsaIvD5oYvmIHsK6R4c8ppfci557IPq/oBD5QIvehptXAtHhRpRP/mW10ikW1o79zb822KkE3arlzQ118MiZ07i/A39uryog8E8qmnT8iiRxsdmliqSVcSDCmxm51GtxvX20J1WTIwdmZz85R3rMsY9ux8NFK8MDEW3qf7EzWokSZNJscEFtGpPXcnEqvJJ+dSRwtQowXk/pwWwauL1BMu5q4ePQmsMN1t7X1/kHVkh6VOwhti8IWA3FxlpxyiVM39sMSdaDpq5GJWqg029kJXVrX3fZD7ROlOZjlUqht54rAPhVgFHAVqbtRThV4H2kOKl6f3IsM0nxxMpiTnhYYAx3Tna3Au1VGeUILLJ35OlwBRHSXDw8rwhYS9BOkkhuZeuwPezVHPN6HjQV/TMF28S2JNQTiOGUlwJqZjo7IVHnUmQzfviK2i69drbDBSA2I0M1s1LQpP24UuK7xNQSf3lr+evC6y5NwpOBUPaWWNBhkh25xiq6nY0iFafJS07RDGXFRNVsJ1fZlOQMfPdKDWXaGzakSTKzGS8z1vpN5xOv1N8Wdzik9H72t0/+pTh0zDoboukc8/SD33ZMJ0XpAyjft7GVszH24cHzJf5GW4HVBeFWmOdFe6cKOlM8IL0sTeoX2zdWjL/Ct0EE2XHCmOEv33z18sWLly8uf/j+tQdjJE2HFGOcx1vA7vRRrpuY4dw1yEDSbySb44aQJNGM6tq2MvsOj0BslMZYXoNU4KiFIM/bPtBhF2jSz0jXa7tSTbcavZKiKSn5NFpREp21XtT4qDZPWOsYPtc0ag985AzE0GxnxkeOh2pJ5BeVa5kCGly24ITGCPXKIASOj3XkPAJqlw4/TPKZ58urK1SfxAE9LmG5EdHJAEfeJtGqlfqjVG/ly7e2JG02zuIaKefPQfqSssYarwT1veGE+gQw/fwXMhCJG9hnwtEbUTi5FzKHxFxM+y8MHt67Q5Rq6PoLwpMjvyUI6UMwjaBi4dAM2VgP2Ttbk0DQGkY9Zt/iYFeYKUi8oqFVNBmF0MZsCfYAmI3IQSmswXhdIpDUvyIPeaOg4SYkh5JrZq+8Ht/DGqJS6R1lW5L4ZcqKBH+KBW/aJhmcosJOXykywtUvBZ/fwMHXfwzXeJEp2gfFs9MJbrJ7lfoPrFNHztCqpbpTlLVZ/+0WmiuEUCu0sWV61BGWvMVjachPtnX4wb2L58nzF98mt5yoQDRNXgZMHI+4Cn5/bi26OajFKPFmIyNuVBfk4kGgqGsGcCQeQycUvSUNf716moK7RhKD3MYC7Vgmtxn1es7lzOGdGyKIB9FtxvfOG7Rjwf+w31cKxmqwgeFyGw56n5VO2ffA7GzLFvKtO4u9fE/J5kYHjXKOuOLluqYlzxHdjf3lDfJyD/0Brez2r8/QKG//+qWqFGTJ1Z/7QZUDL7O3BLuQvttquWqYJHCHPrlQocZ932J/g6HomP53yZa+NPyyFO2Le+q/8wl8pLvM2TYaASuZOxLhcBv60DHABF9hHRCxHL4ZjTyJoJO3AkJqe27XuY24b9PX4qMd9g3usxTJb3bTmI0aPqopcMkmzdnbV+RO5UDiJU1K3nTqlun9stLFvE71JGGIvxkORCkUIEqwx9/EKhHRX7OlS8orq4aMsMnOw3ke4YDmxz6wCTvv1mFU1Piv7LiS3ZtMihGWOKp/wea6uXfBb6IjuoCra/c6tjgt3AWH2sxt6RN4plvCkHT8vFJhEV+31F3gefkrc5V57y0Nx68XP6qZvGa4BfSzC9Pw6Y3rou0iCATiEB201B47ZgD0izA2YMXq2qOncCqCuRASxmFQI0d9JXlETIZh6b9kzbHNpLWNK/GMvkUTQ8rmtmpJlRFrG7EeyEx3wVtejElvaDenRI2L3T+9nA3ldJp+mGSzm8Xt1gpdSEFRyDKoWCNWZw+7VzUxs1JLDKNC5Oa12lI0HhtYZQug3xvCDOWYrhi0N85bR0yerqhyfK7dRvP/1YvG2GFhdopakHW2sW4OLB70K2rWIdFbMTEbByTdOsTDrZqp1Lqh3V2F5u90lfnLyMB2f8jccNksrT+0pasP+L3rKyouhl+ystC0PiRw2dA1P+Nb2Pq09Luy8zzs8TXj21s5Te/ZSeKgx1pd+A27CjuUVMmgvxdKfj8dag7s4U22SQ355odXXel+TGXnquZSXbELUHZ9bCLH8M+idpuf1EXp1rKc1LXmV15fazy+SEvQYOu/QA9M9PkzDBDmFbvNw9tacea11QaAS2hGRUR+NLV2uV+i1YJaUsFmaViS/N1slipyOj4C3Mhsguroy1lvliH3Q/e8XD/hfey6/4EC5oJkGLyoT+v1RgCyD+r1a6+HVfmNrRl0qRS5p8oAwUMz0TXV9DLHFBTLC2pqaP0n1ElbVyv9lFepGN78NTbB78/9Yy8oMcNyWBSQboptcbvTY+ImMXv/3F85Fbws+QKvhiiS/mckqav72ei2LGbqbOVtq6eIeDWYQvqqdWy3yPduIPhhGTOeG77g9AwSb6Tgmi+fbHIyuOheixbYpOuL9ApDlhyajLCThiOlOYRvERKfjvfKpoRUElcCgy3+E8HBUv+nuwqNB7/PUkxMA9sUBdCKB2fFJZDKohghEleAEAhcKS5FiJZ0Z/HQ5Q8cJ/NPf8V+CPHf4pD0IMmbiukyOjTHe6tGEPnMUbJYKlIok0aIE+8ZS1cmFsn1CW286BLMldii8BgKyS2n3ZGA1dyD2gLDAYKfe0kg+a8zF8Gsv6B6Tb8W5MG0qopRzkTCr6RryWeCDF1fwu/Pg/MRr7bhZHHjI+goxa5x4/PiRuhwNpZ1v+fOmoqS6ERXpa6NMSZOsZehwQt5WU50C0LAQuOwEdfaW8PfrT8U+JzqvmAcLyfoe4dNYC+aF7n2Ag/7gzbHSbNp/JjK8HU3qNUztc8D22HaiAoI4Dzrw5xcmH0YZZgctJtsIz00+FWZ3n3ZWZTLrMP3lX9FeBRbC7UKVuRzWue6j+5LCuUEWO4y9KFZQCP9WnJwfVY9nqCOZSdoLD6bYwJK6Wzg2TiJpurY61I7iha3dDPGefb86652n3ct5ylL3AD9s90haSUUwXN5dZqy0ZTM4bH/WBSCd57BJQPVoGIpJIMtiiKZENvDrL4IF2qey5oJq4bR5lNbC7FMm0dYG4RtF1LilONLU841P2zYaAo++v7SfdUcwtkjTALGbYMJ3N57MeJe4WvWANf6Hgve8L9BUHnFxG46ZK+Z6aaOtD2OOp8DyotLcXKGkyAupZ+pNMA2ZF5n24y85jEO1jwe+AmVSnw2gof1iXrdVQEorrkfr2lxoeWV7hpLLr3kN5DdFHdHwtFjBR3XgHBFnQIAvYiYlBbjFOGa03cZFmBl9XISkwnM8eVIFycsDdA2x/XTdp5GOgMxX5r0GjEoKkq0mV5dwrgsueHf0sLeGTkN2QmG3DnlcroU7ybDm3myMJYdUCGmMiyi6d/u19+1pMrWnyPjhVLPqVgfl28V/waDoRbw6PFOZ8z/aF+kV88LTo6WP0nPnvpgnA6oWo5HnoKBmbEo6MADfhiLjxLRM+xW5E6Cbt001gONwWYNkJph8l4OWkZsCelsZdMtbMxDHIviLNTXHF+D7R78uOruarF2gN0lACfvwWg1GQ31JbUIvTACh8l5b8171ZigSZMSv1UpyI4F4/tkM4FiR0ct4ggVoBTEF7TeonGhL5Sli6wRmuOVoZnGO3gr2TxOp284f5DVV1P0QZOli7+6mWCelx32HCxNZvfqs6HVNt5ht0k3mDsIW6k+JSx+RZwLc4W1F4BvdOcaHqnWbu9mbUAJAUT9R+dm5/zCY113d+Nx+Uo2PZSt0d83yNu5RNhWl6VEhXXECW0T8bIRHPNkxa/e1nGiPO7+TUHVNHDVb1DDkex3f1/b8gk4DUELkJWF8H4YJMj470bFcrYILJ/CVLHVf3m+4KCbc3J63mLbsPtSuq5PK1OQzMpmNTeymY1Fib1IySrc2t0SP7FPLY0ebJRJVIG26+9Pl49BXdxoBmK6aGrKCWNrDGZs0YhmJmZJol74E5NFTKnQMlLBaW1WmcUHlxxvTGPh6LVjPFkzF6DJom4mxRU6+iZgNjMTwpIuhtefNHUFcaugqA28mivUi+acGKA9O3/+6lUtwwPhO/EVGpFaa63hAOfzdJZXt10B1+wm32Ro5HZBRSoXyxuwmrJu8moBggZ72cJLvVgCi3wEM/Unvds/iSUbqWz5GbQgrmghMRMCzs/NIdRHbBFqKYFCC1CDV98bEHPxUddLpkYBVsiQNLPNKZmspNUPhnRkdP1N0BOJ41IjVQ+YSS4QE5j2XEF8FpavgJyZYuLR2JSzs0TBSEL0Tffjegre92uqf76JAJXyD1s3Xm0sVZ7qLRO0gYuruCRnTYO3VgXXwjkuTloT2fqS7ZVxtVOS3mCrF9udzFcXrwrPiUpoYZlutYUGrUzMSCoXmxhruLYVG3AwJ1oi0+M+CMqKn4nyfJoqmGfC3lH/e391yIQmb0LgCIuvu0X/Sl1atKY0IOGdjd+jE6zWajTCWCO/tWitAUxwnLMprpvHAa7VXLFp54d5OcmnBFw5VtyOShLYMFKHUKB8CUJK5Iq7mtTEmK/L6IX7NL7n3Nxa5anASVLCogvcwLfGVekLzCJ58zEdHY+kxT2gXoXgBSJTMViC7ZSsnluM2tYBgGsxHXltNGI9xAFp0T63LGj93aROZRkNI2mvts0VX21NWqdGqYTCIJVli7vcZtXZ3zDKPBpB6r9FY17kdZ20kJv2pE63UacZX389glMr8wrPq8EDedqX8WD8mavqlYpIl/Ydqc25iMmLNOnPC065r/tx2Bpz1Tqx5TYZdslyCyvBzQ86X1SnR6cdgR7GTwennSF6TfHf+6cdpA3853AAf98dHFLp+EFycrp/kE6Tb95c4Jd7p51lOaFfw0+09Azd6xhVrfphERoriIwH2qe5+r/kc/z1AAbCVsUIe3AHJ3HT+SI/HcAXx6cd9GrgXZQ10q87X/yZvrubEyATfE5PT07/jRauz+KYWgz4B36IvkczuvNF7efwOLyngUuhPx0f1obQLDMnNZzAduBFJpZTob8dpRbQNKZGJncgHe6LpTQa6v/6V7/+FRbVP5fBLrwIwqJ6j84rjq+5ZvDhj2g94YOYMlBxFjp2ZMFXODntcHR0UtBLD4bHwwM4d6SWobCip3PWbL/sTLCwUHIY4FukNC7NYKK7kXIiot2vshRf6atljqCc3eSqJC8MYg6AFKmqHPgS1hgm0jG5al7OLoMZU80wZWTqk/iObA6LcjJ/Rnt1O3z2IqP2b26rYouBtxrCD/x7yNrMO/z1L9GXSMHAGN320ruUm33ygpgpoYFS/fUvjcMChpZe0/WUrt9U/oznTQf8Tc7NaWCEcDZubieVWF2iC+TL3EEDIYrgPdn7dZ/UJ6WR/2WUsu6Rj7/s+IK6y/3h4eHRoAPCDUaAb/A/I8J/7nBS8Zedo+FR519Xo7HBByHyHQYVqHaQDezsHu9c0Xv0rvg9euz4689nN51nT/PpjVITcuselttTlQJCADLgta6vKkefaO4evM+Hg+EurQHee/Fl5+WMcnnCLQ/eX/Kqv+zADzvJzjPC1I3+7F92ZKf/Fbf9O4wT0i2eKM4R1YdWc7TvqLqAS9cZjYcrLCX4mJNty2A93PJ0ppXiXbi41+w9WhR//cskXc5GtyEgt5aS/vUvr9hFXycL6mVF/RE10haU41OZaMWkdoewsVeZQ23Sahdac5VzqhwcB9w6MsSf4T+uivE9/aOk/719VqPobMZJnmQYN1fHvoJZJmuckl8eRnn0WA5Uyg9Y6Yg7skj+3/GzT0XtfAY97maCP+ipPg/CK+v5lTQvhLmJibsctXtx/GnuxcNWyVfmKwXCAn7VZFUPP1t/2/Ct9LYNjk/0tsEZjf9mp9NyHDNcc3gEe/5wPvdhfNLdj90Gw/GG/gyGB3v1M5DrsuPu+I5e+68KGFuCOwlqCBq/q/Ml1DzClfeTC0W2SCcVegUw+6JHPSw5v5E5zqKYE9OruBqbHCBSrKROFoKUHi2WkuNerZeAJysl4PHuwaeTgIoZLSf9QFF48mmorLaIHrzhh73hniWxkKzq5xfsjaMVGMJJxzUDhHLya5U/BmwDfckp2bB//Yvb/J3for56CWe4PzzYP9ztPLvKZtl1zros53rWZmbriTVzWhklJpBjNptj6zr8L2lX5VLSToHUojMO9w9OOs+8unWP0erFavUyfdZnbdRou0a5bOif+l0W6MeYk6TGoerKEkBO0bjvIhJXxjoFBeQ5H1weha1mJ0DOEXBnivepiSZuM7rx6WEKV6BNrVGTetfZmUunYO2Aq5jvnHaQz0aT5bjeGtVU8+ZZpTkBkivVh13DyDWb9F39sxtanHFcH5uORtSY5EZ5S8nbNMpM8Bc/0rV/Ratp2tSYm8Sbo5ORPgTsfMpskcMFrFSL4+6vf8ln1lVncC3WcZjj4UoOc3DwMTo2YpyGHf9mPX45CX08jMngWh/FZNauowfvWdO9v3Mu0RjdNI8p2LKoWv7QEUNOpCb8uaYKkCHN1rKtVCJUNmJYNEdkXHa+ppN3FV0Te52Q4/BfqTsd0jFGtLBOTpP7SdSl1bv1lLX3GWWXALz7doi4Gz0MYsvBPpCy9h5JWWvXQRJs/+TIUNYFNsWWIwH9hDr6yuFW9nDjogzGchS16Ug1SrrNQ1cIqzVguGG8lhm+UGaco0u8JOy3QINEWex6SjlczYOOdj+CUuTey2nkynXDli8rqKVGKIePJJTNl9EkEhsw0kJl9u/ZLfIUcrQXpZDWYWoqD9ZITuCYjZRnBKlZPsomDUSdM5TN79Ekx+hHWomnycHBeXuKOUqNGW0mpY5Xe4LAFHg8hZTuPXvmVnDHDOf77aXymg9kLI81hR+2qB7sQE1+var7OpsnFuxfVGRtMMh6fVlCXIsa2xE1GjXVmyVmB8KTEgaL6rhHe8PjzjPldojVD6P99S+RiASzMJRynoSNvivVF1SE8hZOELfT1MmK4ntxV5A/12Qxpg6OOfdwP6QwYmktPCsRitNfU+ji179K/gGjF0/x18/+7d/u5u+xL8tNsejNZVrq0/LnPz/doUf++hdO8aCgNhYroaH8Nf1i5zWSlq6WI92x8eFosgcN/z3+oDEwRVd+/aszFPtXGLGULMorNKPNjlDWTrb4619A5/Sg16iYsGMw4fdNdEE0r+JhXjOjIXNcehZIWWxznDIboYsxHGiNX+/r2twm79T56/j12x/5ZA642sFv6FeLcJST3UdylDrpkWJyfGBYRuuGtWgixwef0gkWku5HbNBjvfK1u0Ouh0PLUtuIpcXncLi7uX8K+dJrdCb9QE0JuLZTXWHfF1SJauxxCjkFybZigi/9z50nrcSfJxSRBtszIfWPPOfcxF57hqDQ5kpCvov3mkOvJfo80FpZfbJa7z88+hiLEt+T+kdX6Cqa9lwqHa9tUzXu5LH6/gbzM63QYbaeRrAbnmL2Bk7yrv69FbpIOm9Q5GJV9tcSfewmr2wRGMrCr5ZYOffBUdKFSi0Jn+NxM3WJFl9xn71GZLMbFJh1aXDMW6NgJ3lLk1t4oQm+FAnNmjzkLtxCsRVjFKTkRCFPzasXCSPGhFIOlovw0Gm5uLcSqFFQjRSLANVY6uMFdqMjSmAfhTPxJoQ3CgXdVaaeHuqHxNXMq37KubL6fhmmThLAqtYAzD2QcUyWEyyabPqYidfJcr8FCbLs311cvD1XhtD961/mk2VFoDmClUOYrs7TFk75PTZ6QNmaiQVIbSdK0Jum8yysyw5/6LJ5ph5jRLDGa1NovWszwQhO6gin+OtfMIWlpn78EeOT6YydouSsx4tMPndx01lF8cu93eP/5vMEnrl/kurHuQJa2Cif5N9DAjRQ8pbr8fR2D6s4eROaai88tYdPubQDBpXsPHsl+qDcKlB2MAVmhI2dkfZ4X5VQm+Nij+Mc9EhvZqfJgi9nkF1A7JpI6yoTrJGsWrjgCoHJMi/Pqc+AJh/sPzuzPQYWxotKeTnGO4Wt41LEDOSlwXDFnHYMxnkc/z7c0RzJFebUugDj7uHB8eOiDW3Ti8UtnhN3Er3kXDM63d/OHXbUizxFMvNePxMeHA6cBa5G0VOE5p3dPGsM+XRHvmGntWjU9WOx3rzGofQTCuf7DvR+IG3QVWImLujazhA3Y2/nC9YHNM4v7msMnTOdeTJ1oiG/plnGOYPkkcMZ6f5JV2pOpSOR1CwbRQI275Ro8bE0xIlHHjXycTT0SD26bXqmoef0na/f85rh4aEhj8N9Sx7fFgvxmei5kYe/m2DyBKZ6cpr/opAKQjkm1sQsbdnqwQh5zeDCL4F0xGeHYQXXOiL5ygFpdw1GhV4TkqRElj5DmOoQ6NFcUoPc75gG6G95pWEfqnXE5LG7jMkN6YaZdP+j6EFRND6OpzzSbGibXniKAnxswEAObWz78KiNgTSGNCcMOyvaxpQz0+GVEe8jPF5/mzlFlUIIRDSssJAbT6BJOTp24wihL+mbiFovmefjrOH+JaS7kIEZPU0ylPGiLO4KE3zri/5J1HGD3I3jE9bNPC3GiD5CjoirDN42L0rQQauipmS+Ev7E+HKYk0YL97zRNQgxSfrytggkN1uSb2K7KNUFsTAKKCeBPqGqHC4bcm/KtH/DLHzqr1hC/lBOdZ7YHha1FbulSpiGm71yVZUFGa+0v7VBlJnFXqbLajx36LiXJGR3GNfc6XrqN0a5Di0fF13Tyr6W3tjIktREdEA2KI6qrrvijsDkF25aQxm8AqIGRwldwVctzMlLg6FAkPSTHzPEybpd+K9zF8S9XqKuRFVpk4y5q76cs2ntwV0tNbf/Dn9Qkfykfcsrzl/BQFmf8+cydyM1sLtwNzHhJiGLQvCMmQtaDln5FTC2IBd0oLN0Fsh2bhAgQCf+8mTBQ11u86BfNbTKhLRPw7vzRT8RepMOVmnkV2ciyxHoGFM6RS84W8JxlbUFcF3wQh7Ted46/PK3PmsPiWyBGUJYQDn24YLICr5yKX70Boxz0ZxeiL2uMr0vJoRfnhPotQxUW1I/OUPONXMymEnRQMt49O/mlHHFGY/M9bPxoX97eszo1Ajts2b+nWAqiJIdMQ6QrYTmY6WyVq42kP48zUvjCD/16iD1JLon3w5jMebZSDtOpnLYuBtX95EI3qPlM2Wn9xQw4nHC+XGR/+jcLJmNlq/bXpfIR4fGN+MT/vis/nlJ7ToUiWg2VtA5woOmIEX7MYr6c+fYklxCDbcSNCs3/Jrcq8eifuFBBo/e3dMZO/QHOig1m2XQPwUrVcnW5XZ3hP0Ex+3qupgSqH9I9kEzVIhYXr2oEpJemoxjf0ZYUv3kLffq87eJdAQD5VAxN6kJa12xclT4veelzH5Ss1jG2mQ2QK7KGE9gR5R9ea914jWi3s91l8ZjFkL1R1QtiP/qEX5FyMK3/wh71k3eAI0SFvaL9P7Jo5c3RbUbK5DgtsNFCaq5w6OGBZrEJlxhyL9MTNbqYGfmBVMv2c94fdGducp0vSojvJYaHsrHvY4FkC38CQQFrXQSTUKwe2yWCyoJGOMTvJ0t4gN1S7qjrGZkhIDs1BOnMVPGHZ22Vgfe5llJ6xhJuqcMTHUh/Awrej0HTeOf2mCjVJTUyLHCxsX5jHLovkP1y7UvIc+oUxbVo4mP39NL1jUPmSF3GHG8AxI1IPOPhssXrmVMoCSyFYDS1MH8w90AgWW0fF8eNM1STF2kVxNsf+1t7nLyKJi7COji40QTjdSTkR4lmB4XSIjMzGKJxQoD3CU/yj684X0wQQOT7TE4OTaSqeGORO0GC7YVt8lVhmJKxzUCMznPg9aRvpsRbCwfk1fZsKtqQ8bp7eRLpv2okMQFrUDsf5yyn9QkUxoZj1YDJ11QTPhW6sWw8nh5Nc3BeiVrAZ7hJzSLRGTkNflNMZeXIhdp+U4UUu7+ocD/0lvT53mS6iSYroGzFHRECX+r57OxwxH5rpHtGwoX3rgAOm+PTNAcyRrpMX1cmZc4YmTkzFurjBzArRhwf7oKNnMX1PH42mzmDXMKrN/wwHLZ/OyqpJ62LfvRt0+4Tc9v0ePu4P4j72DL/IGCmHgKaOiHgxPjsTk68tHeuQleGLOVGKXfbQQ5QTLFXZ8VllC2kXXy0+7M1T5kll9WnN/7hC4EF1YILpZ/mVh4wZvlaq2oRGcq8kK9NhrbmNUELLaSDQK88bWHKAE7RWhBx2ccT6gcTznlemCCEZGokzfpEUhQE4RI7bV9nYNLnHKmql6DLkVKJiB00Rl+i012tBRlXHDSzjViEmZY8g/8EP7UxQoNgk5mtAZJMreGVTXPZ7PMOm0+wvxvCfmY/aPjYW7ttxBfthrdZtOUaAX1Op9J78ebZ9TWbPYu4YqBZanRfpStsgQCjrnJ4JVSiWTSERIEHBFAYzVXHHe7d+G7iWlvzYsgVidDduFK4AEsXJoBQV9gBpjoIAh/RAOcv/zOQVHK78nawKqZYgkHMMPsRT4a0JZIkeJGouTYopMw1zPo1mk2l3qkoYy447sWQNN5oSTYC+T2MqFkP75ENIRBvkYV6TsWclIxk3yNHjmUnhL30/1TUsEspumUqyEMtRSEsV+7RYTxTUmUXaoBkVoIh1lIGoJM/FE60N08NRywp3M/MgFnd//w+LGe9JaVcKbSns3EaXmyJU9pb9c605vnbdSjyCHUbNXnHEvzdeyLYsG3BoiNJWtNe3+NV1LsIqVt+iWRN+UfJN8yowiiQNQ7jO+RolpaX6E0WTICAfOAUhEMzL1cZE/VbMz9w8L7ap7OuO7e0BZ9iwwkXP+36fv8pkaYfEGofajwGCr8bfB9rtsVro/VBd0kA9Y7r3K43pP0KpvY7AFp7DO6rVkTP2auJaHLnJY6PCrDa55awhdnRsHwcbEQs1y+Jbcx9xeaEGcspEqJu2fMXIRBFFAd3CWNOPQKV3VEu6KOQp+AGkuTJmdRWWBjZZy2TJ2MDPzW4hRs8QKC7rws4e5l6mVCaljtzw0DzG4A8lwuSBQuQM4idgBSwp0lxXHhhfdHMRusxJlldxore5y+d/BYfS8yOfMT1uww1zY5Y9/DGaVTyc75IN1gvyVI11SLlc+ol9t7xZ12x9ZMscoe4ugI3K/GcfaTF9lcKusKcUAYLUoQq8TrppJIOtDcKbVQbD6lk/WSMJ3cIe6HaK40ML5ElXvpd86oSd8J4WLxiUSSfO3ZpzcYGKupp3bUSuIJSebwI8uho3Mz7TTttHBzjD/ZmO17+7uhvbCpSglEzJkYlT6dTLKbdHTv8X/k71hDKRysWpA+Mk0JQX0q3V2L5KYoxu5sFYuqyXH6dDOyDynWgHWtAoK8zGpCtmBAOsTcpQxc9j7n/kAptVR08kksBmDOpNw7nBjOhPsXTISDOwPr6mG6Xe92MZ38ayMJrp98RV0g7+g1kYale1z9OrGj3ts0GjcK9CnqlJVlmG5jQqd2Rez1WLUiHMNBxFMU1ZVeGW2cz8LmdUliLrnzKckwAKpUiElSUlGvJknGjUxoLBi74vywGu40OyPGxayWjVm/mwS1BHxpEpNd3rWCa458r7BYEjI3EsbyPm8Lc6QfpRH6lzAtdF7Q+6pi0+Qz5KrkpMwrVKfh9e9QOUDdGJR8KkbOtOZ2RCWyeIQLQdxOxUuSL05XJjKjHnu0MpF5/3D46ERm0XX5XZt8LFSnjz6ad9UnM0o0/zV4KVM17yuBmklKcKJI4Cyd9NgIaBSYChWDpeTrICIG9Suv+mGt0G9mV9X8C6tq1onxnHJmu3oBI8wlvGV6jeVLdxm9MaY6tRjj8RGFUwn/RPU7rXgMio4qKWPySlaWWPGkYH51T7XK39Oa3SZzEQuc1e1Mp2XKr/sGZuAjTSrxrH+EbffYzMv4Qsi0GwyG7aadPBi37OCXXohagwGTd/+QV+jOeF5MkQeF3TsjYGUt6bwolsVvMaXoE2OGEhw2yWTfko2R0iUWhTyvibJlHEGYQr50XuI0uU5nI3LsTDMN3gfrN7kYbP008FNcU2dx6xo5Q/PhpdVkqHwhcrjVGa3ADwMLoPagPQXZhGqmYsQ2V9wC4iT4KQXppeF8U7rMKrRFWssALAsaPwGJ1/qOj09BXfTe0zy9kczz+Cv16MTD5iK4ZunA1nQ1H2qpVjo4CPXRSKAjsJkDW1U0x+tlSdlwpsoTEyxikHH0Yy4r7vnEEx6GkO6YpeeVz7FjiuRDt3h6e74SoZYb03qrFdXDzaQ/hMliJrsmVrICLR2igzZLSLg6BmX6CW+nRbcSIANboutF1CLKVEGvrPNtSFYAJfPjV2wm5sRgyLPK6gwnc9EisQMPIV6HOTzJK2kBe0fVKGgoDhm7D6jURbnZPeB0ZSq9QEjAyX3isZqdHqDpiS4G/emvmuwq5/AgKA6v/BGeA7hqj00jWrUIvmctT3jjb9/KrZPhusv2irMg2A2vKr6Nh6AXWwiOEjUCLBHNxrvV+K603LotlvCfq0ycbuNT9vlJ5xfUSDyA/mcw32t7xFgs6Ue4mk8eB8fQvhTioEerDlafjLPRo7UH+63JNMScUnIAYpl1wWAJmGLkcoa5z4I9Zj7IovRoC65sT8vOwnbnFBaDf/jWm5zy2DVZWnDgGRrJrkcuJyC7mnqJAqHurPmqQkBIMOL07mp/AGkYeh+waCkBmxQIngv/i3x+amvu44xaPL/MaolGlzIILbYxEDbDHKWo4aDGL9wp+zBXlUHQTSzslMiiaUZvgSlEVb6gQqz3eVkwvuCKW0qnKIX/XXNV75AJ/8zeOx89X2l7w2j4etbzgW9KVfxND4OZLCV73DepDHg5KpcYQaRGb5xUSLJDUyB4N6+B5NSV7xB+KU3e/4Q8gQR7Rz/hMIOJH+Coc14zNgf6OLvFvnxPV4HQyrhSdI8/nmkcPdqGWbcoQfs5CeyZdT9qw/k5qdk2UZr5MaQB738KqQj9ZxitcWRkXDIUssG4uNwmfK7rkF09VVkCSq/lNt/wpVx8gsPWNX7EyT7eOg1WEAFtqj2xFpupaY+eayMwTtkN64uJt88JgYB1wBUGaRIrULZZWmmYVxqUdFIGq0bBNXuXhhB3BykL+DsB0YPx6N47Czel0pwZL7OVM5q0BA51oWKBjAVW8y7L5jwTq7uco+H7dS1cZqxrWUq1MJ7Uv/nhlQYYUejk7Rz6kykr+P6PzxTcP9p9bL3huoXE1RTzlM8bPDYJS4dHG6igpGAgGThk5VxBo7hcBgyTgNZsTrhQjDQ07jr563Oagmp6kSqIfB9oDmeSdh3zd6DZJPmt2picMvValIlGjLQxZljGEtSdBL4V6tbI98BUPUq52syh5zG6ti3+92WxnE4eRcCWN3PAmiaFN+W52u+dtxXwfvEdKSlxN8XrJ371MQc8fewxto5+8nsMyUwysiqxjlgbONM/tLhl0Zrm8+lvpYZwNwRGXhNIfqwisHIVqyPK9T32giSEjdwLbydfhd9lk3mCzLSQFmza0uWvf4H7yY4I18yBdfhxWt1eFWk5llvBf+WsqxA+YX93b2940HlmgKzI82/cf6xjuCEld8VdK9+RRR7Yqhzmsqc0HMKtNkwzRjr661+w6i7l11TlXJ7fqgyyKeuq/Bho+BNKOxQAMdMgbyGJJX/9C6GMNTEvGXBBW0mvhrfZPSCMllVghcePh7U83LmFA+7xASNGKVYvrYwO4XJqGtEjSToycw/epQYq5wnQnVzw5lEQuciP6oCUmXyvkiHo0UsXlxBMBP5X852o0TgeJwZsKHSsosdQydd6H5gH8480uTScdZrP8il25+lKm3FXkUPBrXI5X7AupC5tZHksB525teD4LVXr//UvXMKL7mwKQN77JaNtup7WVoPzHh58TAQyduJuBzZDUpIlfjKCC6dnknujf0tuHR0FO2Dy/JzzJYn9qg6aZBGSDOiLeCpEV71JxaPdhDOM5Re4tp3t/owCTCevIdxQyv2DBvdgIPh8opDpgq2nUSXMKs1KwvmjzAD1JqYTp1tzQ0wC913OaGROR6qlXdOto/Q+l6jGClEA5Nkq6y8KqYZPgzflmGxGWQ7sgZ9yA6LEd8+6wSJsn6xsa8Pad4eHw2sKVoJqqWHXU2IHHkNK6yfYRe6hHWlJ2vOVeILGATg1SpQsSuUEuQNfStk/v4cr4HQimUALI14xd4SYi72KdrSOm+MwQTdaNgobSfvmlAkOCPO/u6704DrF3FUKYotGYaBeTGcfkyGbUnGb4nnwOyJShM85bw122Oxogqy2r43zCfxYlYB0pkWrmCZnGoKGpbPMVjzbFJd04RBOJDBL7Jt6Vt2Cso3Hj/0XVznz9JL4YP9tatv+ks5FkJhxGuQCdU2onzEiE4eAMFFHcbQSn6uHG48JLXMu/affjig/6i7TNjucU8AoB6LQuAT8UmrysHFPlcWiYg41goiSaJHjacXVz4j3tYreCA9CtDopWffXRriXH9ZADZHJwpePttFMqxTJRs12LlWQSJNByaSt6qyeOJJNy6t8UaIpRQN0GRj/Hq1ILFyT652XWK/cXmklPFbj14tCXhOzlXwuVlrBpamEd0jLaxi/sRMBy2EfCWdUqkfFJZAQG5VIzhV6tknkLaeuNkw9sJwzR6eLr4gJTXdhNJ1MadE78Fkq22NkVVttSpgAgoRQkK+FToGuz1g4SbDVRKkBg9MEwa5jdQ4rBOMP8toNcnAd4+yJf3qTkDQHmLnH9NzDBTzahXi0+9jk4tgyyI84PDk26kzssbgzcegLO23vuK9yQVo0Kku9Cou4wzXGqqW6iuLWyjtAw0ByAjL9Grj3dfFBOMAZQv8hxk1KPf8qeAzb28lDBPmTEtCjkDQcPvwCU01ZO4dLO1pq82btmSt5frfYCZLv5fPzc249bQGVCdYH692B/nVwviW66sL2KOZqC6C4n5fTOdZjU+TKVUX48h2zCT4BU/v+UmUz4iQBSfcV8e8GhR9Va87qjtQrCanZKizL7/Anq0Jxss+vMC8Md4X2UfNsdq3mgYDHbiEuncDWYlfSnB1NEOIHfGYU4OViXCe1Iq/5HfEAJSNi/6bERZpm5xUiMzvJwQeF6LesTpjGOe/Jli9mTYkYVpJov2SjVgVqKF5VapnLMCZ16apeg9igvpszA+2UtKgQacgC4Gule5ndlRj7KJdIkMS3+EXxCDOXnkc5zh67SzLzgpY1Plt65fJoEc3MMFCjlgIYKdE7ga66IV+9SA3XITjiuoRvsM4gX4Bicb3BGmopzS7OE8llBgoXiBSYbEFORL2WyAQd9iryoQ1nloRmH10ij2q0/mHqY5X0SWO5tnabV8jnVWMTGy6oOTXWSRHkMxdK+Y6IlkFJEjfa9VWwKjJtKN2Oy8rdS9xrGoZD79xwhZwqgOwTd+D354pFr+BCpHcwP5Z2yG7fClAksCZds6dM1r1AdM1gKWWWvguBHBgndVdwUgd1nNSBIFd/S5HHFPdfUTThoi67IcouZ48TLlKyo+238QsLSCx4AaTtm8R44yiUxKproCBqTVvp1NcOcyJzy7hOpzkYdgSiFxRnkjUINPg+9Spd1/l8rjK9/0ukK3Qt8RxP82euY1f+TN6SlS76oeyrW4cktZO40vXp2ighb0YMbZUjaA+0goPVfeD2dh/fIWXf9bDBl1nhbeR1sPI0BTpaTjvceevLjoKS+3cVtjlrEgY/hXM9StEKl9uDN/8wPLb94R67FrOVXgU79p1UHjdu6Oj0uT88mmu/TTaSwuNxtbKdydWPhN3IYgTGA98UUlsiDRVIm6dKVhD23xZIxuiVJRqWG0jBARQJta9oLO5MPu6bMgCXDc9fcSqJq3TN5crzoylGHNKRF6da9Y2XrCtVqfmzb8RQrRYpMjRaQjob3UqFs3SE88n8gnUJjBLrDHTzXfRBchhcMj55AnGPCECXQo49jlrhDpYFKVyiIJ276/5SGdarKVdXhVvG++2PDrvdcCsmRULShkxrR0S8HonwYZmL2ljCMT2OnNMx32UOg1fDenAvR2xr4e5fgeJeaujOAa2uZDSrG+18GkbDb9Tjt1nHcY5DjvNRLCOYmHjHYHjS4B14fJw1Ft33OKuAgWqsYvUwbYzB2C81HrG4FcpCzjPO+C9Y5GzjD6hwcIdRkOoyNSZI8FZThadUD4M0LBzCEkM2U/LNWgpZXRX1GSikl8kWrCOVo89GKroCoplDmx76R++AqW939Bjj1HPoIxcPHTCMaljOpZ0CPwHLagylSg9V3kVyVo0FjiEjnpK5fs0lH3untUR4uDoI+2mI0KFzria7w0FUJ6o14gNR4w1mmfkjSdT1HCRGFlGCNj/i82jfwZDBNXShRw7fxvmkYF2eFB2jxKxElmiiOggpEdeSLqz6hAhB0iQwZjQhcoWFsUOEVaWrtPSzsHeUmOnNpLhKJw0lXTSVrndhJdU96PgffI8ThKIspMeGrUWSEckskzIZtgX7tRe3q6lSdNTiiFRjRnycuTN23wNzKBtfpaN3nnPP52CtqocNfk3OIPwBZWjyH9bfp92/4X3q6Uusu1i70YvVOtynuk46Ht2rI5v+cL7ZSbUdUj9+s458qsTHTlAPcaNhLmTI6fIYWFGOxHkyjE2eVxTEs51cZhpMrPlF6q2oBDUQA2Vp+2R4r2h0lQtXZXGHKrhO7ecz1fkadJQWVYUincFgunTOWBUvAflsb8p0tpykFMInyvcuVkZ5Ee4ClhQ1qGt9zxqgEy+iXq6o68AU++b2ZRHMxIxjyQpjNi6yyvRCWI1NqOkyss9SK5lXdR4YcNyVle540/ZXN2D9uOsvB92Tg+7x0tfc/f3DT6DLxWdmcTk4CZL18AyR0B52EVok5cCbAo8duZkgJdep7cAFvE0TNCQHs+nUdMKG+wTh1VhPHp9T5a8fEr3nOur4FJp+dGImjj1bQftVjVEFO9jY4BaS2HPVtcnDxmvTlnz/DPd7tv/uCCSYchSysWK6T4JGnmOpHE2x/GxOXQj6LC9qNQoS8MLSMeH5Ptqx399X4BFTBB5WmhEEsWhsg/5g6FP47W84oiUVbm6AvBFL42o2NB4Q44Vc6GTujluW4OrmpCLMr127FunPcg4O2pc7YEZfH9zV+FIc0KyX4gKzd4yznSCockbrnGP2H3rOvBBiR7H22DDL0kZ8qWBesHc7+xNebMzDKjE77H2Gq/Ouak7MqopocUljmcn7dLJc08SRbOnPKRF0MT1Z9Tq7/lPIgvqc7Dm2NlM77Qsxt/iIvVm0doRIH3Y9OKY2dKjS1SRCJr2CoLi1cW+zHjScQTsn4m0e1BMcNVojSWdh1z7xWXG6B8KKqWDRAPcClsGWv/3rf2csfu2+wdDsGPPHn0v+k8sMU8Xxh3mynC3yiQNsQt2RzL8Q8Z3ct1PKsEEUT4rKImQggcmClfcf//5/9Pv9xEEOplUYkofV/se//7//49//T7IDsYfS+t/A6/jfBIH0RBuaq/u7ZdXklyX2zMyK4m8ilhGSY2EClJyoxlodlpvQwVDIiTrVsSOd9ULaKMoapTlR/b8pMUVDEvB9jJbJz4EWOLwnKh+kzIsvO9foirgjEj5N9oGen4nvv37cuA3q7FEsbymE8f79jDvlSIxWsvooyFZSIa6B2qSbYWpYqeYcGxGg/5FwvmBqeSVK6+Y3MsU3SSH4yY35Fu2v4M6N4UAowvmg/cCZ/UCeYEQR/++c78b7xDj5V1mDytoWR90AUAZtclCvpmghZcpleG81GdicDREvxavzqu1NEJaJDUt6itbaSgSchbbw1gdf/ilJOH5BTmoCDlKNyvxKTT17ITfb/LZ3lBwHbRTOdC7AXiPdA375ELtp1e77F0gX3rkpzp7Yxtk31i+J53FA3uYi0KYsF7LWGqxp+OkrUVOkzMuDjsB4cC5jTm3VVgzIFQXqnmxaDgdMKUn5lqvSGKlZcg4Zz9RBWxMfpfL9DdkD7EPIPbk7O91w2mc+qIrBaT0L5f8/eOvNZjNTBTlWuVatF3M7i51hpWLzOT1dAgt4dd9jScgPflgb49r9BApO29yk6JwcGkUHnUIiR2UzbTMjzW2KazsIuKGIcBsNU/dIRZWPUIDSPdSsYzzzy0uYgJ8R+4jqo4eMDEx3RDF5NhlJG3ddXgIboT+UN0spnhMM0x/fXvLLMEOr4V+KZlTPDdQuSSTUwjbTQQ02MfsmYyQkxwmDG1JVpcN2bvZ3uZ9pqdqP1KoZ7h6WunARggc5lO4rYiC6POLMVZ9wDaqvK8EUdLh7VO6EB8jsDnjNKfeyoJRt2lXigS7NBSurcklgDrU7ny2vR+Td3YQvZIs2eL3ujCux8uacFgnDqrkaFoZTXjj2/Ga4/QrTFKhteT+gOR9/oQZbXXGRUwKDq0ARgNx8Rvo2A1Lj9pIXcpbDmeMRBx5QTowV+OSqmKNhL1F4PyVr8F2DX635bL55HZtu2JyJiGFR3mtieloxohMlYrqcOdKD4UyI03d9m8gr4AyKRKV9WOCWNV/NgtlhujxnWTA/H2fvk9H9aMKKp08soF3Krq8lbR4eSG1gRqbDYPJiMcnqL1xm0+I9+qmu1283PYBdx1TJpK4RuGUkW4OE0ZqrliLjmmeHtw0dtjOseZozQOmrF1rPIw8pjcHiYAd/d/Hmte5GUBNCZhrhF6B4Mag0C3fCIT0pQnP4ovpG1ApR34rfqXbE4sGhzhfuSKmtkwz86oUbTd0aiwI0BVVGPeaTkC/sgzrGv/e5t6xysMfBwQ+bFhY0x9OrZ3deH8HEf3Rgm/vK7bQsoBoV1HMUm1Atrp41j+reOdXv5u8v8elLgTFg3Ifgj3Q1/DGgHXQHc1ax7vK0WZOxWaHzH/m+krqrmMdFLa+v/fL6yZmH1shZKdUMUPbW50EG88Ij4oXRXoKH9/lZ6vhg/nRGmB2+d4mNmeCIzcYljb4rnOIubOl3HAWM/Azx3/KRGKa3/Bgi19ED+gKgKWKGtLiQiSlJbQeXhnNUgqDkFiqDFJij+RKaDsYrDHDmgMZvbrgWJUDZp3uTfyBDnxxeoohfw1mqvcS1QMjA1/uyPmeygG5yz21yz+3BOrVv8AnUvlXzszP7xDq5XjVpwj3e4ro+8Q6uVb9uRiyatCA957J8IT2Tc2phs400YmhBilb+hxKBSWMjUWoIU6iRysNm2U26ajx2nrmVIyr6yjGJsBxUmmOCArXIwFrmHbHAUtD27PZErhSbTk42ESnj9RpNBCy7uXgvfPS7nB3SVEvO/h9pX0QraE5ISpF23gNFa6nLBGZQ3P8vzIlecM2BVE9wYQcJNOn/4QpcIn1SAp3IgP7cIOyDQg65ks+AKbrAcLODFXZyKt6puEc0lULzWbXuxPcoNqvifh/qwxQzDA/0d8UdKqK+/PhdLkd1KyOKXigCFaUcMv5RlxPknWRHF8dcZTkIcXLnwz/f5UxPVIeG5XyIpnVdsx/ghSf3QFMYL+BGPwZZe6lUgGOadyo1d4QEqA8oIP/nrbjK2RNQ0LJjHYXq4WtMnk1veGCkAB4VpWomLbFA95e6VS0oJ3oH4TzNyhu+1iOSUqQ7KQRPXT+m9JVgXKFU54IizARuQcOgqGhuSGxFvdzUn6WCT1nQsLiQmkayK8QBm5mcNN+QpVF5Y4qhlTa9K1Xuj++3xmUqXNwplWr4JphajEaM/FQF1tcMoIjz0gpIeAn0jhbQeGyerruYaJ4J99AafrR8ZhVyNzQ7EbcQqVgAJZxFd5tNOU8cVXB9hJbYRYrgtgYGiYvRB+TcMEql9jTlHS9kRrm7qfQSkUp+/RWnU7tW0jQbWoHjVHy3XGRpaq8EV9IP4Zuv0iHLgs2doZcKDUtLblLfzXCUVYH3S7xzYJ2wT3wUPCdltlKNzUhParIQfq7b7lPl95yBoa8jdR449OAgfK+urd5SCMpA1dH3DF4BhqEiIsnzb/EFYq0zuU1I2wISm6S/3BNZNS8h3E9klHk1dSUqKVYW8CbiSog8jPiT1pFMwpraL3abJNHTNGPH3EKeYBCRtYQ5HzHCF2UvYzwIOO8UOSRskgad0RuryIJGaBJuDCf6EUM25Tq+hsDVDiFNViSpb7mgFLvfndV/WAMbUttQZ/dafL0MgrAhXKoOIXPhxb7HeRBlgeFDf+tVBl+cIcqDIZnUVEpkLpvS985WAzF1vQhUkmnhBAdAsNBjlrmmC40OPhiVYZ8KdeoKB0lKKQdVAwS1e3htUPIKTZzUJWJ9NwHtuRp4Ij6sG0Rq7l0VY6ZCF9nRcymcMsHpU2RcKdAfMQWNjZEhyKET3GLuOehjYRZbletgCQIIkzvf4I002VnUSMbEnEy4Ka2MwamXU9GiXHdJd8WzNSA9pMbvf0bzwi29d7PMe8F+r7Mu9j+BdbFievYrD2p+ZSQeSQVuJZxgGH84LQ7nQeBw/ojx655oJnrtHhLAnAoDcANlH0ZZOV+EFI5zC5V/N68kzoZXVod0mBjw4HoqOvjbU5G81jpCOvh8hCQr4GSMgU21Xf2DllSMgc+kXf37x9GCuOsJW3NDWiDtNEoQzt1fZuTXkgofF6HjriICw7SefFYjhTH5tJ7w8LOcsN0udkUcWSSMH0LMT9ebwCnt/oq3eCaOCCAjecBA4bkPnj23PkOTIvM9uqlZ8/GAnaZL301m8ifZ/n5NyQuMd4r6hkrAH6Nfdo3rmS3uYlqIrrWsxNBgxcDBSJENLLPLKQjCTuWTJ0bZZNJPavoj0yMaKRhI4hey6o/bqrV0tv85C5F5g7H7T4Zg2evgD3k9n4B0Y/MSwe5bekVl9zd/WhaLL54HhCCeZgmB8xPBJgd4htx6m9VtpQrRx9ijKgTSUiuw7zBhSPnurFpK5xOsogUzL+Zs//Htm9fWFx4EYX1OGXZk4yyRVy9qQVwKcbX8TIOriWR4cqDVmfqtIMTx3+kkGlSVxDX1BNjILQPygdwwUaxa3JYT9m2o1QVYr6g2Y5ILVi7tUcgEXCjWNzenmFchIVafVuPi7Dr9JJ3dLFOp6g0i1H65zY0gKZS6RCzkQPy42goS5cWwlKL5uJoEzfKw+Tb6pFQda0jApcfRs5XLFUHEPHpXayYSQpGG5FxAO6cWVRIo/kASEheo8hRTe6pmmA5u661Dd6UdZztMt0uS6LkTEdF6WLsYQmz5QmwpFGOwUXoPBzMawo7oRBjGxeknCGOoPmMCEK0tKOUSOn5HytB1vVjep2VOS+M/G+QhavVMaUfbnHxm/CVPvEMR1yiIpr6nQyqERccZvEXqV+VfyCku8xJYb3nvA8V4HHQM3VrqBaN0LLhLsna7JHReoRZ6KXWCCR2qIVbrh6z0Hu6a2K4vXB1QpijlrncSZWwzaM8s2jItAFGm6+/O3tC/sKkmaA9W5nD2It9hvjn5zOOtOFJQ0EKkfvoFUT+19p4jdyjes8/FXjtxMZo+brbMmwMQ7n433s0hHZgh+7YBuoRhND/mbj6d9KQTkFdszZIy6RNUuTS85qRL8bprsod5f2TAbiSa8LaYRMDPfUT2wi88eUMJQ2XcO8bJi7XD94FvKdEab3jc65Wg1SAJw5PDj1GCapjiYMV+wGYhAWGsUYqOP7Jj6ANW4XWjJiBV9dCdD7YwWnn8iSaqqzXP47kDL/L3uSBpSO86dt5rrIu+B8GDjPpnThhDIETq4ch9KTA/Z95bzitbMD/jMKX/hYyqRSKaBVa1PsklIk7QYaiKQz5XWbWQsA71lxfPNDDtd4KSJ9B7qKBRL1Tt6YN/h32ShAxOqiNIXgSiY88+xjQrvSA/+vCYTsrZR6TELWcjARuWHCPR1X7poRT9AEdWLTObvuX2nCEIZTUVje9euswc3t01pgczoJ2IIs288KFStuEK3xzNec9dNBNdz/BqjQ2WPBELGDd+jz7use4l23+CPYOvIRXjvbucmmxPlsJL0M78aulBG1eWYTSyq1HDEqg6ygyjqZq1ss4NTliBZaYhymwG+kPhla/a6KIAiVbhKpH6iU/A3t/dl6RoaljbyDwpFO2UJdSEHONUd0Q52JwhSFpbQTmWmpxFUyuBi8pZEPStLNEFsvhScOSK5ghfYRZomZycSF7kaxxLRJWo57oftYROYhr+xeJlVF0JPraoEm4ik8cnqUIUZmn8QF6okFKwEP6AkIqrRfN914SHxjAFAWnKG/Nt4r3xXXQQd7bgghrkCsl4OZ2KJUTxTUR4lkbaC9vfpCpcfAWLB8riXTYTNezCBTIiYdSzt6+MOPbqNgauFd5m6oMGNmwcGQ0zPWHErgYiyXahNoYcGKUgJLwCoQgrJ6qCJuSi2XMZufyp2QtGDDf2upCKrQYiH5nB0q3hgJbu0pL04FeRBEk2flVt5MgmwqIvlnAZssm9vNctHNY97ZyaSK0QKzWgIAez4jvhwfA3lBjospAlsxhBp5CDp2O4EgFI6PDZ20bxMPAIbQGTVWFAC/SJqRaJfm0LOhnc2fxMo7+Vj7iiN2GSfeiqaUPRadwE/jElBojyLA1I4e8cg2xchXZg+HD1sgzEM+UD1N42BDOBxhdZXEGDu3Qm4Er8nTZSvMsc6j4hFoQVrdPlZJHD68nSuQCTPA+puJt583pVhmtHM1oTIOTZbRKdxryzBFBv9qVMOJtJLarX5Z1f+4mPFHKI0Be5wVJyAQwJARMzLVFsvGBzUzlBUqAQ6eXIKiJrJNxncoMjJ+R7Ni6YD0rCjSZG8xu6sipuYSu0gwFYkx3BKe75gu4ctTZ4T+UypbNTUbA7qFzSJ9SSBCVYkpwbTl+y2jnkWOcTFr3yjl2xBYPYcYIuqTpdbZWkMVu8ZiiE0E7SKCwLDkxrzRV0l7UM79dKDaSwIN5LY2AJSYc5z8yiZYV05PStIvdwK+GSOCZrOTI6sVEBZu96xzetj/ORx+a3K66cycKackEa27CcwEW7StkAhN/M6QaF77juV+NpwQLQk3CU9hDM0aLpZfmin3xVFNOuOAloiU6A0ci4KKYvl41HhDhLQRMliSNNEgwYs4Iych2v33dtNsDJAeiMp/RF17rd9NgLj5T9gUDcdfFCkIBy7HzOfY1T9DAhE3RWBB+SAzLKGSeTcxJEG9gEufM4iQMxF2sSGBEGGHnItRkR/NfThipIlKFwNfX2IMl3M0165CqOROvtgsV6dRLvEjdE5IK2xro1E5n6tVU1oBzn60YOg0mOOfsaKZ96nKWOD6h05VNT3ld3vERS6bq+bcp2ylqHcQtjOQb21piz8yNbjJ5ILryCBXMcR5I2iXGwm4pUNmHQtF0o3iK53JzGk2JS/tMcQT0Zav0aa4K5Ju7qmQIEhclUZmwGA6wmuab8gB1NWEJCNc7RyPGFVOr7QLW/5ttLR0XYP7MEbmb+C3L9CY/YTFDvusahDCxeO8l7ty6qJ17QMJzKznoBgRtLohBl59MLNm7hlfpSvTLzI/2UIgB0bIbQap0nHca0rkr60zjp7DlQLX5BKT++bw7Pgz7PKdee8HAkBYXB+X46k4krQZEi1jqSOkpKko8kc4Vu5gXKopzaZQjuNPVtrVxjCWYBtk5IuNdMFijVrMCnuFi9zFSMsYANcKgJKePHeisdA9VtN06i51RVTPTDO+n9yn4nBVVA3godOiQGgClksHlj6UlhuSJdJHpaJJ9kibsxFmxEuYqPa3TITjhrVZIW9VmQhXPnbC2F0FmE0oJxLZyniddI+ZRjySLtuu6CY085MkUowXjs9IouiI8ZpYIJ47iTMqU7nmaJyr200+4j9jaCpvQHAr/NH+UDWFwO50RRTGaaZRqBajHNBUa4TTHEFPU/EVSLy+COYqukuPbJRNByzzgtS7+sFWFq2nlgTQsWJZGS+nSYdJvOhFo/c+8EvyNFJJxOzCIHy5L7LqYltzm+pSTR6Zpg9+HRYPj5cnKGHpCEli+tWnvwPuxWLbOJXQ82KYFPPVkW+34f4dldMW+zUPis2UsYDTRP9qDst5cJ275xHJ73nVZ0d8Wru8lEtfqSOK0R3qRnOpgdRkTlUm7D/HFGYUNMrnuHY4etORg2Pk9JJALvxvt/d1sQ5WhjkqkwHBE+VLnhsVgkCFZ6L4JW84oaFdw1cvhGLxwbwDUYGetLvs+0U60kkHKoz2IuSfSfEyo1cD+RbIHoBLBYQXpw8PvYk4s6gWGvb+0wFWNB+Kt63js6wcX9bPtp/Jj/4huTnpPh5jqApbbpxIzr7nJsdPWnZV5S8rOksLsu5hGEo8dwl2L1K3D70hnW5uamE5+W6uG3//ZvmP2k4/ZoS//8Zy/sVuOt4c34fHhr5v7Tuvps6a7nOUefhOfYOQWH7yioTuOc3eDir8sQhSE2YDZHpoht5SSNOjZpFUoeHi3eoC7YmUR9q6yWZmzKdwV51lRsW/6UesQBJhrKUWwQjADZo4HDnjKJ7rIPD1dPeW/b0vzL85EbsD1YwUyl7y2c1pPAGFhPjJ8PEb5OGD3e3fXEePzpiFHmFAxli/t30UIgqrS3wSQfbECNJotrzSwhOQZ5LrVKO1DCsYjKamtItnP26LVJEhdDpJSwWIu5Vl5JRJUtiMRZRNQnb2Gi27xmnAMhrOZVTNTxN9TeL5+wJG6R4o7syXpK1WmsO/lkPYl/vqTGBrnRbzYm9JNPSOh2Zib3A1sZLNsfkGMbjR/sbUDjHgQ1OvQKwl7E6KlGHk09QqiOFDFuKCkZtGvPf+/zYQK1nMIdrXjt+e/tfvLz55klHftw3flHtrktF3sDjX9vdzVJRGYLqeRM3Ruzeyn55HEMAOK2YxKUP8884omp+DK1r5T4RolGIcew8tqlvvHGaXs17cb4rUWzU1801aMkvgDsKi0Dvyqp5di6lnr2TRHWCzT33HngSJ8VTZijyjYHpZKMUypKrFzur3zLb4o+G3hLTGWpbvEvW2Ny0lExQ7VAX1ikOFW+8J3OXLs55+qrPMY/pUu7vJgMw5mEvGMyJtG9kr0XgDB8RWnFdaExPka3obAI3dKnBSGETfJnL8fSMd3DDFJGTJps2dfdUuQv+F+XC4058JJqNxpl80XQq5WDaQic+YGz5Z/YIbjCfBZslG9m4P1+ulXY46lx2OwH4nS0tbttZuf+gkatE7wQn/unFWt8LHbhxfy+roQiwE9aLXh/7am5bCZ8fQedRlv/6199dQ+HeZ0uJ1I1gHiHy5I6xV1fh81mBIzdQ1UxhTwAexyZwudD5xjaohS9mmFbj5Xcd/Ax3HfV1IIybU2flzOfxdrkJ22o0htYPnu+gG71HA3DRzKJFreY/6XuY9VLHWwgUp/k4Bp6lKkopb2Y+RRj57vQPARp4izfSRTS9+zsNuxzrvPcxpQ14HKYwtDl4ZHeJVKJzzzparFvJG8XU/Fb+3aa9RMi2r272QxeYGEsBXHQInNrPQWnAWIO9E2ZSlGXNpLmrurdaNiAzUmyMOnOuK4HY91JjENS8QZlvXKZwq3zWIsGj5Gv7yQWTtCe73FCV4hkluUyijFUXnIPUe8+kbm74XQada3EIxLlg+vv/iZVa5/y7rsWhyvv/fBT33vXqvDQXvmmXGnsYEu3qE2uve8otcE84d0HEUAQC3Ti7nQln6OKW3bkEhPNhHBasvEqv8l60tj7jKTB6mYPVk+1XhvbY7Coj6CMlllFF7euh8bu8pNtqvcGHoc9n0LdMniM/edcl2Lw4G4Fn0EwDfCpU6YTf8IaaEMXLkL9zWpJVK75rKQ2cPq2VKZdZYyiFCExcVUydAe5zNm3HgYaJXXHtcd4z0hTC+WcnrOZypAZBc8twdqtqZVnRe0EtS2QvG2bzLCENAZKQHEsbOghkLyixm7uLt77fAAEQ62NdKtZf0f2P+aO1KeLOImdmh+qunJA1DrVHctHeIxxV+XGPGTG8BqRACZ1mQwLPPf68QZ3w8MYLG61AVBYj8NFwKoHJNuKPOKpLayWIn3fo2oIuM/9E8o1crlTmDuLGK5pee9o3uTwCbg3AVyuJ8fPGTXVFY8fQpEfFS+NzCidQ20byG/0qaBrOsYTOTiHUcO2xqHDDYjRx0o3malOhL4BHZdWmnTOsQmljdSIjBGe8Fgg5Dl11+V8FEEcHReKR8cNaFzisT5wTUl+hFLjaiOYxDA8R8mGmK0vPXncZyyu4Eqe6r7C9KZa6zzSp8cgZVyAT3R+SjDUe6QGgDB8St0obzJXcMHpZq4Bh9xrtlO8WKPEJ9+KmcqGViICxKqQcsXofIN2BSWCdQPLPgQZoJfcouWIiNRE8i1iQZqNn4GCF0SUnXdJHEtX9wwDjw9TICg6k8uldzXka3Mk9j5fo5hhOyDAyut++AkEUBMLYLA7iAkhd/Km7D56zXcHG1zzw6bMaU7Q3hIqVyWJNTfOoS3m5JOytO7MccoVYANRIKMUb0oChpxu6Ai+1lFm+IzzAKSUqZ4P6kubgs6zQKADBxhLtTHS2pJTDVy+kJRBvHfNzRqgt2yanjZ6CfqJgUtx2lrX/dBHtshjgIJZGcVXCLioO8jbp0OXmXjBKIFUC5uVKyLGVV4sK5eAmwl7lKpERqySFwwTValGmfIvJYHMowRzKlMz9ZOO441U66BnFl4CTwSU3vdUNc9uOm4Af83JKpg4we14mE357AnxCfkFgoaNLocK19oCr2zBuDBBmHyUubay+Rrz5E0Yh10E2rJQPAiuvxeuR3JqHQ5npFmeLK4b9oH9zc3ii4c6HD9ndsWKZocredZHpVes6HN4bJWUt/7qRJvP4bZiNimmBwLBxRnZ8Sbqis+2eOCcIW/z3ROxoINyKZleqzVUwol+WImp9aF0GaQCxCf7q9QlKHGb74T3R+8G+7e5Pk+r7Yn66KJQSm6D2A2V47BmF6QvhuXHXYa5S860xFTTgk1zUv39evL+nMHs9maNK6n7o8LYK/o0HhxuRN3C8oLDa4tsbxLGPNmAumNzrhTcjmIq5+69cqEYgx4B1OixmyRX38GzNBLuOUmtUTuwLZUQSu4O2JJxlImYBf+aijAJywKRKZXQKXEZWX/2YVGmUs8TQOHHikPa5XQQTnCBN7PCG8RQcfKU5PMsU0EZlMPVu871fbQuKPrNFclXklvQX3RTUNq21Go567eZCWM6oaDHip1iklNOw9zzkVHXJa2mAU2m0eKY1Ql9FX+yzjTXvVKE53uJtYofjEC9qCCLYhnEpZCbVHlJzOsqQ5j/orTBDbO/Ltk/yPKnUXjVopqINURFpDRtO+sV6jXbbnvUUEFJcQM3YuGUDH8JHB1KDRWly2Nt7G0j4GL0zrb6MwfvRGSJHPU2n2vm+cUtqGvXadkNqafxvI6VR6syusaLiK5S5N+4M0Am03wh74vt0LLZOJ35zh+ltOXiLmGT4g6LYuCIJ1UTzKnSaliUW+zAkYyFyGKL0kTPGHMBzd98hkdE2tJzLD6Ao+MPpMxpBZwMHtS+j8BwzRxkFnOlkY7IV4XKGfDicLuMzOl+XEaB7gTcMoULYFIyY7gqiBmXWHYF5AA4EaaBl7l0FKcSPH4aV6tpHAw7EXhzNXRGpVta98AroWI0AoJ3tNVtPXXxM3PliQeq9aP6IqE5vGOWTuVamtIxwY+WvXWvnZxdw56kpGnMpOaR0ix4ww1bSWWD7y2/Iac3D0G7PfMOOx7e4vvx3uI9d1uzdDjlbbfHZXm/0AxrrQWbFmPGGBgrzlAqzfG4piMLetLZ1Fb8gc1s1aRsVJkM6iZWd+suSxuBmQmHjs2Cxg7GqVGFj9QXrHet7rT/OXMR3Ab0cFE9XdRa7Wn/o9IQWmZl/enQ4hu+qO9q2rKNLarT4fF61Wl/YDujbzZdqDUhQX6tpaiMau0cBljqY0owHaPPkhckMqXiQcKhPl2H0/lxYgEwxxqKJUGkscLl5nEZYzyhBrJcWYOdnqnS9TA1Dd1k+evJ8XOGx/FV2LtFG9GDjVhPih8VGY/MyDaqpULK+3LHWd/TFpN0E8rz8fDVUzTJDXP8uAtxoyNfkJxiS9pcrVuYMa1axh8CYME0Wv7kTIdwDKlTlOcoqQ/UcM3KoYJenstABVq2SCAm5PyesabPTa+I1F+x1GBR6uugg5WRCig+H9oVOyejODHMpi4gikBBq6D+XmELsfV34nPmBQQlcbzba6/ER6UENCeMZOZ+7cnNHazVRrO29LBNcnL3bWLAunnqOQIM64Q3g5qWc2aly83VzH18grQE/nNQsec8y9/Rd3nEv+zMwjNxGTM5Yau954ty8k/nlKhacRdQwfox0DQuYWrWRPghdg5WcQaGiDWQxM09Nqxe+hpe3XMLQ9X3bVs/A8bBiCbRITGshVZgT21lj5WGCWAwgTIJxwDSn9MPy3LisUCD5kYCoYWrEXVpHIJ5tb0YebFhWq1pLHylsmvsaTGLNh6pPRu0dYQQT1h8Yy2ZKsxlNJONv6WcDUTxA5IMbN23imzBMe5lieOzNYrrJDMbtvjtd+cX0tbEwleSuY5++ipifw4DWLeQVhlLKa29F0HBYJv3O8zSk5KYhvrN2cMlJq4IWJTUqdv3kglmMqZrzOURUKgfjHHINNMgLbzd8/NzaTyr2J5/sA2rV8wYAYSTem9gdYSXm/Iz7MGgHhwI1V5z01Sr56owLQiemheM8xPcSkaPuQIraWTazkUGdG4OF31wnWtTAYshrc1g0NAJlpkDbmIXL9XoO0waZmz0DUOkxqaOkYICdpfUoxL+rP1dSBw7mB7E4OPde9DAb9KqmIF8YXZB+ahV15JEyhiQ43A3SZZw06cZJXGh8OD5g1sgiASDEKCAP/yYTUboRFqYUuQB3NnxffJ74EnAZKTjnGspeK7OSblLkV6DhD1VCZiTULNgbC8XRU/ojYhB88mI2kgHRxkgfS4JHlb7xHN8sDFZVxIhUjSTyfnI/tJs4iB8XDo9uWzHEwJOtLhaOaMT5gsqxhwRLMcFnMxCSOct8c1MQP3MPtnoPed1YMI+uwdw7T53mQe/i79DP9awsVzOVE8LHcau1Hum0Y1X8Md0RG1ht4i2CT9TG4OxLU7xmw+i7ZrRyMeH+aCUVtBYBTn6BLSHDo5FGdZkeNvJxav5d2SBYbYVNzdk/bRwVQjNI/zrX7rBkcPPn2bTZ29Dp/S5eDhVUD3dgWeCEo7wN+qdpz2UyDRBy+YMxAlPs1aTqvL1cwUK101vgmrZVfGh83Dt9GBnMNjxu1urYUCp1aN6yS87N5hZXt6H6MBx7W9/f/dgLwm06IcqsW3rIi22LTqjGx3XWg9cDoRE7mwwTLbbOtBHtwWqobFwgzm/GJvBY3blXf4EJXJSeSRpyhr/LEfK79P7HCd78AlOtn15kgJnT/gNn83GBw2/Dk+62a1YhbTm+56//A5OLEdme99PzucSmkCbVRLMbF81x01ci4YM0y0IwDBf2M7TZTbKcqnEoF+NbpcwDmEecxMwNrrNd7Qeky+VxacWSCBqJR1Zb8XVfyrMtDsZmg9dFneSsFVqkDyUewSmLCCiPp7Yxm+pzwJ61djuR8M7aBBb91w7uQkCDX+Lxt9S8QsWaCbIzzWux+BPmCjDrFrduzCT9vp7+V3vazlBSyrPwyayYatHNEaivUwxEvD79H3KrVhdFgmWvjzXvJ5iFogl8uSRofoUjAMwBKiREy4cQdTg2OgzPUY+CtD00EBAKHt1AvqWGly0dE2AJGYd3BuC0fVB22K1xGkLBf5R+mewgskn6juWzzy8A7MwfJIyFinAgoJ47BsDz5yySs0YdHPQMyTo1MibAgwKKmLCEg0sG7pdpGCd/TdNQxZaulN8Aaq63GLRv8WbQHkPVIcll2iCLXo1A5/wAFzLwbRUeFfEtnXpZbSNkvSkKDyoNsn1rDFyUOcYx9OBOG1VQX++H8hkDlfpuAYlneKGKj1TL0dRJnlC/LWsF++rNEbXbqqm3S6qZ90oMXK9aWm77KAnmwalG+9qvRhJLDwUBZS9wI0g/O4F/iZK3GERJumQ6cjTz5StK05vEwrA1D5F9cVY4/VysuL2GU3UtS5hDdSBoFsJzPG8UGelpC7JSoOz/tMSbiNirwkiu98G6a0psS8ZViFwtUgQOO64RLRsAhu9Ubi41v7GvHlEldS7esYmIpNH3765EzGclMg0ge9LyY/v8rkiVOjMwiWpXa87AoWVtyviZAFYArMbTHCYl9mzQfL/a+9fl9y4knRB9HfLTO+AnbtOkZwBkAkg75LYlqQoibVFicOkStNWJksLAJGZIQIINAJgMquOzOoxdpt1m/HXmJ3X4HmTepJZ/rn7Wr4CgWtmqvfeM+pqKQFErKsvX379vF1r7dXae7XOntPravv7tf2DL3fpJ8Ew5Heocu1Iq6jMuE76VE4df12ElZaIXlLZZuOHkFT2djljiVbJigOy7A2R0dYUWoxgUlsgwHQOqOjDFkLLmiNl+eXkxMgvhg4aFYej9uNS2JeTEyvM/Ocsf6N9nxtw0n7QDWhz0cd2q3oLNt0A15DdANOSRz40sXl0nE06JKImQoePc4vEUxh+LFhiWk1pIvp3Px89mnJ5eIqaYjNg7Z8Qa+P+p+6I3X8mFnKR9b9yS/Vf4RSnmjYNIMXi72LnaeXXNC0IJmBv1v/NKLNij1ImZauUv0mlMoIWNEXb7oUG+0izp2rUWX/AWtkRLrmn1d/7ITtG9S4dR4V2ISL7Ic85TgWw00cwCEaEACrHQP5eSeNwO95aucqLqhviVMTX24FxRyEHMXVMmJMGPSgSBk7UsSAOevOlGyXvGzpmu3T2+3i3u6kEETEoQ5SRYxe0XP/ItZhdRXPfbrRYzPJQ8eW24zR7VA7+DhtWMrgH7cZ6TaskAC4HPKcBTfPcQ9/e+hE7PojaArMRme/4N0Ta5LV5qxQl1NtUKi7YHadS2fQHTB4hO0kh0f4Ia+sXJSVRc6vkELAdtk5ZBdPpLauIUFkqpkVnBTkMDaP9iHdCtLLvJFbvZcj5Z2ERNpPAaOelvxB+o4LkskyLlxFiNoN2s/eF/VkLsjiSnhhyVGOjs1ZOv8AKT52IqbJOlHVh1FeKh/RxHDXO502CWwn8OlhpibNYEygKgig6MWc01DkulrNjSDZjXQEYMrhOyXEDEyIlYInCPCJTKja8ZxFlHtHUHpl84KscsxXYnGxq6pdLYYIIGosnLgVfPJoR0kmuhMBm437iE0gjrkrq/pRC4C49yoyZOvR57CEJlh+mlFdKzRUp6QoGRNfHzHfdWlAtJOupVAWXcVgJd5+xonu9tCi84RxPkRNiUo3LhGj8PKIewxcQlTzgUjQ+DTAbVAWyBSrXML0YaZWWZJLeTBChg/X3dhLJjvPRtxzgeCqZfWVSTYIJBPjmZuRcnGj10MxSOKoQCpdqIxGh4zmosnRTlbtjDgvAcE7FQS5+3SyWu8C67Bqvspmus4jkhoOFFNHNEmE8m7jVsY315+O9x3kGDyAxrYg1zPdK+s+EQVRILROWJiEKdE7Pp24PbmuvKRA74LBT+qlEWpKoV4oDLvBOYwRPzZsocxrRMI+otUc2gJaYRDeVF+ctZHoXCbWIC9ZWsL301S20tiV1xO1xFLm7VcjO6NYvDSolb5LkZZmZlODPbIcP5HSg+EEMN6Nlk1iVu1qn94/vw+9QObR5nBXaVCYXPCdxLouhVVSLYIIjqCAEM/NaE1/7qfCFMqRmC+QRzsWIKsGK6J2Ngrbg64FocVYfDgYvG4xVxAOJkrlqG74n33yV7YHMLrUQRc+m4n42LYL4zMnYwFJj7zcGNBtxGY5Uy4PBqofmFK4NaX6P3qc+WfNR4bq095emQTEiB6eh8zqUw0AGwUWYqv0CAO6ccS31f6IM1Qc3ZGiRS5pVwwIh35MCvX93BbpiiCDwowVqc8OHeZwTdTzDG9WkftSKSf2MXLHf4cfaGafAE58FGOOPHBnwgkEnSoUGzrWkSd2nudM+Ov3CvAs9waulXA3WGL/xSzlCBSXM8mE6XynMQwxAYCdbNsn3XGdjQKfc+G58lIZAZkhdOQRP8Fo0a+VSV3KFaE4WFxoijDAxwMFM7+PR5dCQ+V2jzdzZQrcg6WyiF7kOSfsN0QKKtrc8ufXBj0RxO5omHxrXrkW06np+COMe1Qe469FYMlR2P7cXHZFzvOn0ovDmcuPSQTs+Kq+If5eKVJN+jGrc4yKd9fOAFqLxLJxlj3JoJG9LKUpNCPJitZMSJMZcxS1/ahj8pZcPZkMCkzO4MSRnIV7DJw0hWsX7NrDyNXchuFPNsG1F9iHuAGGZ9eDGKNzwEQ5GNHzju/300fupGMJ8yNV0LkWYeRAhRAbayMiMiGHcVQA5PLoHAWR+WI328fEHRzqG8t7IIiP+FA+FKscUuK40BoILBswzZjJheXWzqFbF+2TCKfh9aEEsLCQKWSLpDKlWQ+oNcinxrfogj1ZytyhhaOZtEDBK5KOUK6RKGBrFkZmU/2FM/p8+gt3P25KOjw6P/+t7QBDT6aCKqA0fSywmpQVHJnn66aNmYSauB5og1P/IhCsheeos5dLC3qh3SlcQjlObbp+6/9iJP+7HHw9gE62dEfyMgCewU8kfzGC65MQqr1yO1E/Lx89NeNIAIIM4EimaZWbrzqbeCoElTIdPMYevdNTuC7cOIWieN1iMIb4jDiDESqLCq/v500fiDhRaGWQq4h2BFAwJKNTICDGx7I6jI4995qpiqGSCzRd2h8PPodx6v0amaJIgibAlOa1yamI3i+Aw7Pq5tQJ2ByGzJQJKU9qKiT9dwqbYXcerPfUuYINg50HYEjsqqFMS+RWMwmRV7jMsM/ufgUkEzQtQAoKOQ3Y+KnRPHGQ42Pnl88/+6Db4i8H0i//SaNQ86RdubtNao4Ef3dUeHutn74Vj/fFfZ/n0C8fO+Y/Vj7p9bAz7jcPy8zX5R9/TUcw/wel5oB67Q7/9Fh4Jj0HnQuXOJb9LJGGf+e2SB7t5n0IC0psLrTMvs/rBkSH/VX7brqxG9aDWMrEpqmOmjAwTAv/CfIp5cmn7GgNxF/iHAHIm2Uje8wYY6xWSMmrVL+OkFVVcl3YQ+a1UslROXfipGRHIoplD4Vrexapmdt1D63YEBqFG65tNetmUXOeIEaftf0Ba9MtYfbCqV3n5txGzoBB+u7h/2SWq+8VXOoyzRqSOO8WQq0fNgOiru1JCUCIYShMWxPZ5QLRLcoPNbUCvjgcWAl4i5hDiru5U5YP3qQmMd793Z1cBJJo9TmeMSJhnXPwugB9PJlC9bFgImSQoVv3KjR+uGWKwM5JiQ/nHsjuLFk/qbjNdQOlUCDq6q00PkB08sIst111UNuyJRJ2aoT6gW3YKsPcxy9L0ZUxOwbaMeOmqUPq9OJR+z9f6oxRErbtqcLd+wGH0CQwawB/DVH7700vJTPyyGJOuSa7Pr3YuneDXuMEdfVrbd8LnU68j7UGjDrwpdGBQK7/cpdaermiTVs40sN5LKudMvOt67b6yy/WeBTwXCTVabRkaPUHuS/DdQuCr7ozrEogXsE+gDfl46FPuBblCk7PcAsqhacrIeOtYB11vY95KQ2Ff2YahCXasCevFJ7PwBW45Bo7iuHBhTLy30e6rtCC6qJryuPKsgE0QLT1/8+LrMI0pOWzwB50L/DHBv/urlv8va+/oeg821nvMTnm9N9alp6/We2zn8aPWo1r6rzX3nyc7673zy5pr5faOstbWe/ovu//pO+DntevohfggE8+uJ6ZdT1+rj4eJNkAcYmz+CJfcaaBeXEzE4Re3vKLjfuouua/+8ff/cIpW+v+9dActdR/WW4g4kgctkXs/r3nDK5Lki6ZfJdwWdxpvShcTCTZ3GnLao+hjLcPrLVeWo0h0+pC0dIKEnd7nLLJLGr/MhV3XlHK3/jSu84FEYASrbBi3LlI8YolCWYcSMRrbElt4ET9GDLWkQqggV/h0v6Bk843ciO3AjFvBWctkpojR50YBe0WYOkJsOMmTEejDRbRyQnOxB6L40x0zdlJ9gxtuKLR90bDypKOQvH/6v8h9QWas+70Lbsa9ywY1WzjRdpDqdVD7na8kJ55Obx//AXWy7vdKekEtr3kof/xv/8+7uODijU2AIW4/vUwnE3+K/1c5Rf9JUlftD49Lp+0JpLBHtf+X5H9nWS2JogRJk/IQAGtSxx8e156sucQCZgDj+r1SnrESa/SaXvc+kIECRN+TbGRvX++siDF5CIxydNus/YmkP4n1hLYVARTEKuTaiv0ZkOQM1FoJfw1fgc1o0heHUZGO+RjILhmKbV1RyvkTVFWXuN0wMk6QpJ8kZIpj/gjfhHzrtM/if5/m+aBLuIsj8pwjGd7NnpxZVC0mgPh7XzqJkIxxEvLeo4ouBoaX2CmslRSu8n9Q1tE0uQJHTWpvs9Htq+cvBGNhAynI5vTT1vl2feKPTyYKUpuO3hQ9l1nIOhjYSfrxLTne3Ck6tePaAsjoYHfvWNzk3JG1vzTYQmSDXead90gohOeUSsYbv2n7oN062MZXutmIrMdeIk6emyvkR/uC96UeU527ALZ/VMrG2W4ZecMeZB23ig3acEi8kD8w1a2/kodtu5LH0Uqu1n/0lJXOhnCFy3w2KiMX8Vzq5QMhoD73dSSc8nQ77KWNxQu4/WYebbmZG42Jd3Mqy7t4V5+Vt9MEGbRaBxtsJ+Ua+1BTZXoIk6a7gbytSGwQGLhwN+V3tqz4AreS1AIbPSq2+poNSkS+WC2A+cQKDuwZm5US8qipkZsJGWk1uOU6FELqP6RZO1y792kO8UtVsSriK6H4b80tMK4fckAiQ/5yAwHprjOnDOdRDH04jex3clakFoaUkqPHCRSBYxi0lJZMMrlKslEc3bBopaXK7QZsjIUFqVJUIJBpcBsifH93qrckn03Zrq/k3L1dOvk7je3lJclrGAzA6vk48bG7uc4HdgsfK2XxsHNi6U8YiZ6ID9gWgjiN4BDdWSUGjZIUsWmY9fuD7XbyJddvpWANk2BkaIed8LG1mFHm7uXS4QlHHD1UETNFJze8b463vG/WHQ5fNS+ZVdi75dzv8ddxRcqj4wMTLtk52UhoyATOmnJU7tVAH4fXehWN5BGOBOEgfMTB12tv3/z0gpSNb86+P38RxVp5MP71+WTZjLyuOnmfZ1anDw+grgG7GiR6D9CZZnYULYOozgcdTp+Rb3AylbgKrThF3gTmD/RchNzvkRMRlPeYXOmKJ6JRaYzleZ0rlo4WMR3cwrPru3tia3RyTpdPiwrpG3HvIYBIqsdQtb1Rz50Rd//U3U2BdFBOS6XXr9MiC1EVWGmKN5KcpgJ1HCZcKCFibOt4Gp5bXqYNZCutU32uaqFLrmPzI1jZgvJNDsNzynqPY4FDodSIlz48ExWIqu156clD8NL5USnGOpaJU5S11KfkxVbGWRgGa+LROzFI2gbnzmy+F37pUncEmwRSDXchcwyCoOl6W7Q9Or17ocOg9MGmtRUxktHMDd1xMkl2Ki+rLyjX5yLpCGeNLWqIp2GsVSk4eYrbgSFHtf47Rb1mabFJUA11yomgnPVIIDqAMRw43kuhNuBUElFIf3Hth2tr8pLuEbkyQsiUgHp6cEMUiiCERq4kO0UxkpLNUDJaIocgOqbEFjKPy3ebzI7kt4JvEi1Bu6J1AgQCfNiUlAF7BynyriMEgtZSeL61SQt1V9Blfnnp7rwNqEmzfUyWkpwQgBG5ryPoajFghwRAijyQm4suXL1Vxnmx8QEpIx9vMAvhOetbNykQirPb1QkFEQAB4PDgaoB9RohoEh5F9lfsZwyBSz/pVgfUPeRpEAgt3cVkLKCdpuIu2VWd11QXKGrW08yUS75pLq5jTc3aeW7zX6IEaAJf84eWtyyn84aducJdbdLn9bxT9/ywDeenvGXFAmM43HAgGTISuirLigwAnA6zhhuPO+OIyI3YCY9upmG7vqKMIJgyANv6W1cqIcaQzxmDR00YgKzIc6n8gnCuiZrH64wUkMK83k8Jnq3QEhxc0GWSO0JPY/axAJF7PWbxArU+KVMwqj39+x4MTmMBfAAw2pVtxYDnKZsuGVle4kaHvpgfrZHUGX6rtRnk80+Fz8pGvFxextxWiHpxmKD4Fo2G0hcD1XJmjkfNy2ecYUXRkBuQRzmrkfWAaS4Qjib9a+rLPCBW+CZlkVkVc79XKGLixlA743PEMgDITs8T2u8zKII5IZqYgiNXQZ7MRtmUGYP0+wB0T7P9QLNrXOAeEX1CYTETRpjezGumN780XW+GXCjBGbCo66FzgnBxouYkkzqv5bq2YcPZeK+p1CWm4fO8MSIpeUfjwmcRR2hheYa6+l2nC/2V6odlgEX3hhqJEiYzTvVesVMwr11S/o2jZ8++FQl/XQI8KypW3+QzshrVTwkTB5ZLzeGV81dY3ArOjw3BwN2n7rcvd7urdev3STYAh0VYnaNBOawUIMvVqy4nia3KOeTst9QpD9Au5XkdwY8/RKUZLRojldsmXY8gUN1h+fGbb1gOCNK+B9ZfdxHfRsapIpuyBaOozJ4C9Op1uNWcEHSvFhUubuMUIcXtULxGyU/VgtUWRSfRqjmT4l4DAefGUsYQ4SLPZYSURPFR7nso4fpgGws5uuEpgboh5aPLbuIlwX0ersrHCvAFbjzRYszBgX6w+ZTjzt35DNEPYaMhq69n7hq5jVo3FWDNuI3+moY2d6zXe5ITES/WbvixQhJkUYCLX0S9bUWK1epmTwCFAB6x4bjWXZl10yeKdHC55qOP+UrxMy1lIt/oxCW+VnI6PdZ0+ZxmxZOHI14OY3GXW9+RJyW1c3mOB+1NwHqo5JEpREkl2LNJKWOPuGU9OuDhkyYlcVWaiVaXLpTfNs1dSKrAOpehuUpH75NBxjqAXhdBSPFZ/muL5l8DBFMheyPoMcfSrGq1gdAu6huvIspwzhlMf+/dS2yg9iXRMkKkkPSlwhanrUtZZNSskJwwJ+NRQJrPnwvIjPc7pWBRk9ms7d294BcupNbyhZDGmlyQsR4ZyM2IISzI3vssf3796nucih4FQ1hJFyYMvbwIBEHrtVrjPjNkgjXU5MKtbPHnFOpyC1fi767MzoVDhELVFquPxU9ruOVd8kCBUOGQeuLUGqLx/mw4tPe8AWeKYQhU4tTyMU7ihGI35SC8bv4+vceQNiGouEzGZhb/9la4xstHYEPWBCvpuZD+XBGMw0OLLNPpWEv+H0fdYvwF67IvNI9D4y3LOgRb8EnpQBDQelotAkyDeXlkFWYZab1aZRHTtNfzyZzN1d/1xYCTQMZDcincb77Vj67pCbFP9O1BJ/mYyxhOufJ2Xcy/dUZw6DJKBf6+Ty7kNteCkESWYXYrV5e/pJWi/BmeCd3vW3Gekv2PU3PEpgjEDoCrefU3LqqkOb5z8hiAhMSyUzBKCRA5WXhThY8uvUuq1UATD0BZaZSE/l5wRyTq6DHpYPWAeEn4kU+CxVxd1CIvsuhwGYoprm12KKGDercLL3cQmhC+to7UJJISZfESOEqiFR95j0PiOxZL8INVuqppFWHE6oTacSITNO+POeZyPhpuRRs4mnfhk/vbekbXG4xlmUH9daSgpzwwzKOOAWhsHVssLjb5RVjTV+ZMqvsoE+hjK7GtnXstmXWlyPmKnoxc+C69FVytKmHxf+ZsHjKPram8r9miSNnrGwW+WjNnx23CmglC64YxpsQscdeuN876mjl9O/eaDL2uvr/RZMzlJSI1hb9U4F44bYcsCZyMmkwmhFbKBTphLy3UUz0cJpy+GgE5S1Nu6xRjI2FOWq11uefELmtzWlDSC5Kpa+DaKPwLWAZFRsAtL7cYBlgqAbYeu/g5DfUm2HZHAbOjnMy0Y9OpqTtzwstjK9HsBf8C6Y5AoBi5M/I/M9/ACqyZa7fmEBmiGREF95svSJdhg8NewJvWzRFcN1MPA7/nNh9kv+6RLSl2WwmwGDEu/3L+8ud/+XZ9xbm8P/7N1Zrz20AzIpCpA8VwgHl24d1YXIa3JsA6yjzI+0JOwjXDZggxV5Bk1cWqEqqEznDtAeaH4pLmjgVeRnwIOizyGwJ+VkY3SU3NCVPwtwrxPSpGPm+cHeZDKTy8rvj9cwCQobgnmZEM7VJQJdltJhnQ6kqlFS20yBUbykfpZTb1gtwQuX4CWOgXvc6WC2+A+dO55tjNRoDvu061uL243x0VZqo31+Lg+vWtNzFJbBy2dq9WEV6JxtUs20LSP9i7o0Wk1LsV7Z/Lj7S3QaJvtbaNFv+RLHwmR4KmhQ2QS9Rnt+ioTF0FRUIC0Aqd9eDxNVry+2SSccDRbagSco+bpWe2wXTT+HUb5eygdactWzAGu3GevF/wwXWHijQzej/klrVNblmb8M4tSvJLLsIy5NPhQcvi9NigWW+ijzFAsWOiQ7frCWpLCMeccp1WZneokAp/hM/BFT5AxGKRzX2usS9+/TNqigALvM+FASF4ppyv6CnHgn5LF+OEMrovQ/CNDzeDA0NYIF70YQ40HnszShXIqY8LzSw6HuxYhI6OQgKhXKVyNNn8jZg23TQ3Kder4KXNuGQLBOEixMz52luOgU4mVJQ5LQrU7CaXkY8ZSafuQBX3eG4AiyhJrui4IR1vc3zuZttYPhR7iiL0fKzWK37SnCFj3Wjb/MxwWCRiBzUh145f+jk1Ycda+AF7NE5zihKeStylie9iTetP5z/+UMu7v8K0JbFnWk7umQl8IcMahaRxH9+9ffU91DqwCxPk4OtZhepbRNUolwdw8umGwoVIC+LZYu8cVbWHFCCHgvv0RknrgueBQHXNplwSCXVJCZqZIql1DqWyAHgJRYlZYglFsXi9eI/4YqmHWPrehCJQ+sCoLcreKF5vm6tnt12tVqT5QU51Mu8UqUr4oArx2uTACzfXNm+foBQ64fEqFwswRaLd9gSoGgFrUleLFu5eLftvfTyMHZcNhmEoZ4QpS85PHfc+i8gUrOZtAj7kxlgMptcTFPS79+xbOLwYVFG7A8ENKUh0VlhjRQEUa7hetNA3G+lZVkbEPtf3ReQxhZ36mtNTVJHo571ZSKnH9LPL0BJZS3wrp/Es1aFwNx5MdMc0mPYbYWJ3MTMf3k34XGtEliOfmRfcAdcX5v10UcZN+7CzgZA6X6zQ0wZcB7JFhmbZfozL3ZdIU4ZJjhgKJFBeVmkI44QsopmkdpNMOP22S8y7bJVmzNpBXkxjnvNidE0JI0Ot2WzcPVF9xU1Cvt3xSLnZfilNTCT1qg7g1sRm3SuPeZP0s1x0rwIFZBzXg0TWzT9QaTdi9DYvnYuNUviipA6iCi1yPiiI/T7ZyNtrKQ7PWo0PPSlqj5kFUMCzFPZEJrUEWeiNZBQiKDNjupmcGjMNM1zgYLwbP5iv71s0UkNH2/CDu2k2a43I8oOKMug1exSM394orfvt/VhQg6B3A7jt0yjLy3ZeZ0eq95fj7tKaSUnN2qZk/9cHCDZ433rMkFyglZPiBAMSz9LJsDDJMwkC+xWDYMKg+rSGSTZK7Wlo8RBZIyBJzgbXFrejHpuZECyO6BoC5td3WAaD2Gfiva+zwHMcX3gvGpp8o/HnSH2DHDJMJ1eo0zsQTYo7A+dgW9Bok0QJA3NZlxM1ooKc4AYQ2DQ1yq4ybulUYBqS/ntmc3pwFeeLc3sIUTrPp1R9Z+xhumk4OOHvbE0RquVT13I79CL0Qv1MEYzU4hM4oj2EgsrEloQ0eY2G7G1cwog3StXcPCNTitHTrooiWMdmgbB8MQUOjyuYiOILabPcFqYBKo2bUfKsP14SqoIqzkFYNIX3zHJFfW8VT0mHrYyWZmPSqk6ojJBWJL0JVgpU4emn71X+ThBjmwBvnKtUqzAwyLqThMv9gEajZJ3SBe8oLGgApywtzGcoUUnbq5Egcvi0nJD2dsZRqWsKACBOG105l99j+yOCAb2qyui9YlzO6IY0tgqYtVBJDXHVjIMy3xMdWKgxcyXfAvKKhUHAsMlOHcIp40UUeBhjY6QGEsjtAQYw6TeQTmWqJ3DuqM68PNJ4356fn2Po3qwNM9XyjbvvbRstHixwaDKu8EggNOkA21RU2NdKq45FmNslLCOX9CM9KhjqTW4ttre8Kr7MRU9i4hCGG7LoyPZBAvEgDQYzX2xSAZUXi8TK0Mmhi0QMW+FtjTX9aWyvlvWRRLS/TaGWcP2D7qSIs+CrgcsgCjkx0aKye3C9NAlDzOv8nNnr9kYutY3MNQHPcv3JotLGprMVAyXFuz7Ispoi9gjHV2pY+yKVgPgN7lK2wEkw5lTDIeK985e7mkHuOV3GFMMqELGofBoZ2MbG/T9zaAJO8wOEEVC7F6njYAMf37PGkflfdxHWpLl1iXPdEbTanf2Dw/sLsYq8IMQDsHSYooRAlTF+8cBjJEBq8b8ndDv7+EQ8ANv8y69rPN7a4yIl7BL/wvYBsOxFClFbiXeDr829kNfOaI/E/jbgYtnvnxRhK1zlccUFAUH+9qeX8zEehEzhty5Ujp9qij8pzKfQawRor5ynRRac9WSBHziujXKbtB6s5vVyYEShNZUlGEITObzzTTMA5DKYk/MUP3GgBmmUZ/VuRMl9KU0kmqoYCqXHoJvIbEuyXBaKLbqeYKDfHsjCF7u3gXx+0EGOSUa3XCKdlgzoHNEMimhnKmIAUx/vZ5OW3ub5gHaZ3Q/dZMIVVTd0sySjcgO6gIOkmEZ1o0TJc8NwkqpGv3CMS87V3Cuk/SrhvrCxPuUsQ9lP8p5Mw276wCakSPCQ57DRvk9uKXMtlNMMrgoLY6KlaTfiVCSTX117FZqBgVhirbNphRckKch2wen6Nwki7DXLPr+8bNZeTn1JeR/KsSzTmpbkHr3TUyaaBhaw4fa84bZ2difHSOdOhtB1BmTtoEr1XKTvWUKe6tFs3i1yEuEJH2ziFildS0pVmojiy5lxl8b9AQ8XJYt4K7zP8RMIC5tCY12ofCUUpwQ1MWGrCS7d5/kgn3RzFE379f+gJNOfXgqm5QY216gPNmMFS4HvQkw0cKrGIb7DBMwb90Dh5uXeTC8diTOrF0uPrNYMMRaIE8m5imN53HVJxWEALa7afL8uFDljgJ4e3EaxNZ4XKYCMJIRrKM5NPqFSwfBICfLQfTtQ5ooE6MYgHHLm7hTGGBl7lI97HEB5MzhkiDXm2JGkyGwSoISoRQmEZeCted/SetlgP6cSycCGcU9/HgpOrsn0dIE5Ekz0OpGsNEgWjhwRBQK5yVhL2fCmK6x7jgv7MhtlxbVkPcXmzPjGs+d1rtwoo02pDAZYqj7gVDc7m5fzTYSomHiGBqwsNTbkVBzrqG5N8RwEXiT4MFrHm3uhg08dzboDtwDMlMiufcNBKqPaY0cJI8dD9+s1d+lNvnJM4In4FwYEZOYIYjbilLK0r+LOZrExPkCDPSn+rpsU4KjZ1KgBwxnCeyc4OTPiGe72jDflR9h+iGX7fbkHLmLHSCYFVLUfOfbGmFtg9BCcGHUJgqwGOt/jkX0jh4WKmXlm2w8YdBAxuwLtda9BI55D7Tc7cX3RUw1Gev3d630WFejO4xI5VOvk9xpG0v+VTXfFlEvckqPGeOvZefV7DwcyLS0KJYt5XU2wm9S1n6nkDan32p2s9H4X7rm7y/iM6mXr5LKcdVYiJgJUvdcOz6BRaGfXee7kpceabAyjOIPKPcGSEAYVFdUxkVS48LIJ4vunt6Sh0EKRqjCpNUSZLGrf5vmVk5pfJeOCH2HsZBjzReSWkrwcbPpBiCOuRX3aeFJxe3FJ4xMpcPzWO8yifUbJJOQcQ1BkaDXBFfBRXYzbSsLUZUKxcFPN0HQvCOCGlJYKeEmOg2U9d+/dCMiBIzOWG7vqZ4jn0J3kjvXU+jMPfGCps+3ok2WYJupx57ViNiSYt7/ywsjbNiKZQwYnqIjkq2JTdWkyQ7tNa8BHbq3ZtJNk3QWKFznE3dKn0wwijr2Im7rK0lh2ae0dpTpNASrKv3MeHmadumCLf1zr3ld1LMewOTIbWV8IbYSJOMpjDWwQNDANniziYt4LhoTg0jCKZiwYff7ZmY8E0DLZ5qIjpyz1COWwkAhRLZ3JRRbocDT4cMQUmRXFTF3UfgfrcEuJSwmipBTzZHdgwQAZdY9KDkVFDTw0hJlbx6HegdnELnW4Cd1Bngy81SAQIGXdN+U8SYXwli/efdKkquEt3N8HZG5L3iVOk3Nsu/btwGmJjkOiLLp76EAu+Yri4haH4rnjN0UaxTV4DD0VBoNZjWDZRagQyZ/8n3Hk4hOR4vyYVZOYy7IuqElxFIbssWwK4Am3SAT4nBS3xuJnXhV4jFvvfHwpjZD4wWYzdzTep6MMxbuZwaGDYEFIBoOF5yDgQxoICCIG99v7POurIhgWYphykMdEMgHm4jkVH9Vit6CyGSHxxtj0HldPwrHNEeym18n7zM34DnaNQzEjCMx5WIMGNNxVmUbBktHa22udBBvHVjaNdQcT1a0wXOSnggOsYMV+6XqYuKtjAbb6fitKR8JNZaM1yETHkQLTSmQPpoVm7UXE0FmtUsQSArf2B4nAuqeWtKz5jWOLQk1dARUZObKhHD3XxE9vvpc+T8NVyJb6kFvDTIQDpQrXA83sVSbogsCz5ehBoF0l3aZj0ixr8BG1J4DUWrpb//H3f8/6//j7f4TRyTkdkDxPK6S2apttxQYAcSnDIl1B0Wq1RBX7BJMecBAaze80ourdfyYp7yLrf3XUbh3uPK0krOic7ZJUQCTjprMrYyQiYlbWyC8bXL6hAZl3NxCCm9v8UnH4dzHPS9y2BlQU9+r8emEXzhhQDFUlWEorxAYUIHsV9RaybqAFZjeUkVTeJZIw0mFwpqtV/Mtd9229Fv0mnL/P5xVP4CqLHiIO2qCgFvzeNGC7nNw5F8QB64Dxh8zbrwG67JND9fFSYjwiB2BiHqUcAuUTS9+nBq2OBjxvDT+9B/4nvzamMnBeivEWaUeOEba3i3VfcyxR2mV5Q1By4bVNPDo5MIbcAwrDr8ahOndaCdhnoDy6V2HpMZUCXkYbx3eZxCEylBCDt5OK41SZ2XjsiJUlyH/8/b9jAf/x93/DRrrPeAyfJ1czScYBJzbImtnUPVCotkMRh/QSWiRpkTQEjw+PClmZB0+ecwj2vYD89cs/Mzmdvz77oYgLldmBQeJgqEMnCTrmVKMwLUeQdjZ+UFwDFY8AVJ3W+NltiAQy+L5lVuv4hnT6H7I6/y7t/0e0JTbboEg1ZI3iLd1tc2oNN+FYI0ytgVe4dAPdEGXsHElzN6m1JvDJ67aLGAo1DytGuCEpJqnuO3X6ytZdebZ0n5NgvbpRzLpUSeL+G3YsKn2Idosxq2J3b1m0qrf3QpiKjl0q8jb0GXLztKkTAgBBg0zYjYomaG6ePYR8uy6O1Ry5OFKcNCjyGH/eV4Nk2L6nBslOReu8bUOyaWeelQ1u6z5e0SevUKRY+NzICF7+cVHSt1HgowwE8cRXd4k2mjc+EIJVkHy05k0uSIGGLtxbTsVKBxdlIuJvfQ9ql7/VsHlNmrYKWFLDW7XHqpfTS0G2M2k+6GWCVCBAuBVPOHYYsv1aqw4Ze5rnHKghYdldsv77QiFiM6KTZj0gEv/bLN+wXzIFCEoQaeeOCiQiwQKU4JpB2qxYG9weXbmb7Vrv4Fek7XLYiOT4YkbeYW6jHNZplm+VIFhpaDkrEFZ9F8gjvtD/YmbzS2Acihvaz1PJ1aXmm7UzrgM3FR1gSulLjuQKjW7R0qXkhZmkvZQsYNvOYESaCKflpn4iuheffxZ5dQZ5/q7ma6u4CbA82c/eB4GPWCj+7e4LFDzfqblzlcpPO25Pvndja33Zncifbf7zj/9176T1hVkn+qLzRXiuA2tUq17+pj33Tce2uLukyX1iEm70os74QhCShHCPs7MTsEOfG/TcsFhTrzgQ4k6dFZxbAugyKYgB2yCMPUNKLSKyJ4Io6j7i+0oUsdmIjCqUjG0IxhYVBDm8vPShxK5NaBoLni9CT8HMM5NvG3i+9thN5tkbmsMTpy9eFew6DBQ69y6i5bKnPG28AROz3NfR0uARazTW98mI5ljpJLkhFipJOdnIWMPuQzcydhgBi81HYpFxPW9ZT5vUpO2Ko28+rAiDMlyCL/UtMRy9SW7mqmof2SLp+60q5YkPGW/Ff8dW/JuvWIeUY6/dkjtCgWgobodCxsSbFTJb+u4SzchwQgKTLzbMlSBND7Fop5V4LQqdoykrfJzNVd0F131sQJ6J8+IcVLLcJ7Y1Hg6XZBbj/9zs4yFKgeDabvUYpdDvj6Vpn4dsVxQlphATyq2jWs2WdZRHtt6YFiybgkuwc91WFPeVOhZMRsqQZMH1IvWL3b195sME3ZH9OqU0G4m34JAsOsI2AvElK77ARmREBLWBX6pJz91hbnE4n1zvfm5YgcWofSb8x8DC4VgsJwyFW12QwIWAKwf2bzVIkCLvhHhHpp0iH7xnGKWJEz2c2DZMQoKpe3nCAMG+lEyqu0MRipgj3P4NDQKwVnE2HJHHDeKBn40mZBlQ9ITKVIxmOjWGLSczP7In87kFEw8n6e7JRIvm0uR9yqXHVmYlWxbPZIFd5T77C03yE/Qdcd+72eXdTyGmj2be4NHx3xr2tz3zPdiS+W48Lua+P782IYc/00YKpf1sKK3Mfg86R4b9dvajIMRxOZxYKwBTAqHnShpREqrsSBgBm8+D71Kt0Zj3BzrA4zkbGZlCuRYPGbuhQM35YjV0Sd20uLwluY6da8mArne085U79NPJjPQiFn+80ZgPUCZl2KchC9uoO5LybUbEkV+qGYHiQy1sCoiSECGPFDSXqhc1J3BqYD7dVBb2MTSnIfk/0ZVPSyrPSIb+pK7p5QxIwaXorLeglw+EyZJ7jBwqOsximo6jICzIM3+hhf7l88/+a8U/n38mOxJ00EUPnhFo7eefPf78s5r75y9Uzub2l9pXiB+mD2TclN+0zLf+/Ac8XPsvX9UePZJHMHv9nVbg88+e0GCr+/7aL7IswqIHGxX/0DWZUYjOgHwmpPAAOigeVPWLZ7if3Ftu12yBWAmLYL0KAW2h5aLcNDfCMSLUSEs0xoEB1dPShsmE93HCqP2tr/bcPf3c/yANT/NFA34B5EVe/X40XTRV/dJfdoVC7PFdiFRnv1Z+bqIm5UC/5bIIqULSaVa7sA/zwik3+8xpI2SxhiouFYm48DHa+zkNoQH6kCmwICBXmmQLjjbmxBHgxNngul4+vqVQGuYWXHZxwuWZtHbT6Z21AIChMfJFA8NtyJwaWVi/bS6i4ztpAesPaw6vTYJi32Ltz2WDDDEEx/GRxbHcq8Rui2MZ4uiSsONcqUFAHERi03IIJZffXLMaIyOxGGJxuvEkd3/bW6lZRTPaZp+3w+K7w/gWbXilCvjcvh523jrPOq1WvPNywp95xI9Lp99TqFlpw6PDGp7W89y9Vdc3dJHrWznIHvznsd7mPgCu3EhQU/IluTCc+86l6CLdRhELTA5yOkLf9xFb4hFRGhJcdEeO0dkOOmj94VjCCSv9o0RGVXKIQyOoArU1Ag2ypWrEcmnwsIZd+Vtlxx/Vx+rDcimEAiIgo9D5gtLMPQZL2hdBkpZTLQ83ORfp9M3A7kmjIJR/IEf6173ZKoavTkbWmSoVhcWSgEgOH7YVSt8i+TH1JW1ZDMTMQGQ/l7EHOcokv8p6fOUJiHTxLhuL/Xj2wZ1Wp05w9bgAAVGPoIomrj/KsuxRXOQ4nUhZVS0rDvcFwo41kIubM3XuRV9EHIuqFVhAp6xLkMRzCZAIGB5sdVVOEFBm36fqFk89aLZ5zbP+ehX0R2X8A+cD5ZJTwt5m1RYMPiYgVQLgmyB59jOKcaY1G2YfEHpGsAduLX0OVYjcEaxQqWmNrKYoRo+ezHoU4kJmliIfaN1vmeZc05D1hSxDAqp0g+hgEuR5tERXRvchKg4jm1sqC+o0IkHelKycC5rIWZqGgAntI0t7OC5he0Cic4W2SSDUkIPKN7mk46gEmmrwS7K++4aQbCDkYRyRirP7v9WqRNzKf2r/2y5eIPI5rX2f0Qmf4Ya6zhzZE7U4YmmIvUMe3qz15vCW3fx/c1pPjzKPTidp34nXvz3MUMkktNVAjQaAFCNNf43iv8M1zVZPR9IAb/TJslx5QCJbFDWOiPXX5H0iP3bT60zg9SO+OQ+xDwOE1QYC0NnEqTjDcRpVg+fAQHRCgciCoeslSyfpOkZJQS8cnBzC/iU6Ga0bgZO1lgilPwTcapEXTReeIRifC/xN5A7KRlpHm2yFZ68lvsCtGBnVjHHOrA531Ky9InsqRwXCVsMXHxKVBZC2GclUMk4JdojCpd2rpcWWfYyRd8otzMTWU66NADbpptXjG06jGaF/ddofOm13qD+kg0L4VOZht5GbEPDk+Dd3STBqOLErd+M4bgi+Epma3AGaDU3NUbi9HRGRdwjDsf3Ocx6Gw0tLMxSJUXgodEQIcjqisLnDrN8feHHA5IzTn/2mz9OrlRP1wtUzTPtZMm/0Mg9gvwqvu5ZfqD1OZv0sr9coQtv9h4ZN0s4Tzu9HCK27r52KdMp3DBksijiMxetAczY+pIRIfqMhRpArwOPIoAyejOWahJhurPZPgYpuQpXVuRPOoQNzM/OphKEv7DwWWqwGuNvIS8f91zycvQe0N9chV1u/nSvCHeQQhGInheUewNmrurTMCswN3Uenm7E2FfjSzauB2F0x6xQVAmuredz8gLTgjDTcK/K+a64ztJTezIljTthIyfIF45GJXmbgNhrfX0V2fe2LDCKoWUwuYy28RBcoJW5Q25onxZs1qByugDCCLvR5iq6RMGvWrKEewQTGn58ENk0Hos8MjHIoNX2VvvzH3//9h1zPIhk/y3xGjDuyYl9zylGClLK6Dx2WJrgFjSuuYlqU34L0oxWDQ+ncZP5+0gNLPzNgn9bGjcOZ1QVf+N8L670BnEQflkT6/asPHz6oBc1foj+9+V5FRh624MEHNbU8u+iSXjFBTl3tGm7VidJXZXsMv7wMyDMUIo4cUBb5DUkoZmSgA2YFujhJiPLHIw1PnCJz5lNYzN24+03rnuThIBCakb0Y99fjH2Z9lCsyfCeskwcl5Bu+ot3ubPDOaSVJgSwSd3DmBOOKl4LOE9Ko/ewYlSP3MIGqkvL3DbxMuQki7qQTxtehneY1wGqNx4OsciEk0OzrfPSPv/9bdVnx0lGQcRhThd7siSR/R5xzVAaHqRoByTLBBD6Pv5NPFJ+G7jMFqGlw/g9tJ5V8AN0gAs2fHnb6u7UF6B58qMiGDLnjqLYwn0B5LAmU8sn8fWT+PmzuR5860ad29Mm2d2j+Poh+OTB/70e/2J460S+d5l7UM31ulz5Hz5u/26VP7eiTfcv+Uh4b9dEufS79Hn2Kn42eNH/Ho97zf+81T8w60ad90yJ/bsWfo0+d0q+d6FPcEj+580VxenS6I5Iyfeqc7rjFor/2T3eIAdGfrRP37V7rsLF33Gjv19p7p3v7p522PD+bDPD84Wm13eyfCXSc7GVfdfaO/yh9fSW9tFwDVBSnkY8aN+N8crXzRXa65344Pt0h0ZbytHf4o2sUdradL35z77VPd9QlPEzG7svk9OT0bxi2vkPPqP/3FZ7Bz4Xjcfpz3IT7ruVmber2ua8O3CsvkiKDGUIr19zS9ZqW3Y3ufyYFuklvu5Vj/j3IudPOIfUbkd5YDZQE4rDz1A7ZyT1tjg0t1LjDmlKwkbmhBxUSUAekcrBEy5gvqL5ic7OJK71Lb70nmsTyEPcbPaqQ5iKsz40NMR46sqmG6dox+fDs2j9Jbi7Y3jXFCP01Z1Wt53sBv6p4kmZzPnWEIrfbNL9yY1z+PI0C26Sg+HGk8196CatKWf+rnWQ6TXrXpAZe7LcPj/b2yFabXY3EatxLSRsN0Vt7Bzu/bGO8PiR8JS5m7EbnEebnbdXeQo1EhWCm1sFtaqZe0HHDzeTDfqttrNMv5nYwmrbJc2yrMbo2/85fdmV1f2HyKpPff+P6rD+4LXulJbiExkSCpUjd0dRLP1l0ttyFPMh6TtwXUhZKR+74v84yLm1h0eVGXPOK4XSoAYYUeidZ5IPb5qePEXFLjq/oek7qkaKN0j6iLrRzovuRD4yGXyGWNNnwtoTcWg9IbrTfTuZxs+dImlHeSMZZgxjAZmS3hXdkxQBAfu2jY0N+bvFr/LBJftX8WcGo1XWHNwk4AdUk6lr2JLpdu2UyJuPFN9Z4YTgbS30JVAauKZX+Kl4wVGlyUnI2JRmUyIgCj/mT5PvOi2oqNPycDnqwwee1Evul/3Nk67EwCgpNp/4bTmUJCBNLIhTOzZ3y/M2Lr1F+ihg65S4xnrNaKDQRk55y0qJY9ybegCHo62ggQtKWRChAHg9rBkO9YCu2BllPUiIbVUwgVJMhDIWQxKSE5GPNeHONqYWR44c4aJQDJVk98PPgXAu2a0BJiyr8BWsKmhBQjvJS0xrT0bg1llJvI9V0FUZ4CLAGFMuXxhabxPp+yLFS15ql3i+kzVD4p5pe2P3GQP8hMN2xF6cZFM0F5Om2jAjf6T4FFNCsh1AcsSNh2TQKxc43U2uH253UTYFcHCNtpRaMXleTfDZ2/HTyjhp3d3JKSjPp5Kk+5THeHPtKJn06dsREYW7qeXQUxSDgpniYlEDBiEpsjcu4utokHeeAYihSR84wBuV5n/wdCbWGAinktHS8e5yJm4iAXmqKowIzmhhFu7NRf8AkhwoQWB7sKQpNSCwo1fqhyHiJeZGm6GFVwsQ455YDrvLZFCHQSrWic8Ku8fga82ZnJGyjoXrKE87rnCG6RhVdOz/yTQ4GeOoNrkfN0XKNAeubA39w9c3dFyhddoU7FBx7vMsfIPw2ZlMEKDQEbLDxvrO787T0ChipW+O5ph0ru5510So/TU3u/lo0eD8bQjnuSnvKj1JLbKoUk7OsPC2iBC/l4g4AEcBm9431Rkr1Nom9pSMiJdHgyPYmcUc0I1Tug7U6n9yWURYJbykQJm67guwOCiGkRM/JqLQpwmx4KyIYoVuxJBG3Y3Qk999//P3/usOC7ZJvL5vu9rptpxx0Dg/39rvtpL2/f3nYSdK9k+7+cXp0tH/QduTQPXFXtDvvt7X2AS0we7+VQYkkFepwEkUTleMMwEM0vvU+UzmPfvZ8IBmlT1OxfaXRUIWE7lex9HfmZD65WrUuKNnj1JRH0xdGhGS61NS1czcwl8C55KQr8KVR33Ooqm7oCDuuYZkaXwFysCTNb2Z8J4IWJ5Z5sT2yra7E1alzzQi6SnMlUMH150ztq+w9t0IvclZQ2aWgrIgt+sQl+coihx5NQku/sC0KEbFOJoarty+OGHrVV7D1IIrU6JU3J9LO5XRTSVG38nLJ96dOFj8bZ/+NKrxxfW0tDwhrm5skrE9Uh8jaWSM5t+6Z1ijrcZL6uXr58lGF9GIKp1DKJAL9PaXwekUvaRxj3ef0wQ1ZUabXUxYKO4UkGE1wAqSSl981992UHdfQkdALy1M4MhEeCCBG6O0hbnSVLEQjABghkjnNun+bumu9r4T8p+R9cs63pRtR0YwtRq0IX8nGaKow1/JK/Nt0MoTZObJBl8hXtPVqjZ5qcyH3N9bs4cVao3Hww1Zzz0ZJFIJJXfF43Wd3Uwi547YCfGLDMSgfFjZYxyMExMEU6JSyRyaMhy36pIPJ4LGT/2KQDUrrkUm9Mj8/SDUAyPbD5q9OF2txneO9w6P9pVrc/klray1ufxf3z16rIaq6E5Zt/6SpuU8NGQbrdFsoa3P9QCc723bBorkHtax9tDOncJpIPFlKUdy27tzqboEApiazW6Q+ZeuFl2QDvf1sLoNExVOTkaxKDhGfxtsWbnw9L/0ptXFlB8iWgDeTGLk6mczSkdd7FKiGDgTHRHg8UetmYj1KfSnaB0H+iZa5GzTMcZJNRKolWSgqMFd1pk+XmStod46XmyucOHJnQu80WisJ3Q3jzoTu+mm48X44aO8Zgv9a6GMxZUSTDSHcBNCzwpSiCyjkvbqrmI7PRrUvu0/dDUB1/KgcUPcp5+TRncMwlSQuCPY+BQd6+on4NjJCRcoLEYlOXK6uQII5EO6cqUhSD+QjGJmMHJdqYmoy9aqTjTH+MnvqC0a4BpCf1PVlwVkHktek0hmpYAVb49JQkxs9S1lID7NDNzWYPA/55dd1Vq1ffl0Teqc/ZcZeYpOC1WxhQK/+YJQuLIjSvEZZEYQv1zEMFYhyQE0J1oIhtnFC4I3kefA9xMGmtq2biNVUD8AryHERJ3GdomZFUFcZRF0i0DyvwBLIKEg2zPpS4MNsi2A8YlWwIvS7W7as0FgSlT7FTOp2gGAbeXCqDnh/aVPlk29VKo15ukWYYew0jYmdhHFLqLK4jXkr1c7xJq5aUSoQWdfpEpO+mhcAgtxuO2/WzgqBXeWAEDf/gEGktUarWH2gRtqFRJRC9zrX6EQYiAmbZuMKaOTaaaMpFaLDAfqDDIfOomDTk1WsgR99OGMPWP0DDj6+zvgq/ANN4YL44AW5u9AE6zI4FfCKRC/5LfomG6XT2Sgt0R1TqWKYyLL/GCYB4g8eaS+uZuyISgQNlXOMpYOoaWIAk+TKF6kWWvJR0Uz8Y7WAcaoBH3VPIovuvmatXDsvCfYVrTbji2RyVqJwI1MKZeBkBTdJ8i7241udbX+bDD9EGs0DtvPmq2sMVj+N/TOlt1fe0cuF0bu4FPTu3F/njr4HYdT1w46Cw317R2+w3AvcA4f7693WQRjdpNP43o6i5ZQ/EMlETb0XXhxRus+DZXRrCde1sqU9SI81HbniNAhiUYjMVWDInM8EZ7EHi5vNg06jXpSddn2RHHaD0y3yN+257nv+ja4TTeQQKBaAANJtPUUIr+X02ciXfqCVCJYIyrF2HMhPHBcSlVMolYbxifTd1BsEwS1CiXNuCKd6Etq79CABTYaFJohn3S7Pusqr4ZiXh3eKUz680wdo3PE++HSpJWum4sHUDf1SpBSy5QHkXEpcI1iIUkZECmRHCnmiGEdcJ/dY4MizkfcpULhY8aTuV5pL0N6QU4EtsG5o3BwGQ2ZAt9bwsCiOQR8xoqRcQC/r5fmkj5yHQiuTGzCFzAqblspX87ODB+dne+vws4O787M95Wctq3MorPnK22wBM2utqXr4JNPa2j2WOFkm4HC2QCC8Jzbd2UNcBCxsMgFCBnFSy6Cv4J4hqzsfzZlmpumQixV732TTBKywfhSquIlhlqhMORu7diGzVhm8yJjk1g8o6Y6c3L6N+C4OSQealGSAQy/FZCWpHWO4BGglVXUTI/CfPfvWUEuYririvfksIEDTQ+SAm+g8Stje8rZTMr53wsJNRtwgHtZ8lginx2XvffW+uoyedT3aQZVAMJCKrtmVws8kk7KEz5G4+QR11jLCXibr3jVYEbumkU+ISZ/6SUfB6epBUAXHrxv/LEOaDz8HUwytM0QcvGfjMZAkboeA7FcrUOKJJ85ck4MLzsy3DinhHDsrHl6KCGEQ/nBxC7n3+xUjp/ziuvGTOI4KmB1o42OuSURAXcqBiZLfA+rHUaen9vNsiIQPYaX08jWkBUm4EWMBDUbo/Gc4AYKDkgvj5Y53K4o274k9tQYwOZbY+8H4lYd72V17GITY93HfoXA5Ary5fAL7cOGR1WoroWWuXaUtj/PxbEwN9VPSq5sKqMe0iexSUSs434DuMBo2Uc8NbMfusP440upcoSgAzO8RammosH6Z92aF0IJZxNU2sMOl99Hh4d2Nve117qPDu99Hvh++h9antGi24Sba76wy79Li6SW0fnfxNfRMLEIgNre7X2jhS3e8jTCmQJxapovivgSChRN1BA5UTih597u34lvkIl96O/q6QSGkEXE/v4ZaifCkY/iIsnt19vrl1+rSfXX25r+9ePPyaxsoXn6VzkODIkrdbdLPb1Y24suXvOU0Fj/CeohdH91G86wLftUku7oSZQO+MFkfYTgtW05N/Eu+5MyX3advb/Lo1PpqKZKesKgoXXcumy74iaqYAQW+E10Ih8mQhI6rbqqOwx6xLJkq1wXgFqQOmA5vyoH7rg8q/hNdHgrWlkinrOlj5bhBhgCDd68brEuOvKQ52ghffMb9u/v0h9z7XRHCr/qbOw+qGTjh/MYRrCzKz6lclIKfVPEC04QYdaMbSwAemIkhFQZ2An+ZymYjWCYaFsfR+Do3bKiSFJgwIzefM6gY0KSoZVEsJFrC26w5TIAn9C8Kc4awSPKeQimBjkD2LnlX7nVBIBEPh22tWUM8DMs27Lxx57GfMiSdBEZJdIZPXjN4rWw344S0K6o5O5GQGRPQMc1QRoPVRKpfNNY6O16HIkm0RDboXTdHWvPOYqnClpmMOnh2IumTSz+YxdbjTAfweQnohUvytH14uM/ZKSPCtAM5gYEpIpetwehf9mWy/Ve+NpExI9PWuYejwTvGxQWGRECuICMv+l5WZknrK4jDxeBwYv3YTAIvT/2nsaT26kCqpk5W95k+KPXAkGNLwo6+qHWWqHQsl0+liAVHJpMr1zGh/bGDzRb7bc4FMISIQK2VpgEIWI+EyClqQiciUINzInrVfKT2zJwXtErEpz2vqAAJT4RiL/fnUkpv0mzSj3ANJMdMAnxC4WxfAF4LyaR9Cm/yNau5bIwNGpBcVzL7GA0q1Bng/HWKuiymsVGV0qAwkFui4A8k29+yRsGpgeZJxyO8+6g+F60zSSVpGGebIPgkVsF7JZBMeplN0hupp/P8mupdVe0G/8KJjf4NzImuBcl9T+eCbDgYUhRDteImqEMXCn7T6hP4sGYLmhhaL9AM8z6BOkDfkQhLSoO0z4LPeobD4hEPx8e0a/C7hElhUliOEvChBt9PfTynQXinmYOdoyJ4Tm4L2i9fZxHdW1AOdFNnzcmHLPMceMp1CXiUBhshssqxeUrgwBgDhoVbtwt+83HtkQhS8sWFfiS56iIZZxe/FhezyeBRvfbI7ZRjURfu8n2f8u/uNxrhRY9G+Kj25IvPP1NOVVvx9OPaH1yztScEXPH5Z7VPHz99xBdf1R6RNO6EcXrHB1GO8HHXDWj31+LRF/4dyQKkV/HlbxvO7goRReniKeoDG8xz/pXtJyttuUnno2XTFngNmxpXmaTWWidJ7eD04KSUpHayOknt4PDooOPz1Fqb5anNJ5X9htEPGOK1Mk3tIKSpfa+PRZlq9v3KHLUj99UZexPYE5WPBaZbnF3B5C4wvt4CHEQlgChVJq0dt09C0tpxlOVYlU+qddndZ+pHkZm41FR3AtdxevPpYy8dDKjoWNIlU1SvR4ZjSdZniwvx7gQyKmQqFpc+fUxGDFgsMHek4wUwLa3uUJfwYS3/SVN33DWDNYJEb7bm4JmrQd5NBojDU3QRrvgH1coNr/bcDZVFC/9R19THpNI8InBYwh1GFSF21bvfgyuBQwJsIqE3PYVYULqr6iy7svHpapL1IcuwXoIFXJ1cdLI8LG2/tfOLE7KzgUYe0Dyo6Vjffmkqs1Ex9P6nj2PCQnACkMfkHKQfalxqWKw07O+ZGMNeeYFCKPanj2EXscrUortERsudnTTFg+VThHNA2qSdK4+hZN/WiusmtZNwREiQ5KsJMaAoACeWtCguWZGleTV9r24SZ57GmZ7+TIInqmh7s5t/nJWU8EbPkJzgTnMJCtdHWLfwvN8GFLgSNN2phJgEE0h49VtHW2q8dBQmaLmjdODTGNBdP5zUpkLUx/PS0hi15NPH9wSCSBEKg4yzeNBiIVwJOFWSmG9onR3xNN1iO4pvHS8lh87hiSOH52HPShOIyQERgAozzlJRFQ3VOdSHnGG8asR12Wou8fIMNQOfRCaVQaVQLh0Qgip29wVJhGqk5he8WQPNAtQRIlZsF3G8PZty4Yp3q9fnaI3jclZeljLwdXV8JYzF5eOjzty4XinsFyRJxv00KWkB7P/MbZEclfI3gRdx+KSPZTM3B4c4crQoldgNKysnZ6TuGdYP4nc5P8tr73qp8c3ACuGqdW6viJM8OY7oEHeRGUO8wHTQSg9AhKabkU5X4K26FOFq/1nAP1iNtbHw2ZR5TzB2SRqbBwxBXt+Kqe6399prkJQdRjy5NwSYOCxBeU3zMZUoHRG7/fRxAe2UCcONNPC053qDFLXv0gFVi/6eUFHsI9BCGE7oktRp6EWmogFchGnynliox9rKpkEqMaWHlckFGYTTCbgwC7z3nIWsdYKnKAETClKhRg7yCt2B8VUBbBCakB/XI7BXsnB5TjaMIAkoLd7UTVu1lXuHy7mDE47dVr4I42DpLqyoFB6JN/i54VagtUuZvDz96SNsZwEexZfMpepcI8axHZli9GkQD0SSU49ORCi2iqPrQzEV2WQn/iNb4t4N5Hp2lc5tZXlDCnr7tlakUlZCg8TyCaFesnhXxyVNWVX8Uz9YKMVZPSZYQHZBSkTPn7OCwlJkeUVuWLFfy4WfgxM6el/zckrwxZy4PMdqRnWdop8AvAjefENu27qC17hm9biEaemkP330PlZfSHtUlUZza6+QRASsQMDuCFkR0e6MRJ4weh4hCLCgj9o7TmCSKswKRuy2VUdr1BNmv04z8HoCEKNYfQiRsLaGyCQlFqqCLykV9SjQ2ScZk7jMPkkQgFMykmnvmjkxX+a6yIIYOnCqsdhPhUZ8QBQpcCRI+6DARlQmnhVF8rWq3ODOiNhNqIyu64daZhP355+9Ruv2m/j/qoXhIAVXcOWwY7HC5Qbx7ZyixYSO7DjVgYmnxIkVQhC0P6rVdr33TwqnjlAejtZe3nR6Yt/4G0ySFbJaP31UGgj1XHoJFEUiWBFKtXKbqIhIt+Wk1TG7L+g4cMi70n9B+rXEKCw5tq2D5Wz28HDPHVsdoxk9r5g9sIDApCSxb7x7PKo8QFTkM8M//8yq5wItgx0eLUszM2opXOO1f3rNwclCb0zwFDeUTgxQlqPMnR/IpierskNIfVOPCE4LiWAg1xQvI9K6zBrW/ukMV1/sOJh6B4t0z2/wdNHyc4QYSdkcCOxZoRoMmn2paNCRlZdZQRCc9puHdcMt97EuFIyENl6MyERe3UTnee276XCgKIQ5/Dx+NgyHRtcDwXrVZqO86/Q1grMmZ8KlFT6oqsz71PTn9O5JTrgAmNN3b9++Pqd11syF/u0oGTq5Sez9wvC0crDrigSQ8/PvTXiF5MvRnecV3SJN/S1LhqJPH71JqGkBw7i+vdMlB/kYfvTebW8goMrp+1yiS6mSE4O7afQH4BU9nTEv9z73iBTFeORuzGwIxCWfOj8FxBGXHUknGSXWl7BTM42X5EGlodIkGAri8WF8CSgzULvfJ/3EO3XA2QQKgFNywzNQLDBbDZcqZt2CMnMyDkBg7cL9QXEE7B2YpASuS6yKu+2zg2ZRp7jYstGsZLfX8FKKSTc3G1oROAjLEyzoR4r8dFUTJMuABTFJwiZcHlsMmvuSo1Z+U5G+g7Ikj4qwqmAV0+tQqBDOflxnEEwksVOr23HkLlBPQvhg4sNObfE3nPNBOOc0dcZClhAUfKBSk19Ou3n/Fn9M8O/rFSvhHuDHXjlWQDcbj2DROugLu9I8/7v/dMsooMPd1oISBnxTGHCevc5R64CLGpABZTbcCqjHddjo7O19aB0cmnCgVjCbEO6Ur5l14EN43IT7d51qe/lUzdRK0z7ccqptmarNKGgvmup+eaqyxbueonZBZU9DMS8VB+aQjJ9zihUDd5D/WOzTmuKvYNkkt1TwAs2X7rERPOM3jHgoCkQaKRDEsP+ibgluqcH3yi9g4u4Jd8G5y/vpa0XbdOOVr0oAbvqkuND9Y04O9UY+8a5P47iAx/30CXrVnINhKqzF7RJzbOvJZWyQksMeISXKEhTVh52JshxsD6KfmxE8nI6b522HLfY5Kq1FcvOlU+tTlOpTcBLt3Mc4FlMxagvWGEexcMu47kgALtXDhIQeEoeRo4gXTGGzOttgKJ639AAGhWJuNlJE5/RCEFDsnomblOFz3fkYDnacrPi3v1WSgU7xqz/+6yyffoEjVAfaIn+hI5Gf3Wj5r99++/wz4O6xwYYqWYYqcRzlQDegwGhMdI1oHLuVA6EG72mUWLIth/nDj2/XGqqtBuD3QtK5T/1ulDdjfD3e+cW4dx8Jt7gI3OJikl6RUW9yQdR2kV9eyNzJu+t/89+19uotuHONQ7f81OM/yB9P/saV5fTzXx55jN0Lp+SFUTz6hTy7r/HUxavE/Qu8+YI8l4++qO3u1lJ3c4dmsBX80s+vL7Cuj+rclzp65dkvgquXozAMfyKJrkFlohueLWzPpaidSh6FuBb6sfa4EinpQ9NJWn0UhWvmk6vdN/TshaOSi+eER0NCbJYWO083f4cukieVrMnJjdNZNNp//P3ffc3DS5Z1h1y/jZgRj5/Fdvek8ggJj7wtxWSyZeIxCfaKmPRkOTs5rS0k4Xl+UrFtPEA5jqjsmJEe5S4mOa884UquAnkQE84KrgpkXq8zhxX1HGw2OqcVYykzlo2GW7+iGPo7DpruFrTzO4x+4XhLTDEasKCN/U5DXEkPK4d6P0Rh2JDPDiG7vhSuisqjX1bVC/29TsQDXN1vzVp5CZSMexK0G41QLCtySfq40XVv9Y12gtVUrhAQl6P6DkohWbSc2igy9bNbyezkiqCoL872ubk3go5Krhk8rwGa1uLI9iRTF0PlecXFiBsVJHiDM9W7znOFmpoSSMSE8hqG6W7XPA88fD9wx8FhrRSdHiAEjptvpNC+kUkJxovRYb8vG8pE8753rbWzidZ6cg9aa4dVuT2bTNlZoMrRh/vTWvc3mGp77x6muo+ptlsWMHe/eqrt1vEmWmv76U9ASaGBX1Jo0gLA2GdUB+KMTweTlJxBNmxCWwKggs/xQuUIOU/GNoQI0hHh7DoNyqBSzMa5+Odh0IKRVN7ORGqnrC0uIxVec+1MqLIXvzA1yDX0yy1ehG1wTDWlsh6DgoDRw+7s/SeZr6TkDcp8UGBM5IAmD4kymQ1YYShJn1RtxR1D8uMig1UaDcMF0xQrN2GRZu+zPgJ8TymqSp/ilznRUkxsZjUpo9UIkU5fBaiI+mvwLqyMJmFF3zwNtlPC2QZ3TQAfdKmeLwYEGHF67nU2ZGs1uJq7BzgvJt5dJIoCi6gkVm57vg42OV/tUNVzy9N10Ehb+4f7x0etvcOTg3bHHLKDEC7XsofssFSQU5wi650MNawqpQbDoo3iEKMk+7gl5FHd5H4j5lvJqlrZtuYqludwDRtdFXQ4bU5nyy05RKJ869Dy9sPqBHj3UNiLFauelFdXF43PKeXix7/sqJ36Tit4dIcV3N9yBY8YamD/wKzg0QIIgf1SAWoyZD7PB7PhCOxanVKUfmgom5w1PX7KkObAP2xjJ0LhWY2f2noxj9dczNI6Hmy5jvbKPQ7BMO2ojHMnXr+vOT/tGXs1/CqICzdaREllEzrs+jcqQs8aot/rwx4N018oiEJNRqL3c9P9Okd/er5PiGPJZHSHSsxYl5M70PS2xvsTLlvRtmnLJwuqVLRLHJriwJzm0k9ztch/7YV8/Ia6gbD1Bsg0CkQr2GeVx3sigToSrdRPxwLl6NUMuWNdDxNFRkcPelDKgA+5+hfZsTlCJlCInQkNa7jE10lx3c2dfmEbh3sgw93QpbqMo2xI2POwak/9UwBjlp/qJn7NZspdmzXJNLPU4j6sr5yE5bW+NR3A3C/fy2gqRmKe+jPPZAQ25Hq/d30G9Npa4YtbRubbVBW3PTcOjlslfEr5JcR4HbdKIJT3p+QwRsAdjnmnfZf57500Dg7L+JzyS5j/YRmE857nL0g9281/W+FHem4cVs+fBFEfLPTQ81/HQTt/23a2vW1tp3bKwUV7sN82XH5/bsrLXbQImSqpuKG8IytUCyVIeDLy0W5+eWldtJwYUIQoYW/cKiS8IfNVgzSsMNLg3iiaNd8mhYmW4TAS9iIOOSYnoyBEH64Ep4Mkd0WN8iyUhzLfJ06qyTlRcd+M6xrUYPFLr+jqy8TOxQlLInngbqJQjgJtRR1KsEQhkdxsJBRPKexOmjvKv/CaSfBMVUM+IjyFdh484lytk0aPigJdXw5M1c7rdpxEX8ZNV5sGwKWCkEZR5EUknCWMPyVSWUCRMRVzpPDaUMpusg+4VE04ju1FJFm5YHzIb7njeV1hhVvKr7YVy6RnCGed/eO5w9upFtHco7GIts7h/IZ4jYA7VITfPUuT96jemhGgakRWP8KERAnxKF6TXwpuDAcBRw6bcToBadHZRqoFFf/tazA9dp/JV0xOLJA358nw2eyqiItez9eN0orDGIfa5KdKGOkHKsWBmLZCwBphjReIPSLREi3VI6uAb4jmwcVFY+YTapZ6BBIsCHQK7kH0Da2W5ZtEXGH6wS1bsaBJMzP6yDuvXliGzujmH7CY6wwKb30zQbizlIxKnBQpEdtiocf2BDdFj0/1eo0rnptug6K2+rarzm3U+Guu6mPT+t10fTVhBt9VnDmqh3WBg3id5++KEgH9cdQtxl9EBVbHT1+qMRW+gmIqdR7Z5FMKxoSpc2wGVKRsK71EuUZ3xhT/Li1MdZWUMjvB6acAEKOaFoS3QPP1qRBTYIZbtowZfZ29z9DMt+nI3UlFQMEbJlxTXm2pPhKfA5pS3ZAe8OwvJXEUm8HgMN48WijAEBLSaki21YrOMOxyDZYxFSDpzQbJhOCbyd7MPBxvuiuM6r6wVgU0E3e08zGULko61NSx6J6vmzaFl2C+L8Mzzdq5KI8cNK51KTQk1gxKipgjJYhQLv7KhDfH0qiLeljPn/MctWAmPQEC9QW50ZHHFy7IKutuHa0NR2Wo3IGmkZnqinSnMcNlQkh6YS9hDh+PUS20hqtp/PQsBNkmFKo5Si8zpCRyBDbKnlExNqwrZ/jaBBEVR2Q2duUUU6U6LtvPuYYkByZ4xzpMHSZtU7zE5Vptto0AOv8F0RIFPnPJezM3ibtDzdX3VKSLwr3BcnompmMuHMzUgyRsOg3cDSXSXl56BNVQjGrJuoSJMchQZDQIQcF2eonkJuEF7+Uw8HuCBQCvo2N5YykxR5QjWXpFafNiiIFvf3oZ1ZDVWONTc8v9E8X/CIoU2RPZk2FPuE+eFpNhs0YIUu4kuzc4yr8fHELqtOw+xTDcI45HU5axlmL3mZ3BpgsgW+mXCZveVxxbn0dLr//j7/9OuKLhdQqnYbmvHpnOsiFSlacpqjJx4wErvCJZlCF7XMOUUiWZ1O72mKqllO90QfOi8qMU/jzOBmk/1O2hXPrCmv4oEMtzVgC9AzoLgvwk7QfAZQ2XZnaec5l4TsCT1rnWSDedTkvx9JwHRKYlt9iV60MiL3bEPWBK82Dn8L23WUG8QoKPexTIZ04xmjlu5j4y33e3OOXEAyrI0sbIxNQqsDPOfmQptdZlav20tgLG8eC484Cwwudu+OmocX6dTxsMTbLf2DtoJNNGa7+5d9JsH63Cd6Tx3QHfcfUA2JK6Z4X1t4vOARIsyxtctbnNBbbYveN1IIqxJ4IOeQ9jmQd3KB9DbrVuraw4sTcCYJq/C/gMlzkpAaiXtpK0HhKBf+nOtvaarZXQoQd3g+ZfPQAmraO9EmnZFQZCWMVeLKCfo7Ugrg8MXv+6HZaSlUNKvo1WEIHSXXBc9SPc2zEXohE1wGE5H3ICfHhlacynHPVqpAFItQvxNBZniaz5MpASFWvQ3BrIDg9Ec+1mZ381zR09HM3RANj2cHJkaO55LF7MAXcsMEqcVNQoq6K1I09rqzqqxUR27mR9KBD1arpZY7OXJ363jx5uszvN9hqbffJwmx0GULnJlSsarUzY6eOKKiClTT5ZuMmVHcUbLRAyHHMorIMtwRSjA39b7fnrt0a+NBAlEQeClMdxRb6lfOJ/moulck2T2dn9DOyc6zxTgW4ZWZ2sAeXxQGR13BRH0zKycuN7MLKiATAP2TusIi+jV2gEm26i28IFrGTvcC1WQuteprLl/ZVRGyb57Oqa46K9/soK02pmcrJcWiF++FC7ftLUQhjLdv0BpZUwAKn+B2c+rXeVAhKtSQg/OlqFeo4l9lX/lnZRQl67VN3U2xvVh0JZ6oq+UCD1AyXy6lZJDInvFsAGSAV5L0tiQ8/NdT4wLOS0xmjOK2hneW2Wo4O9h6Kddru531lNO3cq2rJ6AA03w5KHdvlORUuzafVILLfKt0u7icmoVlPo+ZJJxiMwIP4jG5WC4rRCj5DC25wdIXzvRU9yGuTYV+VFBQ0GevBuhGyqlrlQeM0DHPnsSi2o55O//RhtYK4t9wfTEsfpstGDonWKUF+aywvYx4PQnsTzWINZLgeYI8jFByL4Tqu5vwazPH4wgjcDAKF/f8ftihbNCGWruan3GtbuOgZ7TvwpMWDsEhyfaXA8ccVKA6faa9MAHwaELItVZO28DOMl56oEUWSf0wTkALFCpo9CE2SomaJuqqMzbGCNq8SSNY/+w+BvZxUo6MkkODgkCkDlTKCYyyzcsqZkj6SLiFugG4e1YCA5TtOBOw1EixTjYIFnZ1h5IFNzjFw66mWSRiQJOyrRFh4vwtHnpTu1ahFeeSiXq0OH7c6DHcp2s3Ww+lA+nDqEATTcDEu30Db0GC3Y5ndTUJW26bzyJC4/YD5/a1G7EQK/Qp5TBHgf2FQoQaYUdlbYbIkhewsRHFlxbHA2QuaI74cPC5l4GL+Ljt25/iivoAa5FJN1Z3WYU1SlHVFBHtsafbyi8sIcjSBdc6SnLoB4qIgjkFhHYFcKsuS9rPSDD2ct7Fh88M/KW++Q0ouWAc219x/sgB0191beejS+BztgNICGm+HqA3Yv9Bgt6sblxUOWW9UhvJcBbnFQ+TbalduIw6ZKPcePLDuv8B0RbuhVMumrGTYa+FpnNj6q+Irf9SeHq9/JbVhx1EpsZOUZWg4Je7D/YGp257ipbp5lZ6j1cGeIBtBwM1x9hu6TVKK13fwotZYdpfsc56oT9ULho1FnmhGxCPRWJFpW3N84vayYQUjValu27DU/oBXPqtNLCHFbCjIp2Ycer90QBj5JcpqPa4P00sve1DhD9v9s4K6NaVIfQAhdz6e6casTCW0zRtBuSsfNF9b27j2uEIwYODqjxsg5zAHJOZsU9AVVYitCVWUz+TVuu+We4YO9BxMn99fR8Wh8D3VSMYCGm2HppG5KgtFibX70ght4044rzxLB0Birx84ZwCc5/oki8Po7uAR2zhMCF9xxd4MEMlMqEILKehzM7Su2ZYohSYOwybNezwQliyPI+iEn/t5Cz0LxMhgN6Eh+TT7Q74ho4HiZNch2uWni4OjwznUpD1fT5p3sD9JLw401EKAZ/+aUFEwF2PnSDpc2uGR8tXCSFIpQphqnA6+xK8stpIedB2MmB+01rOs0vodiJhhAw82wxExoJxiJZG5JFbjEnQP+kzdMvl50LqPV3JxGDmIaqeAO65ALmIzyG40Al/+UjUXKPXwUqqZze0YwAVvxPELl3DkQD2FJSylwhXXk8MEEz4NOc3+ls5jG92AUSANouBmWKLB2jztQi1Zyc+oLZpMvuxP35z0OjRtcZuNcSJlyZRW9SU6Q14I4Tj1x8oEvXDDx5WHqeImx4QtOLAUkxXskHODihENgFMTQQqz/BK6Ed5dIpnVG09XiwL0eYDLFF3EVgiE9OrrF8B8mt7X3FF9IhUWzfjpxksQtRwhL2G6UU+Gkz2TUrH0TQJ9Yhi4tR2hWO2ecNoJquJ4VjF5+nQ0bIqMW6eASMkE+VsGZ1QLq+xoe/eKaMYUzDmoOWR5h1USo6ObTaT6MkKnq4nJRymRHCONHlJCwqS9SZN12j6lSDyF9eBRu3gtEVjOmVlKwr0ZBknrJoMe1m4E4QiGrWZFKRLwbTG8abYNZupsoE72YJj5+FzEUkr/uqwv4B/ltVEsoPFR+6KQY5vn0eiDrnkikXhT4qljKfkmhUxgFwreqxQdJp191YAQIwcBJq+shoBcTEVAGM9AnqQ7DTFFB/dj0LR2bEPYclrkcJKmigOwMbAyJoD0spFONOKuJ4LQph69A3YcBGA8tPkWM4xyT4zfyfhW2/NJc11xM9Na028/Bht6NUJs4ZevKbSjkELyL0jwUsxsbhTyk0qqyOrnPAqF/J8U716NmT4iT8Cbn2hSO5LK0x4kstuaJyN7zEPDi9WHwm7BbVS6jEau/6EXvfRoblSHJQk0VFGzBFPgE8satNgO1lptSj04ezGN+cNBsrfSY0/ge7DYOA8At/DufnWiNDXhMe1XN+lYwqv7OQ17tnozTXBc4J5EgRFiFMyLmwp383nUa525loyiEHrOwBa8838GFIMWVwXomqUHWx+LN5YTR3KrHIOnRXN8xyk+TzKLCFEVMNJWNknHc/ZdzzII7PkO8Ek0gpAf2rWAEzZpSZwqUo801JZRBs7S+kAdUkuGSlPOvMxpbf40TvtzQe7coOtaQV4Z40yDurIe3JKbWntm7k9KiqNsKt3+FuNwKVtm7D2W+zJppxUN3z0v8Gp2NEhacrD9IUZSLg7CAUyeFPqrIqWtqVlNentZoNSyCByLBXPKa9467y1xJGw7FSUqSngo8MkjKjVtJqssDPo+Ojx/sMjpsHqz2SbQeLuDTDMAnKNxh96M1MwnuFQGgJYJuRykLdxjCAtNnWbOr5M7IYp2iVKK3caZDVHl1r+BX+x4wD5BErUmmXcpzt7mk02btDL5trnSJq4JfIc1DBnPqDSd6Y6mp9lwxFPS8/rXhRMr0Q5yxjYFJqr9/myYetYWntDjOdZpQGRyGSWW0hgl5AWl7YN+BprGiMWmEBc9ixcOiuwgway16Ws1GYi1asGWMAfJB0JKWp8fK/v04C6htmqVIE6bwHIV2tPzGl45nhTBEmaPSokktRbZogNhNzH3PihxpBnGKbt1zrms2aZsKtlQfJ4Qse2ABqh1j5jS+HgNrwMcDzdP3a65wX+q6tFjddHpDCm45V1YSbGXtnuUV6bSag0supYmeTFtvk3FY/AyuM3cuJr3rWxFxOAsI+pk/SW4pFnXjQbkJkYKYiVvsG4IS1vRZaMohW0lS5FctoAnCLGaXl1mP0rZ9GoHkK/s6AiFnmcjJD80wgjGvOna8kV823NONzZcdnM+7/qDCc/L/IsqLspVxAnRwxfR2IA/4MlLlhPEfcktzYkOO87i5fp7brVFN6pZskMge2Q08gX6zILWdhnX2/JsaF1toLqJvxqx4LoFxfkntkM6hqhomXq0yvA5C9AJ94U1Ktqd8IqyHOBeznkiYIoGYIqXc0e6XcAQyqoEVi+AqdxNnGbv1TvW0fW/b/NP5jz+4PSSjkjYczFJDugjfc951NECygyiihqP02QhVWkVXYdgJ3D/AUdIbKysXynO3wyRvyGTFmWcMIgHBg8Mb3RBDyZYRI0iQy7/wGOr9rOgRu6iyI2lwabJcc3vJ5Qj7bMVwBw2VAHEFs7pELIYTuY3QydA0olT2fGHukEXf1MDTVJugQytvm/eK8osh8ZaL7aTSLVIWB+l7QpYYUoVLxj4qjxpf6tnDNcAgOlTAGlXyzB1avgSjZohjzUGxMORLuYpqsfQwPONdBXJx5Q7wuaPNx7aTIYmE5D7K6bmJcz1OxSXhOPjZSAE5OSBXk5RpWaU4H5FrMiGZfcWJp541x13vc/fvdGJU6yomuUazCyekIPXl2axoU6N2w8iUSYY6ipXsqdQOQrNAOjRKxsmZdfEtq+l8ObC3YJh36V7rUp1RJ2eut5ovATwElQdiNaMqJXwxqoG0VPQ8mK53vhakW2FltFQQ6HdUrKSaVBCyVi0ZBlL4HAhO43oZwSKpmdUXSKZDKvhXMDG5Oa3qZTSmPEJwiUs5FqyW1KbJFQCj85wUGMT3ZKiGLXJ3QUUhZizgL+zlz8mE4mbl1vSMsvLgMZrRQbPFeEb8Sf5uPz1HTQS31MnUQgpnlwiA91lNAQYdZ/ZnTfXQGmOlCFmuKUuaA9w+sqCVxVsZ64gutrEAKwEj5SbtFo72arepu1miwCqCZQFagODuEJSG09jfSTThTSLOBq5Hb0RfqfgA3DAnktyEwrd8DOcWQdG35peBBSgVRgMNRi9LjvmUy1ZKeaDJkKFnZ1NHIcvNBYeHJ8cly9YoHwXFl2oQbGssaO/S+BrTvCHjbdBkG6O8wZNt+Jn+Ol5iMeAhbm0xWHsUqMVweMyDYbPYmgSrjijXeXXxhsMSUEa59KFug9rANu93zujFJQiBm0UEEjRjbTTUQmE6YcUvLhAjKIjCAuCBCiLYTXJbD3hE0Gtciz0myPGs6y4NbVoPHJ22elTzkP1AdJdmUA2mQtE8fPh1pMKoHDDUkwWKn0EY0nv/7RyopNOMFaMPClvQnrksblQw3KSqlSDCmjVT5/GGTccwb7OdP7a9wP7BiIDESkWXUHbp/v32xrV0+012OXUy19z359mH0vfP84kTL5wAPUrtt1AOs79OzHeoFms+k6miLCC9hSsuAjpVBB5ZFbKtmyoWGmzd9KvnmLtY8MXgQMscJGjaMt60YjZGnCwRjJQZ3m/um0tiv9mJPrWjT/Y62ffXyYIyuHzBPtMLNqpCDAtd0OdR6MdLL5ehrQ4bybRIMpQSkhxEzPsyHT719/iXu+4T9zXVHEqou4SU5jul8znJByFoNeBHBCg80WOj5mtoH+5hXASUTeznpHWg4WCJukggm5cNGIzJaMICCADn00f+mlhS/dNHtnthuR4H9wxqO6kISU8WT+qIsOd/O1FjckUJykHsgnIJ82CTPGuikROqWaqWBT/CaOhhR+aGq1hZQTYb6T6mYDrMA75RNB+ZGuq1sg3+00d4fzMnL/UJ6Ax8jfvh+0JMWGyRK9ISWK/wKST5CJje5SRV/DBNJNwa6fVgt9WKvUByXfxauCviqjGge8QRxRrFUzr7+52D/bsUT5kfDGeGyuFvzImypcTPY5P42d7ft1U8flQ0fF55r3f2rvNC5HDaG941LdcqRFKwk5WipUwThkhgPGOmiBK6RdVZIwehowXqVBQwDwHFLd7HHh7cxx5KBegBHbA7beJB46h1/KG1FyGsrL2bLeP5oDbsdn4TL53u2+jTx0Wcsor7McKvP/xyoAmjcpAFDL7LbEIK+TWdurHTR4ljIzdcYBkHCvZ4DY2vqhkyIL1Vyimlywk1ZJOaCGfgiqH9DNZzqvlOKpog3hLFYZ0E99GwSlX7Ag8GwKDPaboPMutsR2aBrEoUtwVQtB1Ng8jjw8FBu5LMwgYzXbzg/fGExrTlAy0P2pbQXquWh5JYfFsOyUAjsLZadXsqF+Ui8lPLtrsfWHBJSjDwTMela0Z8Y+66bX76SGLkp4/q3M1RrjvM7fn5uVQRw13yzrIqOKOcfDaeyl2DCDp4qLSKR3oDcelxASfnk+bCQ/bpo48zFBL2Ege1eA/UpWj990Vdh1uUzbCjYeo62j+spC7Y4d8Eyw2bYBYQ19H+4TpcjLUeicLkWDhedr9PCJrhGBmAkg5JTAEyryzEfZzy4zvsQ8kzTduwRfWO+cGUVn9u4enInMs6/FlWK+R8dEzOx9FBx+7FWajbSYWNL0lrNOwaxb6sGMhuCDpTwqRxnuRs+X3Clyw6KEsPjGSIG4OeN82KvuzOFgx+dTciDskO1xZA0L1BXnfd0VE/v2mySqKW0oCF0HfLqhX5YPrxXxh4QlFEfI2JWndC0yTG5hldrrzM8SKmOwTtuk0k+Gkfs+aucsIUhvnzkjQUXLbfKzLvD2IrclIRg+cG32N3NiLUlUtVso2uT/fZbAh+fEO+AbIqyDSkooV4WJB36y5AAalNiswjNUYIsAzX/UF8Rm5r+Hp8lQccEASn1rmcEg2E4bdpF4MR3a6uGa6OEXHJTAYcVYPcYtgaJOhmIlVyhZy02V4+vlWaomHPKHxUrgLEhWej9/ngfRra9lA7sXCaIkItKFdKH+ww0XDzeapBBK7w+Xrt00fAlwIHvz7nMOF2gJb/DSWwNhmxLhukduppCIwO3dBUUGCsyCZMQVNd92F5Kyw1yN2s60zkkU7eWwQFctGpP3p+etJuCNXWwgRzgzbviD/LbQ1m+DZXp0dtNiK8Y+A3E6EOpt61DN0zRIqnaZ9i7W/SoFgjTRYHTdzlCYsHBvtEDL6B4ucnxFZMvhWExv/x93+TbSa2kg6TUcnA200pjgL8rogJmdch2JF7CFTIue6DTE1WPFpGuFWaHrAwCeQsoNQoY0ao0JBW+Lqbmww7uxBSmUkVUc4c8IEmGRIOhmPvrfWpCuBwkH59GJtfNbIe6BmSx8n+pmof1SU1C0pc3otcsgTelJ5zt2lCDCvwdVH1rimt/+F0vaP7vZ63KC41P5jS9TzPHcta3nFUfakVKXmCbK8VsC3lkzEW+UC0Z7R7fOSUcHztO9uz2tbshdJ1t9iYkc6UhnCnzoaAD9dCGKYVCZhxBLRIevOCm3sb5iNp7T72/PB+93yLqlrzg4n23C6VzLt6r9vtE7vXb82qE7OB/6Brk/9RCOmGhY1+6viIxFxnbGt7yJN2cr+rfjdt92TTVe8YO8r+4b4tkVTGIxOj9o9B173Kk4HckyFQX5yBYte8letFi40hFOunl/WaHCy9fUzIhhcZxwBvGCGMdJbBwkGViYGhoq0HS6fEVgksGS4ho4PCAK1mUteQz9YL7gGKU5tOMhTADr6CbHQ5mNFtZMXCsrEokgtxAbhH3d1KpqVsJFYcxGv31F+asAGRoJl8NhGF/I14WUVUf6OVKbwoRrEHqMhAizWeTSV9733OSUZasENjPyQrDi+oAK93NNk0ncxHtRhg8Ep98AjQOWgH3HBokR5PmHvJQJ7IAFhA1pWULW7Wvs1JtKdbLugDsZW6ASs19Q9tIDVlI3o5TggQ53LyQY8aY47FMnLrKWGGuC3hYYiP3a+n17Q0i7HS4Cr+Ml0nkQSkRQ7ghX8Ak2QpJAygbn2W0C0gimjYxq3b+wkXeOF8Sg66oLpGKfOlUVnu4MtwXmiTE1u3WW+aw0ZRNBOnPyBgJPHVuD0Elw+stUJRUrxjyvadNxWBYHQrEyVRys2RFwMHw1TzcY/hhOKcuf9CvEVZeQZ0EaEMkSPuy6aWWyPCIkOUxEsx/p+CCzI+PRuYtBDb3fjy/h348pwnnDjzyZ048z4c+e39TqUsZNbltc1bifz17uXYa+EZ8TtKhQxFlhbwXgo6cr/yIWf0N8Qi0icagKogMBr5nWFkubfSSwh0VRUcr1q4qzp5ZonBsaeRg4WJMTVUyPL2AtfISy6fxhFCTHBSGzjkfQ+cbt4X6jJVvnl25L1vUDyRENozb5UwF4V1ry0oqybGDYHsSoog8MmZYDWZvqhsQdUFKRjJRwSZm5maPcp+umbtRzTN6E22UpZeGNSw4yVeF3HrfPr5Z40q9VquMM25jks36ZnNR6FJDbck1d/JyEk/2Dqqmw+yMLweEpHk4zn0WpHa1LOxqF0j+mZAFmuNZJiNSCmXgNrZaETptQUJd3P90lzJXhC8bbCw6O7ynCZXySgrODjSQweYGOHYZwoZhesxLjZk89RcN3VLQRLQeg9W7Ptwpx7t3Y87tVXtTqV4hmpC/7rkizuJauQexGU2Vx7HUDjRnEEYCOmKxpkPRcSqDwWCEABrSxh6KHhhIHh7aV/sd6fUohkCDjcitAcslHKd8sIen5qXKyep0hdhVpRQDblQ5CmOvoodnmaTSYCKoLankh9AoApejRRYaTfud2k65us6lBLMR58+8kqVrHc48+JE0u8hJHgDmLJPJ1e4M9mfTRCJ4BdRI+iVHdyHTrR3rzrR0f6dbt69heTNC/oSZXZpkZcR9mFnb0PC/hZCdEzXKN6riBm88f4xvTmUjMdya4CL+uRhH/ruqctgqzrynk7ErexDRnhoPZ8EknAPfff/IHpfofmhNeW7uO4qqOJumnK1O5ioAhvyvIrR2XTLg4DZuK7cUc64r+J3vOy8g5N0Gddbh+FB1zCeq08fH2x3W/d85o/vdKUtPvO8C5Xbe9Ky2bSt2BYSgR+Y+L6w7doPbgLUygQ+udvHWZBZcQJJYg5Pmfwv77G3vrbgZqP2slCQFqEnviivKcjLwazs4g8eBBXdKSqOUiSvrqlSR9ar434CLTnmknknXTHlVPO3dJtAxENkH1OZqVWvHhRf9RHZOn7GcEvVuultPtLSC0MA6zD7MwGPuiKgxme3SOFirx8Gh/dEaCxnKpLO7BrkrCKR0sMKBxu9CdQKLlN/l6tZCwhQ0PvD6MQ9gdaDNSQfzIYBh5FchNBexEnvZ1SXn4EDNZKUpKzwccVscOEUGJ9w4tgxB85L+gCEXSKTTx+nNykce9y96u/Rwf700QM1deU6ueVof19Ojja/cvKfPj7Gj1AdjGb2pFYqH2WQA8xykmPM22C+yWejPtuh/IaccvA/ZVwT4MBXO+Pr8c4vn3+W9PsXvIWPH/X7g8ZVOm3wHBuOrV1mHx7VvQfsce0P6aD25G+ffyb4Tclkktw+fgSPd8M9+IiVePyJwI/GoydffP7Zb/Svyq4uQqLmBfd6gbkv6/SRbMEjbfkvuzStXzj0u/P0hc9c42UDjgte4XVVIxqZ/SRJxt3cs8E0o9tfHhFmcCZUpXWQuwjlmtL2xuQubILzf6cqVthsQRpJuRe+cRDurmTdME7hcBIarMty4oio93x/hRbgBJV2wfJCXD8eBckSO5YTy/wFkUnZdG4k1lrLIf5zFHQ9HQ52sOx/dFT/xWD6RT97L/fNP/7+H66dxoei0WpTi41i2DjEH4OrxrH7Fa9cTb/QV3fdu/odOgqbynFWHF5cmFk57pv15idr+IeshkB2yPxKj+MmKpp845ynPSerR5cNQwI5yf7KbTarJ0VC8vtfvaXXZyMZNYFCv91VcX7u6GL0ayrFidUYrNn+ZJ1Gh9ELcBq/KxiRbUJhbSSIchIs6U3kGoZU6/dIsGTdodd6yAPEKYSYQ/qJikSxeJs6qcbDbkXT0bRcbYXinED0nz7+KXmfcI6m+Pbfc5D3baBzP1X42vBs4QMgdZkEms4P3iwbrLU+jl13ZT6J060jp74lIYcQgQ4AHhvmfQHdCxwSNiR6AgsHQ+gyo9TPimaRuIXvI/utlPM+3y2jhJt+TfBnZV9FQE4Y5Ln3jAOWgxaQdSWqVs+gBPpA2FWKbnTfXIhkxvGNfL6bov1IZIdPMOA8HKnFfqtLTdVfum6zPf75CN4Sn/wwG+Xd6WRWWIcQrnjiprMJmGQYZdNuEVMUSwKpgbtMKJc7IBpIgkhhyYTuYUozhvyIXJxibn9G1pQ3t0UUduFOf3xCKXrUwzx4c1upo6AHei6vNdM9HINjMzPEH+/O40L4TAVFQVhvTapzu5LaM9I/Apokrcx3+TBduhwVScC6EFq23i+It7wSSaGzM84SZpry80PvGWfTSgyeEaapgWs3rDErOGHCFcAItPsHzXbzgwauyBAvHaca1Nz25BPd7XN4noAPGmZ3nQuwAHu7JhIXOKUwAt4nN9M+DLPUlRRgcmcOoKvEwWQArSNGr7FsNtId5EEDi0Nc+JKkrE8fCRmHsEuRU1xIRF439ceL5z1gfe9HEkVmE4FW47Feux2QMJe5KX36iKiI2dhdPn1RGIpcopBjVkAp4oSMcMuBFH23sexdy0cNOVvkDuNVkAysTpRz1YlyrjpRzlXH51yV862AQctbDVYIBzbbj0nhe/zsxduzJ+peKsYkwRKGx1c7l+QgvIHud1rbpxIvvo6JsgINs/vH3/87mgWHpfgpd1bRWau5X3scjClYT4j8Bq+PEkumyZPml7vU+9Pt1e69413xRzd6jrc3EOWPITUytWc1xF5NqvC8/k0JtUbnbh/sHx5a79c2+vcGo2J32FGV7TneuiUGutg7dtSy3rEV24s+Zn4ftdigT+gUmE3BN4WMHrzI/u4GRhB2ckV3lOj4cDuupts1NrzavUmbv5WRdf1BLXd/lnb8uSKBLN3w2B26YgfOEEkMWxjv8FRwRyQXXhF7/d3jnZVsN1crh9/75v8IOy8u2ztt/FZxXmuPife9VR0CWN73F+KBXrrtraMNtt0v/4rnXhoADjrjdU8fcoUptoGSBxAuClGFxUqbTA2B9SNM79P/fGppKLrIdmSyVQjo6sHIPXCwBn044Vc58Ate1UU3gfVBIr/8n74cZItX/cvu053nbBl0nXnqY0+wzEvgYMR+PkGinaJlEvbIl11sXnfVDnv8ELLBRJIdYYxG0AU3SDbhflmPgmIUQDplMP/4+7/Drokm+dT94+//odghU1Pxsx4q1XqJfhCkcJkqD6JIbiBaEuIQ62AUTStdI0njJgyWBqrmTV4tyT9xo2enhcSTB5hbt4vqmZgVIUduHmSVAloYqsU0riZWfdxz4xhB/c4nCFRBZKvsTDtsiGa71VnaKttpk2HxqepUZ6XNkbqjQ1n0b/D2gmPVOdyA8b5xeiuQqxnvKCa7oFsGqltJMsySp5NkVAwEIQI26yQQBisohSm9J6A3G3PfNdnGWRRlk43eu93va9SUo21HwDx3PWWzMf0cM4yYZDdgH74TBDTiMCLZhesoUN8IYPWD4mwqDfNSmJJauSZw4EqERhfNsDdIE7Huon0gPMniaz2Awuyu+wp7GZV6eBvhtPTzkXtk6hFVnGY9K68mgjm5uFvo13zJCC6MpUR5QGhYijzclmhgDdp9llJeXcoLOUzptGXFkPx4Wg7IrF/dWzDVQcUW7IQNq8nAQLiDlzZrLy8j44qPcREZwzt6au29PX4HtJ9NIrJSfJtuapaqr3WDJLaMEAPrpRFLRhWBzIC5Os1ng8X5F2HaCpJB27BgpiXyU7A/DF8+GMdp449X0y98BVsOBQ3jIp0eksBLE4/eWf+k/uihhq4VUXXnaxbccPtK5O1O7QyRqPSxm0xw+253SL31siDCGeGIEkH2SWoU3LlkIJWuK0ZCVa/Fh8bBsVMeUj0CiyNpCAQF5iqRPqiSIcUjRDj1Bm7bBR9AogZEqQu5C/SdDcxr1nTX0TLA2+B4ep8VWQRXik30dYj/U3QknnGDJtqY8kQbkvO33W19dMfbesmAcE+fVGVtNGoVNKELW31Bn5xsLPY+Syn63wP9MvoM2bsMu9j+snpZbkqgVcB5kB3c5f413FVSSAjNiyNSqeaKb4QFUO8TgM80IQUeRWkAc1Q7+9PZ/ymXrECWc3V6855reVyUb6FeKGRPV0ZgZOFFDovGTaOekpt8MuH0ki6uO3f1sLtgxokr3hcFZ9jAfVrzRNznefAL2JBtbrS2OgdHW0ElLB+IWIVsuM6SpxfZgfYiufT+16u93XrdVcqvGEijfdz60Nlbb73afr3axza0aW9vYz7xJnWSSU/iGGyugA/xppJFI4MgIKkHItyJu7t8c92BtZAINXGHntI8jZ0GgH/jMUmp2ZxJR3krMQvBUCjmZiSB+iSJ8UUtZZlIupXCTORYdfLpVMLxGIxhkVw7ndxymr+bSSntDCM26TNm8HlQhjaQzTCCa2qCc+kAS4hkHq3WxoG/tGq0eIKWRysIb6NChLrVvUnVPQuxeso6BqMRYNy/zgrInsTX3LIFX6Njml+//HOhVSXob5RqLt5l7AVKh+PpLT+DJG7uxiRsheI4ZlSwL8gih6x0QUIt9Cb57u2r79k3lhQcXjglY8V3+Q1NAxIYsXpEmtAy0o4TljCcdHXCtLR7J+XGUKE9CFDxpsXUJuimBpOw45G8kVLumhkmqMoCuonizwJRRCC8I8SC3WhpvnDS/lPEKzonDUc8DTkZ28lUWyVTLRkFLpJWZdZxA2ZlFG5+xQ9X3yPu7Q3sG+ccditR2XSoTu99lanVuy3zVlG0y4bB63xQBbiDVUZg7fJlPjjeYJk5z3MKcNBwBKNbZatToNUUfZlfluAUwnWcTvCn4r+XbCYbG3zhaXTasgEMws15hgQxE1VJyhiiPRF840dBNwjhBuFrXXCoanC+57WR44dXSUh91WeiKgoyEalINV8qZa5LsdZNr1NrJiYBWQiHGLsN30psGUMCnTeppyPcRMwH+Y4qh6eznxXDYCg9x9UH+c1/iu9EKKFhKOFOR/Horv6TJQOSQ1ntY3slJP3akPSKA3q0Xuj7oiojr9yV7GSdV+6Wukonm4VbSLBqOWClquH5YjcjcUnAPMVe3iFe0TR/CjJVmcebP9W04S5WBgUmXqPv+ehcQLIbhVKSvj2m7Ct54Yqi0mBWISve1SQZzdw1QWsDNFnpJDQU6br8K2QCL3RZUbBenl4iA5VgXwt+zPOr+2o9RGt1cVvWJZwviYMZfn/dFJX3IhJiMwnPqjGUnd7qwO3d8cCtNzY+eyfV/kuckOerTsiCY3hysME9qUQckbi9CEjFQVkrtmTckvAstIOsWKZLd4N7ExABk/6ncN572Pu7BrOU9rjd3itp3Ya/Rns555lut/fupnov4rK2Estu9OkVRfaTZuEUlE0klVLF1VBFDzGpYC9mGBkrXXOVoRaN5NSm8zJw9YjRCiWwUWtsmRKE7knvjBJojWwSuwCpaqAY/PrslL4J8acE+EFiUyrGbQpC5Zhzj0viPYVBp0SxT7JU4jDxYj9/9f2p6tAy0vm4WGW5fAhJWLIjJcGvlJUPsFnCcUQ9BAkfUeWTxcAcYfcinir2dNkJGsa00NFKjjr2++56BIhrW+9x07NeMtdUhsYvb+rHkbjsbIlfKjiaYqJc5hEqccqaeH6JbDTUCZCbTuAuKTcbMaVd8lFSoTnGf9KCWvKYtoZwWUmF9tXNuT7SnP+Xjo/7Xy0U9RFy5eovMPO6VbzJuWDelCH+uHaccf3GpWTWP5RnREvamalIt6hLugS6aSVhbrzBcza5aFHKK1KklNtWG1AeInD0YIIKBZacHPPyx/MahW5D3NhkFQLoaMio8R27Vuv2SBvwEsqd7F1r3vOnjybbkCLOywLm2Rj13oUT+ROxwEJZtRq9ctE8iFeQsyqxFAi8qRIO3n1kaKIB13rjwmQV9wB1sJE+mobmkAbo+Z5jJNWDDBkbHHVO2X0zwTiNX/dJLeEV5giedXE5WQksp+qq4RZZDK2icioz+CTgiLL5N3xE8Qc5ArhraImykeHNYrA2eUJuTbvZyCdQzVd1m0czDaMKMe+ozCZyxWkAg2UTNDA9qfWwLsHLT6JMWLlxqqWavH6OXAPiYNtQpFNBxtdZT8uRhbXy6BlkLO2ljUF26Yv+fvvTyw1pylNFf76LkF1lAFpg1hwnPcN2t7x6FnElBUdGLMIus0eT25RNvFEDfJrDU0wiFU1hmYdirX4lA0NheXRL4/4bZHi2LJt/lugWX/OPn7NN1d6iFKDjdkSeu2Iwn9u9zcad1H4N2XXIfVHJZw7CANXneN2C7QaD2cxERlCywiggqEmvaZDflH9woh8L5pARPaMtjy1AF8vyyKkS3VsqVE99vgwl6xnE6lFByKFSOUYT47c5gHOLqTy/5iv9ybpT3VJHpsqMmBJJlh5NFSFns12t6losgOh3ntcB5lc8Wqs6Cf1UtGMJSi9FE+haO5+CC74Nkqyoo9xr3DPn/WhGUMtbi/i71tMAV9kow1WSoYoSjb/MntqAConD+HI3e0pgCdN8dKpp1o4efnWzUIyyG7VtloIUGDElQUxuhRoUDCxio4I2A+Q+zilR5FrcoXTA3Yhga+ZwEWWRUdZoFqLt5oOA3gqE5Hg2cRyDpWlcQcow6PmqoBKev3qw6EZ7jRstioRqavazf5yRATnDiRxUk2mPAzo9lLUHnOiK/Iskb12LYnZ1hYnPrcAMEr5dCDrCTmsiUxrxSQpdYrdcPx27ySMsr0ultKF1EatcDFve05ppJjELgS/TpoLNXmZXXLcjmQqigqnZVCalt3OkxAiPvlD5Ggu7pdHkcGmMkXsNkWMNHhVKCC6zpJRQWFp7e/vb2dA2H1ZsVJHV/dkSaXn1njlKeIYGApitNZ91jtsxPs9ZX3EYyBAL3E6KBby6BkYNiJZz9Nxp8XH+OiJmmqchad4f5Ah8NggSUCzpLA9SqVzwRoMVnqcSs8RGEPabjMKoiOj8uATRE/HvqJabJhLG6x0r1/QmF4uXWkJSOp5ao3EWwnEMXGjkbPcQuGqPUEgJndUUeGJcynvNM6L901JG0yEbJU2il0+4sIWWODPhvG6pGHEybM84z0ZTD7SCFoK3HNUBKFdLRp4Vll8wklrvjthmhqgZQrgh69fwg2zIpLc5aNvFCm04pviUnTES8gtBq/vOr/WP/EooU9O2pVGOD4/K2NwjKg0coyduQwEJQ2+RHola2huSgMih61GAbIzEWJx2B3nv3c4D00VVHFk0gFpVYi5Rxx0L520+xi0p5XDPEsrBfplQ7ptnJBWS54OSzQMTSGcb1rFd/ubGo9qSJA4OTd3F/ePjqksZgDYpg3ybopfjfDyDtYUVab4EqQDwYsQUCHJyUyUUOQKEWcV/Pf2yXMKIRX3RBoeahZRSLqpjQ5Aoy5c8m19DF83az1qsnaOGi5D/wJZaLRPluOTEdeIET1rjup+qZtlJqp8YK0lzGnCEMyxaXDSGTapORb11zV07/YrNVgynXULazUYiJFMT3HZVcUHNruvmH0R4QPZLETJg2YThZFWgrxQCC+ckeJQXomNTD2pSxWZKs/y76lWkPglQuaT7aKUrLiPDC99Pk0GIMxUgOJRx8yBCj/dP9vb23MuOPfRBHDfjC7G90FCfSPfases17VMmFiao+ZIGCVVGXVcckEJX3Ol976TAQDoK0aNh/WSleImCqTFOizEVcO7MUeT3hkKicKyW2YKGbsEWjGUrgM2tB1fCgCifbgSWvTa09T2/Wy39H9lYPi7DrAYfc5KzJTZnC7Xpoa0NthQiY4ELc2pwPM9JpA8KslpSyGwHvx0JSriC+rkg6ytVRkFVL1ExIJNCS5GmEECFwdkIwMKRs4eRESCsaQmjkRCwOMirgnF6MzNQ/lSzvgH6IAJlJymhyr4XI9kYy9dTx4QsyUPSs9mzhuHVxcrYgAqi3i4i8k4jXIeyXxqyfGkaMOikBwZ89qizgLxNuJ3YwXAlwuPrWBvRAe6VBgICg/fXU/HPWpKwL5l9oxEH7zFVyK1kXlR3i9QOAfHGOefMH+HzUMxBSSrn1HY1HH+ZPZXUZLHUkh0I+WQvTdV3uk5ha9FiKmwlc51rDKMJILiUKlBaU7HIaAjJKM1nBZFvUYvo9y2PgquuWIMOjFc3lBHgb0++B7q3oZJYNq3rPLgFr7ejqbAjirWs92JUwU1uE79UvEjk1yZ0Lg/emVNMORQvlmyH93MADXU0wjo2hH4sbW9x+A7uquVuOLr44J0z6VJ9jdpZIJE3cjTMqVuAAB4rvmXAVclYdRs7rc8hG4S9X7jDnoy1sLObYN7LjCuA3ae+2rMka/zO2748GSre7s69qa0bj+8etv5gwdZzXaYRe6WsL0kuXbYlcsS16ixgRMrxd72fgBOMEkYQNr4BoZCANOIh7zTxncJMR97drLw7+JK+1+R0fyEgOpCDggwYq4zky+5ToCiS48X87LsV7dlxtj/QDJmfQYydC8ItQS9E3njNAKdhfwBi83xfBRL5Rzbgy0MbEueEZ66fTlDbILweyjSxaH2mGNdTK/sDwbrgfPXZsHY5SD9kpjaIOuq9OZJFLJ82RPlUXGfUzWiYFU4hgAanu0L4dkn/PamFIpxJiU/KUYL9VWuYSgnQJhde8rJe6GD+IjdI/RpGp3QSFVnVPQ0O2Ygm67ojtHZk6ZgqIjBzoKSP9Xsuy2xiNwpbSoUjqoJ0WiqrUcXwVgysWXt2q6Af9VIjmnZO60JeM2aZ3nANnddXRlBTD1X2uErtPqQ8EliUkONOCmRffWnBxTCPoNnkUjEez0nASPS58Co0566fSKirgMM+9sVN2V6v0eMWKSp2s2ZPsTbj6zEO3aUkb3BpQ3ULOPVihD2cNBiXuW9oAlV9xJuqbQo//RvtADjxb74H2y71JqXPNAahiD3CP6fs1RP8vOt5aPjoPBQW5wLX5wxBUF4yumRngxbtDcDnvhmRJsnqwUUDm5EZWkyMwaqoGxHAXZUnm1JSrWabYovCQ6QJiQYnxhJfbxZiMS1HIDh9i2P8cGtrgIamGdzLNe2VDr8I60pk8cV8f/bkNUYUX8Ve7Tn3+1h1/bYphNubDdtRhre3t/G9NsgIn1rOsKPtc0K+AMvSIwC6ptCw+NSqVY6ro7idlYPKcMJB2ee5+qnagDGv/eiROf0d9nkTEezgd9rpSrFr7b3es3tdKkL6OphaJaSDmKU5uBz7mWR9tic6eS6UTfJVwEx+m7cNU8KNumrHUiyTKzumCk4OW6GaCtkJDMMQF3WQ3Ds1uniCYbsQkHg4QESxdDlOlr/zAQlNr8KHUh3EFcmmczVBpLLYbqbKZz0rlel4T62ENBP5IpqIrDRetX+GZOXBra7Fq7yfDhCoAqMEkLc1/MQtKOVTYwVDgGpUY+Qm5QrqmZk5yn84AiIEcoYwhj5+O+pdu0YIudyU/sNvNMqk5368HVY73cE536RXyYRN2/Ii/Vj3WNWIgdfMduQ4sZNADHhOW66LYPo+bUzzhvu7gdrk6uCp5b3ebOL9/mHtRcD1puAqAwvJM90U+aF5753cFaLVh60iVAa9FSx8AgnJ/DaJtlTYZMT+KBlgsIo7wVCGoxXks1FQP8puD+0DNCxlcfkuLRypF27oUzJqawE0qk4/yVI5GJxxZixFY19EOEQAVNe4psFROQFZWBlW6uPtSQ+hXWeUqrfXKgzTbwQHhZeVrSZss0UAL0U9OP5OL4OjwzUSr2A5gkFiffhRkQt5We/nQkaOWCCWBh/U6ApcYniPWfXRvbHqNUcVM2vkGT0LPOeceU4Vwz7eby3VjUnb6RuPWAh8ZobEspST3qjsRL/izHvXmECZzDvu3IL9f2pUBOKcwxsjvs4tM7GCwCQkzpeqjhx+UvkEKlo8ZtbEEIXanyQ3cdQMIRDNNKG6rg08f/0TFycaqUTC6Si4NYaA6ksluj/TFBwASOiNJEf0cjDLNIMJxx9Fq8MRhXbsBnV1BU8VjpxPHNCT7xc1Av8Ko24uz+99rgjIGsvmLVEUwemNDhTN2Wm2PYLgJJVCocHBOqTEwymRvARE8mmVSMp+2SybFPZ+9zjxkvszvcmpwqybuMfRV3bBd44JvZPaedQv9Jj7OfVg/bIgHNt2Mx4O1j/px/d20peMJD7dL82DHFhH+xZCfFqdPXuk98qRG073TijXI5PgMZOBFqFkFVK58DTIEaSsznxBER2Q7KAEo418g2mwEKHyOIWOkp+MVTlqsnjSrJ2RLko+KEhilyQTsb8KqU8aW0KqdO5V6eeaMm3iwGWQyHQVtRYvuNeo/tmE4KV2tIGzeexSiJTQ6SfimyOW8lgwGzH3utGd67V02ms+Yab0peMT+ejqqU/24HiUUoqgzeMyALy198kkSwQqB8m8vuyKNDtvmTO2tvn8QVTzAODnQgjVBQvU8QtkcS2lXloBx2YoAyQdwwbGQfqPoxCeeu18QGanurt46LyQUx01m00U/BPXi5MDds5Tlr/NbHYgGOjKgjVRCxVIpjFsj/DD2nNSJiXpPpsqtrFAFct+25D1VyEP4eukuO7mTkpt+i1YuGT7fsl+kpV281nVLqYGa5oW0ovIkGql2CaeUaF3rsLT9Cvyjfe1LX66biA5Kk77r3mX4zPcFXqZAlAiQaELSgAi2SrrAWlEk8ydSOx+1xacXhTWp/b4NYfSuwMuUWFATiBkKYr5dXrX3Nu0Y7yv6SVdlMh1RYLsIPWr4yFpxTX2ZOFOHPideJZeCTGUZ+tkyavcRKnS2mEI8E2aVSy4Ps1Y8a2D49Ns162H6Q2U6+RgJQTdVDMGkYns89E4w2EqH9KHueicrr95NMnBdohPa45ls8tu78i49Y5PWvcAH7hynEtD+6KVOrxjXe91x7LRmh0QKIwPP4gQYsJhOpxna9FRmc/5MQcmIm/47KHZR0ReoIHCs4qQDhNyTS6tkV6wh7mYHCM9BUSU+Zb5fo4P0Zv0kkHoqTtPHbv/TIO+yPpftY/bKDjANQG/2rnoujv63c7TfuruvwG8C2CNMBpcOak+pXXDMCHpZyMoLlLlOxx8I78H6QlryaKTCO9enpKigPTk2euXIsaXIB1gtElHk6x3TQNj/Dz7msSszZxOPWE1rWS+p/DDjK0i1gDAISOFWBZuvZVnkv7rLC3U5wPNg3QYqavTjF0dcitwTKgWhqSF1/pof5CoShN8ol7CEA6YFWw1mLuG1+xEGHChQNToge0Qwv+1qzv2gNkwMuwGfYjfRVQhR4ypLw2sZ8Anwl/n+Tsu7DCZsWE0NhOWFW+rcWvK5zx6Qd3XXdOlLg+atVB5KoR5RjUpJ+mid0OIw+DW25oiDT5MnWfIKjxXJ5YgU+PYVRIpQkJLNnqfDyJIdBqPt1Q1a4oAnyD7Xdw82Co8SClofXj0JlczSaLJvWnQ++BI0kRkntaPrVOOY3Z5q8ovmpUVRuuwdJH9wGmwVFA1Yy+Ut69iLt73z15jHvww5VAQOOQYBlykePdvTxm4EEYsADMOCr07AhToFG5qoYuhW/GuE4a5dCdbnZVXCD2roZedflImkt2zSvWZevA9lVE9XFbZJXSCTROJevJCUDhRta6bX16puqOFtTkuUUA4HElLFgrhy1EgNMyA2rV39cK++Hh6PRt2R45Duz0BglCd44qfzNuaSsyMeRnHJzdrkKgBTjLSCgQcHMpWaCWFct0gmgFHcHrW7l3INB7XPO501MAdjp2QwBIjf6vTlINeAPIC8RTgA3bVGERCJEZp07+fKQIL1iSMBXofI9aGXDi6y2/GF6iUTEVhr2njLtASX+MmRc+MQqIxBqIrY8B9M0aObZeNhNd/aGrbIGICFiI3wO6tGSOvL/lp5TLyn+G3lXWPomFq3/jFBxNDpl/oEn2Yd113rD2LPTye3+N//P3fAxERWr/7QkhJPoGg6G/k/UWsgfqqB6pQJzXbxWzL7vUnKy3uagyZWQ7prwVdasfWZtmAUw5qV1R7YKLlLznNHvQeshTc6tgFZ8Wcw1WJdLXeqyGGYta9wD4wQdjegf9okDaiGp/9/uCCDcQXpMfEJWTRChgK2P09peKMs4YsQUOkxS0CGg+3g0RfPQyWzQVLjLY0pmPhf13aTsSygBqkoaDnHBxEeXuHZaMe6meXAjIICK74////TJKpUgq8YDnb9r2dj/VcMni7TtzteZNM+rUGxZNFW+SWZkyAzG77sTSvvv7h+zc/3CbzYvMge8cpJTRQCkeTS+G5JLEniJOjsHclLJJvnHRLWTBjx/fTBVA7fOMQ+AzZpfi69SgPvVufxB+eRQq/XgfnPjKrIoK+HPRhBCuqELoA+qfwWasiHU8LRSQruUO0cjP9xMACc03GPsmmiZOgbGA4N9kFOvcm12NATBSvIKoukEzUI4hrr2LRkhCz9jeKh3Woi8e7ToxO6EJAtWG21/QJVCHGWBACxdFjmfF7J7YYMfZ0Nl65rV4FqPAhFT47q7QKvFwU6kQz86i1jCOmHE+3h/uhnCq+FXDp3E/avqPChqfC2zvGV29ZV2z94ZTS9OkIPfdPV7oKWx1K+fNpObZG66KCzAYTEO44d40xzYvo5CvJznsHUwO7wcg4i95hao7ySUtefS5VkhoHe6ZIyEBDZC3c1Cx5y/INWqc4VaJfMmRDy+eUMFaMAsoMxGa3jzWBb1V/AgFqhZZFrHeC82yiSIamo2qs3PkDUWcxXokb00WBJloaWTiG8cj7qfdvxgm2C4HMClM9vlQ8HoG1Rh8TaSrsawXrWizsTCuSUgJb/CZU5eQvTGihegXFDfr9fQbmLc4KiqxvoMaGG10D4pYiYKwbzXV4f3F7dx/wullNkU1RBXC/P3MQHh3LLU6sxPLHUbcYf/Gfv11rlIOpYM3bFZG63yE/0JYZy/DR8cFGDF6Ci4WVspD7E2BKeoDH00jNOaV8ZPSUadq7HkH/kZA9tjbZyysqAAKvHkPRkY1JgoacKIBIKEk7D6OC1OIuA1JUhBtSZEReELY5vGsYVTq6JkMpfHYMAMv9a46wkz2E+8Huqjbczz97RWbAYOqNQ8vUcENmGhL3XdvTfOwVJ4rX6Tqya/4qvidVzMIi+p9kMRESdltw8sbPqff1DhDwVzds11sCgM4kaZ8UUO7ayW9ZFPI6cbP2I3BUNWEkuZJsc1F44cgTaxKEwRIoWEwJWkvSWCMwZB+cq54A1hpxKwYRuRTgW/SScRpFav6f5+dukX/VBEJSYN+p9QllEy3xeOIztuoqshY8S54OH5UXw27qs3ajJJemNRn77M0g/cLKI44Kvl/F6kS2OY6zZHoLlCUpDpggy+PVnVRgiMKtrSXmyJfDqt8wjVpgu9xP7yi6KUtGtvbuAihgCr2GH+LM2JqsL4KBmvXkcbAQRKRs5P4CArCF9mWvASStOAKfS+yUEdrc7sfZFCwhzmHVuTNx++r5C0aUhdWaxUUYSihuPFrHkcEGZL5nwk/FkmJyddxgGH2NLZh4ype8BSe8RIBDWaUU1/v8cFcNRoZAg2LKkUJMgKBaPDDCpKBzbrow2Hstwd6jv/f833vNE4/Kx5/sk/hsP+HvnS+K06PTHQndok8Hpzut5nGzTX/vn+4QlDf92To53XG34GFj77jRPqztnZx2WqdOPnA/dU53ZpMB3m2dVl+p/9zPb0Z0ir5q7x2eHHb+KB1+5btquVYo4atBd6ejsaudL7LTPffD8ekOGYtJy5PByiW888VvxWl773QHtcx9BXMWr3e+SE5PTv+GKeirrfbpjp4rghSVGRaOy9Gfi5tyr7qJOTEc0Y2yTofu8RdJkZG0D2tIXWvc9kVVDe5QYhYhbhuBSE1qw60p++qowjl1c3hCo+CNPcYGAfvUfXB02UM2Uz6yeV+GMdbZ58LnxFFdMhwrwoKX5Al70Rd1PWeO+/lnzwhZ5TUdYRo86roCE5oTvYB2QArCp4+hHmwqHhTYbW19DEfKFLI61kBhSVEnOBMawF8c92cDZN/JacFWud8+POp0dhhzSSS4HpkhJka0Odj5BTCwBUcmlwbzl11p+xeZJyzmdJz/dM6qkrtn+OQWn38mf3DNZObsfwr4nPq48nwyzYWF0FplHqx0KtnsVIPKs5ZIneUbiAmqWL0S+2usBM3RzEzajlYhnwLQBd18x8Ont77P83es1b1oDJNsULMP+vUMOrcA+vPtZObPbPEmj7ajGbUmIBacxUFnxfG+kfv5tiZHJeFMeoFrYSAXYPUxWAcFI4WhrV64o6ULd3S4Jws3imfM8ylTEFCTv5eaTZSuzItmqzgxAXWXHaBQ1q9IKXsRMXDuuU8fDbqsZs/RbXrr3YBl8FsvHsRDICkWcpJyNxHcVi4XIUqueeJsj3adzhXcHenctBhcZ3b3BWqYfP5Z9NHbiRM1PoSCN57ePn0c5u8VLJ9ICxEpwEv89FGnKO3tSnecs7pyvq3l5HFA88WIuOjKrhRiKU/6Fe2LBQbBvpOYRaJoIZqRKeKONtmwiz3kWJNyA12V0+pCNG7BkcJW+yeQoo8KEK+q50evWcjYBeCN580lhhQcZurfIlWFGue6Z6BLBbItd6fAbSF2lBvFxKZJV1789JErexe6H7V/epWNZsgjv85h7+2jkifc3em74tNHoXyeDtgNBw1Mc3dAkJL8YZyJCux5DDXsRWg8JWcrpq+y+BjQQPGOIGi61YXgK2UpeIMUDsLQp5Z+IgXIk9s3kmwOIwMdkro7fZB3JxqqhNtAr/kmX+5HKouVtZhQhgU3q3ctI4ZfjZJOCk9ZdxSLKuquUGA2J03KY+BILxT/184hABVb+bU8Ao+9Do4WNyTDczwpYegkXVmwp/zqyglSmZTa65pMcsFe4jTwqdMbuzMCPZJGsPVzGgwWTETXNvCjvxFN3ORH/CT1pj99vGSEB3cjz7pSZM2jSVN11EZykzBIuoQSOMbj3so4EsPpURZfGvP3VuV/4VjcTx+JO8tlhSLXoStWIEIZr6U8aa9zSF7BVTx4GxPbIdmrWJ5142hQnlaDz9q8wcybyRo4F95WpuPb1Fa2uO+Gm8+H/ahi5YuRVF6tWsgkLGW0JCFDNRSwrK3bkmXlkWNONqmQre3XAzPUhAC0Op0GnIIg16vN3VGLwiZeexTd1feTW+vD5RLw0V7r/mghLM9m9HC4RenE5f033Lw+HLRtQa9zXmVh2tjOiARoJUIAbEhIry140e44DKFy8pHW4IHsCMZaOMVLcr/2mX/LRTsbMaBGVGNFO4FzJTX1++ock8/tdt0tTCwO7I0u9z5ET/X9cBRRMXVj8uEtwpskOGg15ayhMdwD5TAZ8O8eO7BBuOmb0dAWFeHWHQk4TOekZajptd0HqvcQra2sf4xeaDhMJ4Sk19ZtqUxvk/T52eu3z787Y2r5sw+EFnL7Ns+vgEOjj71vz7s82V854ozzglsyIdVzV/sqmjlarix1ju/CbZyY6Hp2Yg+f9jDOJZQSE8nRFk6aNbpmkli4IdH0PQ20Ox7ir7bw1XjT2ez6jTG7vo2soaY0JEWxhDxXrwUY0yqrI2RbtVbUGhuCjcQ4stecl6o0v1OM894COUoRQ/FnsU8m5Fzpccwjl9YVQazcD8wAs2E6oaDY1HXkltgUdBNRFFAgrM4vEDor240U87hFDlGWZPKfs79yepdp6qWR4NXwGtVnM8dFUaJmXluP27L5WKwZNOcNsYdeKi1JpLpFSHWEQlnO2oUqweATqtNSdTaGewpKh5oCTHUMzRqrePt02ZnvHO8dk7S05MwfHHe2PvP7u1pTwnNpQdx0NG8HQsfcfWrIeFbxAh32Frxg8ZDABJYus9QE0ZWNlihIn3seH6W2SWsRqxCqwr8d9a1NLqoNe4rxFtH1iUZfqbN9hV2Zmp7IdQE1PdBp+UuvFNoninl6IDEk7KWOGZu6ksLckJjC7kQ/UZ8QMQ72bIXv0nrWvWGkWqY4IDf9CkFJ11PIa2EPFbTE1HQG25CxQoWbK9ZRI1FDw/98U3jOQ5DPSSoMpkJVLx2j7gq++hUlG0+potxQQ7E4jAqQ5cDb8Zfo65d+jK0wkkk6HiQ9G8JZ/Uq7ucdBQ2wswJ/W5XlawZAX2jnUaKtXZsAbM5YkdqrkYtI3YeiT3nX2nhGElpK462U2LBxpjbOekWhdtw0y3xA4iFOKpsmHfJQPbxlmM7sMX/TymbtHs6Kxt7vz9KF7kOCRwKMqzVTPxYafGlMUYQEwjs5EbIZs+8kmLC9APCGKdmu5V3v813SSPwGfxDQ2X8SeH0OjmDptvZG4/6ez66ZKxqm112pVQ2suCRGUCiE0VWsUYKC9kOcAQFKESHLICX6BbW+LhUBqA/OQUUJWe0ed61NK5durpgw5TWKJ5bCQX4izFBkLgp2kjBeCxMFwrZFBdZpNHVt5TM7YJ07RmdpfEN+76SpQgt/NBDbJBtecXHsJ5l9dueWKbMLoEt4raPAauahBv7bRTNxqNbR8LnYGFxB9iH7BIB158l/uHL9ztOt6bjCiZWM2Gaw1+3vsbsGKmeX603kACqe8PCdsF9ephNbA4+rYO3k0NlqxX+nQTrJx0TBtkkt/2KA26QyTGrHWcqzb1uq5Irv0gsspEYldUGz3BfSZC412p7yr2WSklPPyazUFMRoImIp3uUC/ywp/JW12PuDVboi215AB0HRwTay9Puu0E69N0JwOTKgKfbIhLQdeq8JcX5ZlYXz7XMvaE++Eg+J81vURGqqHqfAyKUnm1dhEP+e5b9aGsKlEHHUcJGMTPsjuoKywAjxDeIxSdmmGOsQhonrE6fNFNi2FSEn0x4H10sSzRwBQ+NHOoE2L/L+XnSmSvMNhInbJpMJuwK5WpyW3liEFBZXPyRIF2TKguUT4LX69LWjglmJ/exd30V5ruaB/eLS3d1wRBcwKCMcBczqgEbD5pW0UAz+qRmdv78PBvtEE5IdgR7KVUOIiXN7ITPRR2K3A4jliIRlKErUHtzEd9XPcpYi6icLHDAnEkEvn6TT4MxhlDd7cKAEBHIYEIPJkiInkeaIO9ogOBcFpSpV4CniTowMkhdtrUX2vqtwsuGFjmAcPKhsT+5yDBjZYuPq8HgvXujqVfUHCuMpS5oNcmrWzYU4IQ7i5LNiOx3w3Q9YpEcvBifU1GO9G3a291dR9sg11bwHzYkcF6m7ttcrk3dqrJu/WXoTeciblZPPplOut25WHb23CKe8EtO73jGg75QLm16mBySL/SOr9I4w2DE4W8ojqUoFWMKOmDFXQuyaDK7tXvAtXd5ioVl0uniHLUErg3+nw6deT5FISYR/7pDXH4QTiO58kk2xw+yRCoKDXEA9Yek/y2eYefk2p/k7S6Jee18LBgC6PIM4nT0pM/m6strOSGN3+b06MrS3K19pRgRjb+0dzvLZTTYzu0Tj74WtmAnzzIaBGaOQbNUzb2y++yDjJC2wYsfLANWdISEhxiJ8msuoprh3dj3h/zk+sSdxZcW/8o716y1rbbNkWGdV2VLxlJ+05/tFesGUn7Upocd2CS8fO9eaAKV9QQGgX1C9f16yNAOTji0uOepPb8VT3jc8tolT18N4iM4LzEEamfpO2oFdmCNTWu3IXl+Rr9dXe8Qger97P9jb7uUVKqh0V3wfHJ3NH8HjBfXB8MrefPRUubHamYJtCsFRRhkUjXXnhfvexuCerF7ezzeJuFxjhR8WH5fB4bnFPFhyWw+PKwzJObjEfvW95HbXgu1lqCDecVR5fJ+VF92chHJOFZ0wLj0G+vYwGJDXq/Qh8s36EZA1MAEJCeQ86RvQl0RF+ZFIVLelRnUkDBxgLjN4j4q948Fu6Dayoqo+F4I+zHmygBcc2Xtaqnp6TYCbpVQa4oCii14aScNYwi8TGT0uTUvvYtamRgv3zMixEFap5kY+o/owdUu7VhngQAi3lzxwpplejfOIXnxP4DEAPjeo+DtkaN9L+Nodsu8gRPyrmYO3O3CFbcCO5R+fKjNGeJLd1c1SIrL1eL3sBoC9sqdsUxDaOQK0zwq6Kt6VeA/KN2WtVb2zkpOQaBAKau530uALJ18kpmq6+0GNHC3qwPAjELca2Hjtd9MPVpHAQk0K85QeWHO60/YfCYw+sE1gEtrA7Qcsc5VLuxvtRb0JRr5JpaRGTPggO4nvqqRxc9GouhWPOivN8gRUnVLtylwAnK9IT1m3t+4UB24ZneDWJgSWps9eB1Sub56zce+AoR6vJ6HAbjrJdfKsflejI82rJ0SId+ShG/sk4nUlooVx+EhFfZs1TStgxMCvj+RWHz+i6HXJMYR19qYlgJmY6Sgd7DegwEA6bXYcVGRvkyDLZGeoSCCi7cSACm64Tsk8xuPf9SHD7q0nhaBtS2C7izI+KSWF/XoLbX0AK+6UC7PFZPY+lEnOalx1pScbqBaksGGejzakrKjgrxFJbFdYXZC8K9PjEVHbLUOXgcqrGlHvYyoPVW7mN5at1J8vX3gG2srM3t5MH1TvZ2Ys38lU6mmme+lgHPiJhebAj8WAij5Mzwg1Jy8/I/iES7MvdceX7d7QVrLakt7cx77TvZN5ptRruNLgVn1vyVjCl47yEJfdrzgtVUT6DlxTsj4EzlPfNrekZJYZIRajZmBmfk9vCpSvxNiNG3mScx4rcfX4BfQkSBZnwC82F5YQsJz1CzeHkUknhQS1B8h4P02nSrDFGYzah4MXJ9NY2TEk+5FGPnS42QQ+cOJiyp5JmLq/TSeZoL/HwoNrUQnI76wtIYRiC5yXyrq1rkE0rrO5lYYa3BIb7XnJ5mTMOokRTPxDh7602sre3MZK172Qk2xMje2fOyL63yMjeaVnCZ5fpfrMdOVTpcyv+HH2KfjN/d5qHzU7pczu4YzWLTc+RxYseJyOFWabolmBS2G924qPy5S4ejnGa6ZtXAJrwGBo2QXLhO1WRGP2Zr4+FeiiMFWeCf/nZsmV2oz6Q1acneGBi//WYPU5m/Syv14hXuP/gIYbZdZv7ZGFfUfH4Cg5Tmem7YuTUlCnPVD2L83eOaGsCGGqbM157IodWTB7Rp4PoU0xYMVm1o09Rm+bvdtR+O2q/HbXfLr3Xjj7Z9u0v5b7j3kvPWtCN6Je9JYAc+9GnTgmQoxN9KoF3rAHW0QFYxzKojv1ae+907+h07ySG6tg/XgnV0To5aR9apI5NcDoWo2n8xkgc6LGRIHSkEq1jP6B1nMlTEV7HfCOVOB1HbmBfjp++yen4cXqDv7VCXZdLQA6oqzHUCGIzmcRFysVUidyxv9feZ+QOpT3JqnYfyXRDgDhTgCCwJfAyAyh7EpcgkZHVxZTjZQT3ncTfcgVySBDUAISLpDbI3RQI0nXiYT52pkm32FE8c4JpZa0ydBz6I8OWeznpcxrI9eyK5QkU5QzYHipR+FGaKXKAsOuSPaxSqyfFVxZkQyov6ZLWhVvWTQCuWNZ4zsAfIuCs5bn9B4ft5ZkNx8cE/fB1KLrEcRN2zTNbi53GXcoTTR9RHiBuOCAzUvAVaqGr2zpNCFGVLc30fh2o7KJh3YjJ7pYiN2hWVBhXan0TfggnfvAimfl7oPRxOtF01ixs1oBqgBaff/bTaJoN2IYoB9bvDqnfATdaonLrpO8RyG2f1cYdbmhHkb2wY1KG1I++Nzc6ooZ+TpAfN74/Hyougb+1nTB034FBPgoAnFeTZASwtwBSOVi98StgY46Ojt3Gfy/UHMZekQRM9A0MHxhWwqA5LOSKnBO4kSfpdco1ACsOCYTgIPw4VZrPnSczxzOTEUotUlXRWZeAz1ZPch1EmG91/TBLM4F4rt+AUdQZtYQUk/5Qar+RC0GFoc8/M6d7MhvFbCa8HUNLRG3FSV81ptGRIRWJDCYzeGnNoTHQqtq2i3dUDYLYyxBcEOnYk/EkK4iEiaDDw0SZ7oVgJDdtU5p24cZYmLKS18g5IK0oIGzI7DCnmMZ7bm/SQiP9ghfMlyUfoBQG4SXDV0PmXSD64dQPyTrP/WbTRwVCusQwxlXicF1IV27pZc1BL71kQJmBL1FnTlOT2fL3gUcqQPbohOwIocZOia3OUbjolZcpwJ/JXAe7Iwo5mBKdI1vfs8lXXsvrCHT3BKBELithpPjI9ugrR5DLiu5Fuixk1WX6UgsZOyIWFY3g8a+xzYQ8dYvfDeUKEuHejGIvGXM5KsGMrr7aGV+Pd9wxcXz+gp94XHtkxYyG6+dRvfaICg1mHy6Gtxf0Re3JF59/5kHQo98e1/6AeT2p/e3zz2ruH3z8yyP+9YLEmUe/1L6qXVy4nl7dYh6IhqdehreNafph2s8JKh2dUAscKcwNua9+czPYpSn8Imi9I39VM3ymlihzLYM2ELtGQCFiJyxodSZpuCXoSRoY2y1QJiXz9XOYxTGajc8r0zInjmmzHSJas8T9SKFWm682vdmwS1Ve+gt6gtc/XoRQ8GX+eVnBImQZvCOxyLEDBJT44nc9HAit4CMu5jWmKqURiM4VIKlfpkovGUXY2N6GfsnZdwtsiD/5rUq67nBpeYm6NOZbgRwWzheyb2jjV5y003s2wRzu8hpBI4CUWA3aa20t5Yzw/aO9bTPCqzpnS0vpF3OhmqJ0rYODeVNjJ2jqfOnxneHZzHWr9t3bV98z9iqSjelM646Cz5tkN4RZA3jGwrjiPYQWoPYQrk6pFKRwNUn/1xmsG3Skr1PUqKEum9XQnwEFuGLnmYMGM4kptuCLNYUC4hw45aGfKpkusSDcUSlQfYE/JJXkoCp8Y8vDJTA01jm2w0MJkVxaQ1yD5IokVimylkfcxlr7TMOkKWovuQIH5JqtISuHRXQpOuNrlaNVVl/cFeZWmNMBYR/WmuUoxEoDa9ZMMD20RoAfUrODIq8LuDHX6XBP3CSc36Gxqapmen+NBW7ik6xZtwQ5T2lzHDrNsjOdFd0XP/5obqO+LyUlBqxRVISPVisrhs3aGStvsA1LVSLKELx2x3CgFE1wB3UINEDto3WWbgut6EyN1GU3cNmwIXiYTN4pfgUXzWIfFPJ+AHs/rVvDseMwjvyveQfdBx+LLbvbtIScVAJac9S529zrzGfdBRdXMh67aY0ZtfZ9VhinOamIWY/g0Ug3TKa9awzN6bKAz0oVM5qNDJLvuHYnpZF7lGIfGYe4kGTMAJ8Zxzt7EG2442Scz0xoiBw9qb82mgN88w3ecidCGvYS9Hwk6rxIpyS3uxM/nY0c6VESgmM+mLPj2rOh13gYTRhsKrH90RagTwDf8JZwci3EeZo5Ew4MkRPo3hzbzVcvsxsOmvAFrN5Sj+bkowiKWx+enE8/ZpKMVo+H7sRetv307ULQoNIJRU71qOydW1nG5OYcTmGxN9f5QGr1QEvlTK9paV8DQmuEQ61WD0bNsCutAGW8kSjM1ueNUbC+aF9Qr5JmgPVPYTQh/ecm5fRqKjVGjEgi62GSGBKr684o0qs45QgjzFhw24BPhNMMEvRsTeFs3Yd4Nbi4nGFCHp4GVg5SYoxuXziNWZWFPa8szKV2LcC1QNMMxribBcBHxbNWRXWvZjKvQo0QEo58+jw3Dgdr7eW05EujM2CKLYkwFa53f118mT2N7zvUg3bEO7ldBZKwylLVaR3dASRBA51WeHl5GHcARij1A2Fq3d2MphqwNFrH85gIERwCVk6Cqdbtq2zDY6/70HtY5okKh0s2Vy/8uF1IyCt3+eQBoTA0SmGNXT65+y67fhhVa9/GTb6YW7kF+Fn7nXWwLrBgCuQ313S8jT5oykfrc51hLRclZgf5ZHBXVUxxbHQKn10f5b6jspHhRS1SzKUTvDObUJUSqlYhnIHis3opR8OcoUQlyeYoo47bEhQncdHKPL5LB2OwDKTVEV/1GXLsbrdlWoe5ROjBbOzejC3PXMsPiaTEiwNSsppjqk0pJc6JUY4T3J8BPrziVTT9Y0ibml0NMi5JgZuugHYSQ3fkg8qWUCpWYgYkFgl3V87Gq4DDIHXDfJIsNCd+hlUB47Axrga+bbOUS6HRO6FtfoSldfpVyyd4AT60wyEP+r23CJY0HHGbJEOO7LyMhk9kAYeIljFOfcVdAk6AjTDYGyZwJFBHw+RDNpwNHb0OM8mkfP3da+mUbvK6owfUnUjes93SUW5iOgKscCrkMWPA0mnIAnDyKS5FIyUw5Uhq889E932baDr1pVSgb5Hco3nQsC1nE4LAvUnjKEGWD2SQRu14QROVYqlhvep0DrLpnBMi8Uw5CTsefEm0ZSz1eMW676bueJrXPdR/k7hfgMHo/nankVAGcBpFeP/0sSxh3qpPi06oLCLtH0sMLApFi85x4bBgFzPUQpaSISoQdqWosTfjetpUo9xKQWKV56PdvvMVsyLSkgdx5wtmv+HGWoYALRFLHJWsaxRNNkYEXePKMah+63UXX0PnKZV9LlO7U3y7tvCCFklQk6xQcRlJ21dPCUxC8GSdpikHIIXwXgxucWMITraaEQMPrEesLwozq8dWClSwFyb4OLvkzzYC/AmX5jNe6NVUuTyj4D4EnxXJJTyIO1NlG0JPHNr9trS51SJPaz14LyyVwnuVGo4p7Yd8qiYNuggvictGgEIVt2udPVFwwuF5mPe0QiEbeZq1c0dlvWtJoDJWHGZg00l2dYVkJAa7JJO6T9tSp4uWOVH+KFmawX6kkZDJLQ6BOMgSbsWTu+eznJM2uPVRERRHQPKd01QpMBJRs7oefFXyzLJpkQ4upUpQkD44cbf205vvGcXeZIs5tc/9OMm4SFa37m5Cf06B347LlSaMJmksKpfBgCk5QZpEUefhBGseA22O2KnzmDR0kf+emxOFmycfpU/qNAmxvvXckU/GcGyK5KqwwTniR9RukknoP9+SbD8WYuC8o2btOQFxKqFMnJSLjXJrMoo3QEWwSZljzVflOIsCaepqDQyh5em0t5pRLMefvQ9GsSLkkwdxZ0axB0ZxYpUjn1URvP1kCONNRV3Q+SssYiEn6ylNnaNwg63fZcxcHAFfzgCHHfQHWPkygJSpsJfCMQyLLZiQSHMJ3x/N2rNbdlDQkyyGyXm8FGAnd49eTZxUBsJ4k14lnLgZTsMbPQ1BbcpsNKSJ1+reqqIEviQGY4vuwMUJrrmeBA+UGBaduLpyE9jirWthFJx67kDSc58+og1vLvOHwPvf+u/JD05RSn2nyb2ISiGJiG8YZoTRSRbiLA3I8QnrFAwgv1CfVFVykE9hHubC4WrvTj+kvRnJtXSEIScMUB+DRPxiSPxbvPP1mlT3TsHcvLEjVo3E18tluhm4DTFiV07/HbHzgr0RnOUjoI20Pd4qy6yT2sHhKbHAb9EPeKBjkivNKp3lZpWjo/07M40V+Bc8iDszDcstfqAadYovr1aHaE6hcPzBKiNZJ9hRKtstBQOxHxGEpU/irKntw1cUYT8kSZs4EaNc0p85e9HXVPQF7L0J4g1jIIZMbwqYApVKfDb9ko0y0lyzv7I9B64MMVL8LLW3rpO+MTIgVcMbSYL+/xhULZQ6YbPtE/orfsPEwvAbV7PUvfIkdrmynE2MiDrH1xXOJhkNhGco3F0pwvkWxZwG7oKkqNY+G+CvCrgTyZU7Sct1/xjxkNgHH/9Kx45YnyRUj46jOgFHGqNRlOPQNGkFRm9yjrIqr6suGexeyadgRkBOIXYe7iw8gBzRotbg2l199QLwU9QtXnPskrHTxIPG7gfjIppqlSsnmWrsFvlZfcehMmkXu67VTqVjeNamNGVyj3mW6qg1Jz9EQftf+OjBn5l2HFdwVw4PQB2QXKGSjpZ3oPTZ1vEOf2d9GCL4kHiKBjY4w2gBoigZ5FemercRyH0Jb949dmMR4gK/FJvhfGKRu6qyXmpe/ovgEF+I8viPv/9fv/xlN/7yFxaVHbe+nhE7x80ghxJMPBnBqJWM2KNNd+QIMWV6JoJ+97ZqWii9G8bka/aU5sQLmZBPtJ+OglTJoyigb8BnVtTIKSoHyce54goiiVU/0Cyp3IJUu6aKx2xL8QZbAy+mwj4PBcQux7cQAv4wnSRa8G2liLq/POzyaP8ucOkKIbfaiL+/f/f7xvXTcOMtWVnMRhPjC7WyyvQbzXljQ8t+gElfu8ethNSsiIoTYu+7E3/Sxb4Hp6Ynb9Z5pX6iF9achBJ8hjIkFlPY+ksk6QH7+ZpjsQxkhruAwcicCpnZwCAOwqLQR4nj9uUhyBJenFoRj28c8Wpj0IioJjU8uLnRl8YeFuLQFkEMjNdrwnyPyL3BFwS9G+6Gc8I7rtcUFyRhAMJs5EvZ+Nk+m11FcUUeXPvL7nx0Awo78KVlbmpfze3L3e5TiLqAeOtzSJuiq8AvrZlX9I035Rb54D0736kuy7jgaPr/EiGx+tHEggMue8luxqUpSSo2JnbFsFJFffEtC0Jr4p3KwmcFJWZ0K3kMEeB/xXIJ31PvF8MkyWjgBwmOLnvT6C1ofNiSF65PcrJY3Zr7vQdEIh9Rons4npLNZnIrlhIZCWhpklC0NTdBrghxfrGDnutck8wkIR9OVLzVqB/duUsJPxPnQTnFrN08jtO1pBCufjoqJYEdldLAjkqJYEelVLCjUutH0afD0q+hwMeS3MeKaJ6JsZEoKfRTitRQYEPNjoA/66c33yP/hCBbmITIwzGZSvIGiUiXIVTuFC+RSEms//R47zjCgH2eD/IJQbMyixNvk9XN5CySdDjmipD85Hx9cY6AQExcFICSRQkpKsyUSwmG0OVi/sfEF52vSZF21NamBO5cAZC+cceydnaTMsWO5midXZnlls0hZss4KdVaxB5SOJ1oJ/Dg2M81oozcsW8qJURH/+c890C4cdjOPPnef47iUfTpMPp0EH3ajz4tyWWMsx5NpmFrcaZhe3lRcM40pLrgm2cato6PQqZhe7OK4PN5gFQXnL6U2h3DvD8bpA22HlVWBm+byuCv8HTtlT4d1whf0mxl9mHruIP0wzOGdaEkMS4pG0IUatxQ4VOipF7wnGs75Mpx6Yk4VJzrbMSjjxIPbzmYknyOjMVCeuj0Bm7SALLqGEuxJM/x6HBf65MfRpR4GFHiYUSJIaV8dQo5xLf0qx0nwqUNFjNPCQF7RxjSNJRlonFWpz1rI5eUe3Qjjezv7e08/UlKWUvinW46HW7HXiicxJsg2KyWi6fibt3y2GW/SfRDAJ+YWLZuzyJVfI88z0LueOLPQlZbt46wPcZ8mGTkebzV+OVt2oxK7OaQYRIG6uVxIo1KsltZeEFqlK+a2FyYk34Ycbb4ArcUaukzykxfwAnL2dmLOOMB5WC7w7CMNx7W9o5P2y3H02LeeLC3kjcedU5a+yYLW3paOw97Ccf6jUd5OXHPkqDfIHXCqRYLmORRYJLf6Cu1l+GVODt7UcPVSdpuEb/XTEmduo9SMa448CeJa0eTLJXmGhyUTtxKNas41+HxoeZn75mdbUe5/O0ol79tcvlbjgJOok/H0aej6NNh9Okg+rQffepEn9rRp1b0yY7lOBrLcTSW42gsx9FYjqOxHEdjOY7GchyNJRbJbW+xuB0L27GobUd1GI3/sPTb5vfKRnwg6vsg6vug9ORB9Gk/+rS6fsU8uMpinIsqybCS14B8V/MaAn3YmNe0Djv7x0YOk57WlsQWnXliNO5ZxiIoGizZOD2yms+cBD7DPqLsrxMb71vmNAtarmY0jglQpXC9LomTaGeAPiPBKAQaFr6wr1SdDAMivpNWcpq2F5HmYUEWQHi0VgrW7cPTzkFJsD5ZuaGdw5Oj4yNze7Q22s8FK0vydSv85GTI0fT2MnO3djqq2tGOgfJ4i4dr3/DTS7Z1SQ+VO3vcutvOlga2zva2193e1XpT++C0fbzd9p6Y7d1IcVqywpU7XGQfNtjhc356ox32PTzkDuvAfu8d3ncceKsdPunc3w77FSaWfBB+JV99kVUC8Vi571t+bBk3rmp0ITDPXbZTx+JvnMq93D869Arr/BVtyigvR/rq57Musk0pFwm5QlK4SVJuyQ3JtvpswFb3Oc1rVTdJ7YbCqBGhRWuvLlZEehi9FFHRKRwAZOmXp9fpLSpJxhnHU/aXiEzNvenC4gePq66PU9dL+vqzW5mcythz7t0QEoA0xVWtFypyi5SyhSBcyw7kUnVMb9S9LW7Ug72jI8tyN9LGKk+HAGLp9/3sfVZ5Dg2P/do9s+wQzjVXfQLvyFAxisVstHVyoEevYmvN0fNGGWoKMNOayM5Wmp9fP+J0Hy4SOU2uQqFaLuweFxRn8wVZgJH9o/5n+Ckry3hvRWH7qyns+HSvvd2lbjX+/U2tofHW/8Yv65fJ+6SfVNLXgQFco4eWEdh8g9UU1rkbhfE4mMQqaexov1N1V8dwNKXa7Jb06GfiaL4c/HdMeWeE4gF7KSNJss9GyJLRTATnC2OL6M82gbYpUEFsdT51DO/5mlfau0YDUQ/NUlGnMrhtxWxeJb8iZcZGKM3Gbgv7wvTdIoyRS5/L0r7FMLSY8j6HOieEIxdNifcPw9Q1IE9enpOhDj6qYFclcPvhMKfPOLR20eTyKM+LUCq+mfMm16wniRyiuLywRCaEuzvJ36Vkur3Ko+bt28lkktw2pjnKeTJP0CmLRZLzvYHeyeVH7RIqpoS77itXLe7Sh3bfICTUu9/YqaRpP27oRSrlKGsELuGWSHCg5vnTXUXPY8d3tuNDW4ueFRxCzI1eo8wnFDE2zUdppUrRMmaA8OgyprSo8QcRP+2Yfm9bwIkTyrfaz0hy2cwWsGhxaVfdLG6Ch7RB4Z7VqoS5Ymz5mj/zC/FuVjdauZeHe6c74mHrzjIGk04b3mPL+zdX4ZV2HD0vVxzakUWyHVkk25FFsh1ZJNuRRTIOLaBPe+aTtUnSp+Po01H06TD6dBB92o8+daJP7eiTHYttYz/6xbZnW7NtLbKXr7ZvrvZ8d9ZG670PNF1YV9fx5Lhv9jb35LQOOwcHxrq6oSdnwYEQ8Y4r18tvlWfP8lNbQKJCtCs1Vnnm9t1qOUnbFyChRBPJe3LsM+qJ/dOVKsLe8WL+qFt3GH06iD7tb0gAG/Pc/UarVXNq20HntFM20K0ObDg+OTg53Jrlzu/Eb263HVti+wLtcpt2mbRK9fEV02QyZcO6ez8mgZZhv+f6XOXmtg+cGnHmNKY0GQkEr5PhRrVnTuKj4mLjBsfrshSrpV1Q3prgCRQulQcjQAAlyPImhR9xZQRKL4eodBoMLiV/tq9wUnvs5CVTtMjU2XYy1r/OKJ78iWRgc1KNtNT0kgNEMsqa0L6iqsVcy7vyRtg7UmLtRD6wTuRDenBMdPz9hgCAkfxBKf+9AYAAJb8Qu3Ja84HJu/88/qqz19o7Od55Wtr/09pZDSqSo0cRa90mfusfKO3da4WbTyJFa/VgPn182NFUMnPsk1L4mIGLLvTwtvjwurN76WS86W2jtX/Y2Wt0p412s58VPSetT9zxxIFGG8Qje5S/VlznU23m8GgBD6iOxz6geOzSUUU09hc418nMkexEe/tx5Jbg2/wc4bqFfov1vKCYNT+V9oIxXOfDtNzb7kJOd9RoO07HhupSCNdBayWna5+cnHSsp6mzGV58JQ+bsyzPPSGOitL3DZhhK3mgvQaF6mrP+enqAK4OOOGAAlM4oMXaeBm/s9QcawO1c9X4E2TbiqKveKnjRGDIU7H0DlKKd0HKrfgYkcEIBeQmua3kSJ159aL99Ot0ihJhfARFdxXFmqOviOd+SeFNT33UeHN8Pf4S8KnuKYq9otrX7si4T9ll7THbzi6QHFk8rj36+fXXX18IY31Ue1L7YzIcf4F/1f6Lthmeloi2i35/cDEILwEQ98td7kULek7zUs9cC7z/GH1+f/HnF2/OX/74w6O797muKvZwzONokdK2PvNgSm8wyf0PwkhYZDp0wp1rcXM1tbPfPm5tKzMtYQZzvscFz/32m4QrFLOuZwXFBZVlAkeBxOWk/fTDOFM7BL7OTg87x14ma9PS3BYXEjNHnbqXlJHJtxcSA+h/5c7JhmtcPtT+3unf5BeAaZKp6qI3Dr+4uV0nxTVzBbdWvbTXbh/00s5Be79zcLl/eNQ9Omqnl93D7mGrcyg9Ef9wJ3t6MUnHeUEJMFlaXLAxj1a4tX/UPtg/aR+2RAG5cCfhonWxdwHR0D2580X3tPXFb/83NZJwaw==', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(256, 'wpcf_users_options', '1', 'yes'),
(257, 'wpcf-custom-taxonomies', 'a:2:{s:8:"category";a:22:{s:6:"labels";a:21:{s:4:"name";s:11:"Catégories";s:13:"singular_name";s:10:"Catégorie";s:12:"search_items";s:31:"Rechercher dans les catégories";s:13:"popular_items";N;s:9:"all_items";s:6:"Toutes";s:11:"parent_item";s:18:"Catégorie parente";s:17:"parent_item_colon";s:25:"Catégorie parente&nbsp;:";s:9:"edit_item";s:22:"Modifier la catégorie";s:9:"view_item";s:18:"Voir la catégorie";s:11:"update_item";s:28:"Mettre à jour la catégorie";s:12:"add_new_item";s:31:"Ajouter une nouvelle catégorie";s:13:"new_item_name";s:29:"Nom de la nouvelle catégorie";s:26:"separate_items_with_commas";N;s:19:"add_or_remove_items";N;s:21:"choose_from_most_used";N;s:9:"not_found";s:27:"Aucune catégorie trouvée.";s:8:"no_terms";s:17:"Aucune catégorie";s:21:"items_list_navigation";s:38:"Navigation de la liste des catégories";s:10:"items_list";s:21:"Liste des catégories";s:9:"menu_name";s:11:"Catégories";s:14:"name_admin_bar";s:8:"category";}s:11:"description";s:0:"";s:6:"public";b:1;s:18:"publicly_queryable";b:1;s:12:"hierarchical";b:1;s:7:"show_ui";b:1;s:12:"show_in_menu";b:1;s:17:"show_in_nav_menus";b:1;s:13:"show_tagcloud";b:1;s:18:"show_in_quick_edit";b:1;s:17:"show_admin_column";b:1;s:11:"meta_box_cb";s:24:"post_categories_meta_box";s:7:"rewrite";a:4:{s:10:"with_front";b:1;s:12:"hierarchical";b:1;s:7:"ep_mask";i:512;s:4:"slug";s:8:"category";}s:9:"query_var";s:13:"category_name";s:21:"update_count_callback";s:0:"";s:8:"_builtin";b:1;s:3:"cap";a:4:{s:12:"manage_terms";s:17:"manage_categories";s:10:"edit_terms";s:17:"manage_categories";s:12:"delete_terms";s:17:"manage_categories";s:12:"assign_terms";s:10:"edit_posts";}s:4:"name";s:8:"category";s:11:"object_type";a:1:{i:0;s:4:"post";}s:5:"label";s:11:"Catégories";s:4:"slug";s:8:"category";s:8:"supports";a:1:{s:4:"post";i:1;}}s:8:"post_tag";a:22:{s:6:"labels";a:21:{s:4:"name";s:11:"Étiquettes";s:13:"singular_name";s:10:"Étiquette";s:12:"search_items";s:31:"Rechercher dans les étiquettes";s:13:"popular_items";s:22:"Étiquettes populaires";s:9:"all_items";s:22:"Toutes les étiquettes";s:11:"parent_item";N;s:17:"parent_item_colon";N;s:9:"edit_item";s:23:"Modifier l’étiquette";s:9:"view_item";s:23:"Voir l&rsquo;étiquette";s:11:"update_item";s:29:"Mettre à jour l’étiquette";s:12:"add_new_item";s:31:"Ajouter une nouvelle étiquette";s:13:"new_item_name";s:29:"Nom de la nouvelle étiquette";s:26:"separate_items_with_commas";s:41:"Séparez les étiquettes par des virgules";s:19:"add_or_remove_items";s:34:"Ajouter ou retirer des étiquettes";s:21:"choose_from_most_used";s:49:"Choisir parmi les étiquettes les plus utilisées";s:9:"not_found";s:27:"Aucune étiquette trouvée.";s:8:"no_terms";s:17:"Aucune étiquette";s:21:"items_list_navigation";s:38:"Navigation de la liste des étiquettes";s:10:"items_list";s:21:"Liste des étiquettes";s:9:"menu_name";s:11:"Étiquettes";s:14:"name_admin_bar";s:8:"post_tag";}s:11:"description";s:0:"";s:6:"public";b:1;s:18:"publicly_queryable";b:1;s:12:"hierarchical";b:0;s:7:"show_ui";b:1;s:12:"show_in_menu";b:1;s:17:"show_in_nav_menus";b:1;s:13:"show_tagcloud";b:1;s:18:"show_in_quick_edit";b:1;s:17:"show_admin_column";b:1;s:11:"meta_box_cb";s:18:"post_tags_meta_box";s:7:"rewrite";a:4:{s:10:"with_front";b:1;s:12:"hierarchical";b:0;s:7:"ep_mask";i:1024;s:4:"slug";s:3:"tag";}s:9:"query_var";s:3:"tag";s:21:"update_count_callback";s:0:"";s:8:"_builtin";b:1;s:3:"cap";a:4:{s:12:"manage_terms";s:17:"manage_categories";s:10:"edit_terms";s:17:"manage_categories";s:12:"delete_terms";s:17:"manage_categories";s:12:"assign_terms";s:10:"edit_posts";}s:4:"name";s:8:"post_tag";s:11:"object_type";a:1:{i:0;s:4:"post";}s:5:"label";s:11:"Étiquettes";s:4:"slug";s:8:"post_tag";s:8:"supports";a:1:{s:4:"post";i:1;}}}', 'yes'),
(258, 'wpcf-custom-types', 'a:0:{}', 'yes'),
(259, 'wpcf_post_relationship', 'a:0:{}', 'yes'),
(340, 'autodescription-term-meta', 'a:5:{i:0;b:0;i:3;a:0:{}i:2;a:0:{}i:6;a:0:{}i:5;a:0:{}}', 'yes'),
(349, 'installer_repositories_with_theme', 'a:1:{i:0;s:7:"toolset";}', 'yes'),
(452, 'category_children', 'a:0:{}', 'yes'),
(737, 'the_seo_framework_upgraded_db_version', '2701', 'yes'),
(1247, 'wpseo', 'a:14:{s:14:"blocking_files";a:0:{}s:15:"ms_defaults_set";b:0;s:7:"version";s:3:"3.5";s:12:"company_logo";s:0:"";s:12:"company_name";s:0:"";s:17:"company_or_person";s:0:"";s:20:"disableadvanced_meta";b:1;s:19:"onpage_indexability";b:1;s:12:"googleverify";s:0:"";s:8:"msverify";s:0:"";s:11:"person_name";s:0:"";s:12:"website_name";s:0:"";s:22:"alternate_website_name";s:0:"";s:12:"yandexverify";s:0:"";}', 'yes'),
(1248, 'wpseo_permalinks', 'a:9:{s:15:"cleanpermalinks";b:0;s:24:"cleanpermalink-extravars";s:0:"";s:29:"cleanpermalink-googlecampaign";b:0;s:31:"cleanpermalink-googlesitesearch";b:0;s:15:"cleanreplytocom";b:0;s:10:"cleanslugs";b:1;s:18:"redirectattachment";b:0;s:17:"stripcategorybase";b:0;s:13:"trailingslash";b:0;}', 'yes'),
(1249, 'wpseo_titles', 'a:56:{s:10:"title_test";i:0;s:17:"forcerewritetitle";b:0;s:23:"content-analysis-active";b:1;s:23:"keyword-analysis-active";b:1;s:9:"separator";s:7:"sc-dash";s:5:"noodp";b:0;s:15:"usemetakeywords";b:0;s:16:"title-home-wpseo";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:18:"title-author-wpseo";s:41:"%%name%%, Auteur à %%sitename%% %%page%%";s:19:"title-archive-wpseo";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:18:"title-search-wpseo";s:65:"Vous avez cherché %%searchphrase%% %%page%% %%sep%% %%sitename%%";s:15:"title-404-wpseo";s:38:"Page non trouvée %%sep%% %%sitename%%";s:19:"metadesc-home-wpseo";s:0:"";s:21:"metadesc-author-wpseo";s:0:"";s:22:"metadesc-archive-wpseo";s:0:"";s:18:"metakey-home-wpseo";s:0:"";s:20:"metakey-author-wpseo";s:0:"";s:22:"noindex-subpages-wpseo";b:0;s:20:"noindex-author-wpseo";b:0;s:21:"noindex-archive-wpseo";b:1;s:14:"disable-author";b:0;s:12:"disable-date";b:0;s:19:"disable-post_format";b:0;s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-post";s:0:"";s:12:"metakey-post";s:0:"";s:12:"noindex-post";b:0;s:13:"showdate-post";b:0;s:16:"hideeditbox-post";b:0;s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-page";s:0:"";s:12:"metakey-page";s:0:"";s:12:"noindex-page";b:0;s:13:"showdate-page";b:0;s:16:"hideeditbox-page";b:0;s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:19:"metadesc-attachment";s:0:"";s:18:"metakey-attachment";s:0:"";s:18:"noindex-attachment";b:0;s:19:"showdate-attachment";b:0;s:22:"hideeditbox-attachment";b:0;s:18:"title-tax-category";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-category";s:0:"";s:20:"metakey-tax-category";s:0:"";s:24:"hideeditbox-tax-category";b:0;s:20:"noindex-tax-category";b:0;s:18:"title-tax-post_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-post_tag";s:0:"";s:20:"metakey-tax-post_tag";s:0:"";s:24:"hideeditbox-tax-post_tag";b:0;s:20:"noindex-tax-post_tag";b:0;s:21:"title-tax-post_format";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-post_format";s:0:"";s:23:"metakey-tax-post_format";s:0:"";s:27:"hideeditbox-tax-post_format";b:0;s:23:"noindex-tax-post_format";b:1;}', 'yes'),
(1250, 'wpseo_social', 'a:20:{s:9:"fb_admins";a:0:{}s:12:"fbconnectkey";s:32:"11bc8d80ceb2392d8f4b5d1cccfe5326";s:13:"facebook_site";s:0:"";s:13:"instagram_url";s:0:"";s:12:"linkedin_url";s:0:"";s:11:"myspace_url";s:0:"";s:16:"og_default_image";s:0:"";s:18:"og_frontpage_title";s:0:"";s:17:"og_frontpage_desc";s:0:"";s:18:"og_frontpage_image";s:0:"";s:9:"opengraph";b:1;s:13:"pinterest_url";s:0:"";s:15:"pinterestverify";s:0:"";s:14:"plus-publisher";s:0:"";s:7:"twitter";b:1;s:12:"twitter_site";s:0:"";s:17:"twitter_card_type";s:7:"summary";s:11:"youtube_url";s:0:"";s:15:"google_plus_url";s:0:"";s:10:"fbadminapp";s:0:"";}', 'yes'),
(1251, 'wpseo_rss', 'a:2:{s:9:"rssbefore";s:0:"";s:8:"rssafter";s:64:"Cet article %%POSTLINK%% est apparu en premier sur %%BLOGLINK%%.";}', 'yes'),
(1252, 'wpseo_internallinks', 'a:12:{s:20:"breadcrumbs-404crumb";s:30:"Erreur 404 : Page introuvable";s:23:"breadcrumbs-blog-remove";b:0;s:20:"breadcrumbs-boldlast";b:0;s:25:"breadcrumbs-archiveprefix";s:13:"Archives pour";s:18:"breadcrumbs-enable";b:1;s:16:"breadcrumbs-home";s:7:"Accueil";s:18:"breadcrumbs-prefix";s:0:"";s:24:"breadcrumbs-searchprefix";s:18:"Vous avez cherché";s:15:"breadcrumbs-sep";s:2:"»";s:23:"post_types-post-maintax";i:0;s:23:"post_types-page-maintax";i:0;s:29:"post_types-attachment-maintax";i:0;}', 'yes'),
(1253, 'wpseo_xml', 'a:16:{s:22:"disable_author_sitemap";b:1;s:22:"disable_author_noposts";b:1;s:16:"enablexmlsitemap";b:0;s:16:"entries-per-page";i:1000;s:14:"excluded-posts";s:0:"";s:38:"user_role-administrator-not_in_sitemap";b:0;s:31:"user_role-editor-not_in_sitemap";b:0;s:31:"user_role-author-not_in_sitemap";b:0;s:36:"user_role-contributor-not_in_sitemap";b:0;s:35:"user_role-subscriber-not_in_sitemap";b:0;s:30:"post_types-post-not_in_sitemap";b:0;s:30:"post_types-page-not_in_sitemap";b:0;s:36:"post_types-attachment-not_in_sitemap";b:1;s:34:"taxonomies-category-not_in_sitemap";b:0;s:34:"taxonomies-post_tag-not_in_sitemap";b:0;s:37:"taxonomies-post_format-not_in_sitemap";b:0;}', 'yes'),
(1254, 'wpseo_flush_rewrite', '1', 'yes'),
(1256, 'wpseo_sitemap_1_cache_validator', '3LFGS', 'no'),
(1257, 'wpseo_sitemap_page_cache_validator', '3JsEl', 'no'),
(1258, 'wpseo_sitemap_term_cache_validator', '3LFH3', 'no'),
(1259, 'wpseo_sitemap_language_cache_validator', '3LFH8', 'no'),
(1275, 'wpseo_sitemap_revision_cache_validator', '3JsEw', 'no'),
(1281, 'wpseo_sitemap_167_cache_validator', '4Sey8', 'no'),
(1285, 'wpseo_sitemap_169_cache_validator', '4Seyr', 'no'),
(1308, 'wpseo_sitemap_180_cache_validator', '4Mf7X', 'no'),
(1356, 'wpseo_sitemap_nav_menu_item_cache_validator', '58xVL', 'no'),
(1357, 'wpseo_sitemap_nav_menu_cache_validator', '58xVE', 'no'),
(1360, 'wpseo_sitemap_post_translations_cache_validator', '38wTL', 'no'),
(1385, 'wpseo_sitemap_192_cache_validator', '3aDuP', 'no'),
(1433, 'wpseo_sitemap_194_cache_validator', '3IiM3', 'no'),
(1482, 'wpseo_sitemap_196_cache_validator', 'pkwI', 'no'),
(1501, 'wpseo_sitemap_post_cache_validator', '3LFGX', 'no'),
(1535, 'wpseo_sitemap_213_cache_validator', '3yn7Q', 'no'),
(1581, 'wpseo_sitemap_222_cache_validator', '4Seyx', 'no'),
(1587, 'wpseo_sitemap_100_cache_validator', '6EYml', 'no'),
(1595, 'wpseo_sitemap_224_cache_validator', '3nP9T', 'no'),
(1642, 'sm_rewrite_done', '$Id: sitemap-loader.php 937300 2014-06-23 18:04:11Z arnee $', 'yes'),
(1645, 'wpseo_sitemap_cache_validator_global', 'kWcX', 'no'),
(1648, 'rewrite_rules', 'a:107:{s:34:"sitemap(-+([a-zA-Z0-9_-]+))?\\.xml$";s:40:"index.php?xml_sitemap=params=$matches[2]";s:38:"sitemap(-+([a-zA-Z0-9_-]+))?\\.xml\\.gz$";s:49:"index.php?xml_sitemap=params=$matches[2];zip=true";s:35:"sitemap(-+([a-zA-Z0-9_-]+))?\\.html$";s:50:"index.php?xml_sitemap=params=$matches[2];html=true";s:38:"sitemap(-+([a-zA-Z0-9_-]+))?\\.html.gz$";s:59:"index.php?xml_sitemap=params=$matches[2];html=true;zip=true";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:34:"nf_sub/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:44:"nf_sub/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:64:"nf_sub/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"nf_sub/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"nf_sub/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:40:"nf_sub/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:23:"nf_sub/([^/]+)/embed/?$";s:39:"index.php?nf_sub=$matches[1]&embed=true";s:27:"nf_sub/([^/]+)/trackback/?$";s:33:"index.php?nf_sub=$matches[1]&tb=1";s:35:"nf_sub/([^/]+)/page/?([0-9]{1,})/?$";s:46:"index.php?nf_sub=$matches[1]&paged=$matches[2]";s:42:"nf_sub/([^/]+)/comment-page-([0-9]{1,})/?$";s:46:"index.php?nf_sub=$matches[1]&cpage=$matches[2]";s:31:"nf_sub/([^/]+)(?:/([0-9]+))?/?$";s:45:"index.php?nf_sub=$matches[1]&page=$matches[2]";s:23:"nf_sub/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:33:"nf_sub/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:53:"nf_sub/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:48:"nf_sub/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:48:"nf_sub/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:29:"nf_sub/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:40:"index.php?&page_id=101&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(1649, 'sm_options', 'a:51:{s:18:"sm_b_prio_provider";s:41:"GoogleSitemapGeneratorPrioByCountProvider";s:9:"sm_b_ping";b:1;s:10:"sm_b_stats";b:0;s:12:"sm_b_pingmsn";b:1;s:12:"sm_b_autozip";b:1;s:11:"sm_b_memory";s:0:"";s:9:"sm_b_time";i:-1;s:18:"sm_b_style_default";b:1;s:10:"sm_b_style";s:0:"";s:12:"sm_b_baseurl";s:0:"";s:11:"sm_b_robots";b:1;s:9:"sm_b_html";b:1;s:12:"sm_b_exclude";a:0:{}s:17:"sm_b_exclude_cats";a:0:{}s:10:"sm_in_home";b:1;s:11:"sm_in_posts";b:1;s:15:"sm_in_posts_sub";b:0;s:11:"sm_in_pages";b:1;s:10:"sm_in_cats";b:0;s:10:"sm_in_arch";b:0;s:10:"sm_in_auth";b:0;s:10:"sm_in_tags";b:0;s:9:"sm_in_tax";a:0:{}s:17:"sm_in_customtypes";a:0:{}s:13:"sm_in_lastmod";b:1;s:10:"sm_cf_home";s:5:"daily";s:11:"sm_cf_posts";s:7:"monthly";s:11:"sm_cf_pages";s:6:"weekly";s:10:"sm_cf_cats";s:6:"weekly";s:10:"sm_cf_auth";s:6:"weekly";s:15:"sm_cf_arch_curr";s:5:"daily";s:14:"sm_cf_arch_old";s:6:"yearly";s:10:"sm_cf_tags";s:6:"weekly";s:10:"sm_pr_home";d:1;s:11:"sm_pr_posts";d:0.59999999999999998;s:15:"sm_pr_posts_min";d:0.20000000000000001;s:11:"sm_pr_pages";d:0.59999999999999998;s:10:"sm_pr_cats";d:0.29999999999999999;s:10:"sm_pr_arch";d:0.29999999999999999;s:10:"sm_pr_auth";d:0.29999999999999999;s:10:"sm_pr_tags";d:0.29999999999999999;s:12:"sm_i_donated";b:0;s:17:"sm_i_hide_donated";b:0;s:17:"sm_i_install_date";i:1474463287;s:14:"sm_i_hide_note";b:0;s:15:"sm_i_hide_works";b:0;s:16:"sm_i_hide_donors";b:0;s:9:"sm_i_hash";s:20:"24614fce04d7b6eea440";s:13:"sm_i_lastping";i:1474491602;s:16:"sm_i_supportfeed";b:1;s:22:"sm_i_supportfeed_cache";i:1474465502;}', 'yes'),
(1650, 'sm_status', 'O:28:"GoogleSitemapGeneratorStatus":4:{s:39:"\0GoogleSitemapGeneratorStatus\0startTime";d:1474491602.6299109;s:37:"\0GoogleSitemapGeneratorStatus\0endTime";d:1474491602.766829;s:41:"\0GoogleSitemapGeneratorStatus\0pingResults";a:2:{s:6:"google";a:5:{s:9:"startTime";d:1474491602.6328249;s:7:"endTime";d:1474491602.722389;s:7:"success";b:1;s:3:"url";s:102:"http://www.google.com/webmasters/sitemaps/ping?sitemap=https%3A%2F%2Fcedreo-designer.com%2Fsitemap.xml";s:4:"name";s:6:"Google";}s:4:"bing";a:5:{s:9:"startTime";d:1474491602.725426;s:7:"endTime";d:1474491602.752538;s:7:"success";b:1;s:3:"url";s:95:"http://www.bing.com/webmaster/ping.aspx?siteMap=https%3A%2F%2Fcedreo-designer.com%2Fsitemap.xml";s:4:"name";s:4:"Bing";}}s:38:"\0GoogleSitemapGeneratorStatus\0autoSave";b:1;}', 'no'),
(1710, 'widget_bcn_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=1271 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(5, 5, '_edit_last', '3'),
(7, 5, '_edit_lock', '1474358916:3'),
(8, 7, '_edit_last', '3'),
(9, 7, '_wp_page_template', 'templates/page-iframe.php'),
(10, 7, '_edit_lock', '1474358512:3'),
(11, 9, '_edit_last', '1'),
(12, 9, '_wp_page_template', 'templates/page-galerie.php'),
(13, 9, '_edit_lock', '1474491461:1'),
(14, 11, '_edit_last', '1'),
(15, 11, '_wp_page_template', 'templates/page-tutoriels.php'),
(16, 11, '_edit_lock', '1472569169:1'),
(20, 15, '_edit_last', '1'),
(22, 15, '_edit_lock', '1471901833:1'),
(23, 17, '_edit_last', '3'),
(25, 17, '_edit_lock', '1474358455:3'),
(26, 19, '_edit_last', '3'),
(28, 19, '_edit_lock', '1474358377:3'),
(29, 21, '_edit_last', '3'),
(30, 21, '_edit_lock', '1474358487:3'),
(32, 23, '_menu_item_type', 'custom'),
(33, 23, '_menu_item_menu_item_parent', '0'),
(34, 23, '_menu_item_object_id', '23'),
(35, 23, '_menu_item_object', 'custom'),
(36, 23, '_menu_item_target', ''),
(37, 23, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(38, 23, '_menu_item_xfn', ''),
(39, 23, '_menu_item_url', 'http://cedreo-designer.com.dev/'),
(40, 23, '_menu_item_orphaned', '1471902013'),
(41, 24, '_menu_item_type', 'post_type'),
(42, 24, '_menu_item_menu_item_parent', '0'),
(43, 24, '_menu_item_object_id', '5'),
(44, 24, '_menu_item_object', 'page'),
(45, 24, '_menu_item_target', ''),
(46, 24, '_menu_item_classes', 'a:1:{i:0;s:9:"link-home";}'),
(47, 24, '_menu_item_xfn', ''),
(48, 24, '_menu_item_url', ''),
(50, 25, '_menu_item_type', 'post_type'),
(51, 25, '_menu_item_menu_item_parent', '0'),
(52, 25, '_menu_item_object_id', '17'),
(53, 25, '_menu_item_object', 'page'),
(54, 25, '_menu_item_target', ''),
(55, 25, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(56, 25, '_menu_item_xfn', ''),
(57, 25, '_menu_item_url', ''),
(59, 26, '_menu_item_type', 'post_type'),
(60, 26, '_menu_item_menu_item_parent', '0'),
(61, 26, '_menu_item_object_id', '21'),
(62, 26, '_menu_item_object', 'page'),
(63, 26, '_menu_item_target', ''),
(64, 26, '_menu_item_classes', 'a:1:{i:0;s:10:"link-login";}'),
(65, 26, '_menu_item_xfn', ''),
(66, 26, '_menu_item_url', ''),
(68, 27, '_menu_item_type', 'post_type'),
(69, 27, '_menu_item_menu_item_parent', '0'),
(70, 27, '_menu_item_object_id', '7'),
(71, 27, '_menu_item_object', 'page'),
(72, 27, '_menu_item_target', ''),
(73, 27, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(74, 27, '_menu_item_xfn', ''),
(75, 27, '_menu_item_url', ''),
(86, 29, '_menu_item_type', 'post_type'),
(87, 29, '_menu_item_menu_item_parent', '0'),
(88, 29, '_menu_item_object_id', '9'),
(89, 29, '_menu_item_object', 'page'),
(90, 29, '_menu_item_target', ''),
(91, 29, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(92, 29, '_menu_item_xfn', ''),
(93, 29, '_menu_item_url', ''),
(95, 30, '_menu_item_type', 'post_type'),
(96, 30, '_menu_item_menu_item_parent', '0'),
(97, 30, '_menu_item_object_id', '19'),
(98, 30, '_menu_item_object', 'page'),
(99, 30, '_menu_item_target', ''),
(100, 30, '_menu_item_classes', 'a:1:{i:0;s:11:"link-signin";}'),
(101, 30, '_menu_item_xfn', ''),
(102, 30, '_menu_item_url', ''),
(104, 31, '_menu_item_type', 'post_type'),
(105, 31, '_menu_item_menu_item_parent', '0'),
(106, 31, '_menu_item_object_id', '15'),
(107, 31, '_menu_item_object', 'page'),
(108, 31, '_menu_item_target', ''),
(109, 31, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(110, 31, '_menu_item_xfn', ''),
(111, 31, '_menu_item_url', ''),
(125, 35, '_edit_last', '3'),
(126, 35, '_wp_page_template', 'default'),
(127, 35, '_edit_lock', '1474358543:3'),
(128, 37, '_edit_last', '3'),
(129, 37, '_wp_page_template', 'default'),
(130, 37, '_edit_lock', '1474358495:3'),
(131, 42, '_edit_last', '1'),
(132, 42, 'field_57c54784b3284', 'a:11:{s:3:"key";s:19:"field_57c54784b3284";s:5:"label";s:29:"Titre principale de l\'accueil";s:4:"name";s:10:"main-title";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:7:"toolbar";s:5:"basic";s:12:"media_upload";s:2:"no";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(134, 42, 'position', 'acf_after_title'),
(135, 42, 'layout', 'no_box'),
(136, 42, 'hide_on_screen', 'a:13:{i:0;s:11:"the_content";i:1;s:7:"excerpt";i:2;s:13:"custom_fields";i:3;s:10:"discussion";i:4;s:8:"comments";i:5;s:9:"revisions";i:6;s:4:"slug";i:7;s:6:"author";i:8;s:6:"format";i:9;s:14:"featured_image";i:10;s:10:"categories";i:11;s:4:"tags";i:12;s:15:"send-trackbacks";}'),
(137, 42, '_edit_lock', '1472569016:1'),
(139, 42, 'field_57c54903d0448', 'a:8:{s:3:"key";s:19:"field_57c54903d0448";s:5:"label";s:9:"Bannière";s:4:"name";s:0:"";s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}'),
(141, 42, 'field_57c547b1d0440', 'a:13:{s:3:"key";s:19:"field_57c547b1d0440";s:5:"label";s:7:"Étapes";s:4:"name";s:11:"banner_step";s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:10:"sub_fields";a:2:{i:0;a:15:{s:3:"key";s:19:"field_57c547d9d0441";s:5:"label";s:5:"Titre";s:4:"name";s:5:"title";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:12:"column_width";s:0:"";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}i:1;a:12:{s:3:"key";s:19:"field_57c54806d0442";s:5:"label";s:5:"Image";s:4:"name";s:5:"image";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:12:"column_width";s:0:"";s:11:"save_format";s:6:"object";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}}s:7:"row_min";s:1:"2";s:9:"row_limit";s:1:"4";s:6:"layout";s:3:"row";s:12:"button_label";s:18:"Ajouter une étape";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:2;}'),
(142, 42, 'field_57c548e3d0447', 'a:8:{s:3:"key";s:19:"field_57c548e3d0447";s:5:"label";s:14:"Démonstration";s:4:"name";s:0:"";s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:3;}'),
(143, 42, 'field_57c54933d044a', 'a:14:{s:3:"key";s:19:"field_57c54933d044a";s:5:"label";s:5:"Titre";s:4:"name";s:10:"demo_title";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:4;}') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(144, 42, 'field_57c54861d0443', 'a:10:{s:3:"key";s:19:"field_57c54861d0443";s:5:"label";s:26:"Carousel de démonstration";s:4:"name";s:11:"demo_slider";s:4:"type";s:7:"gallery";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:5;}'),
(149, 42, 'field_57c549f2d0450', 'a:8:{s:3:"key";s:19:"field_57c549f2d0450";s:5:"label";s:11:"Les étapes";s:4:"name";s:0:"";s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:6;}'),
(150, 42, 'field_57c54a10d0451', 'a:13:{s:3:"key";s:19:"field_57c54a10d0451";s:5:"label";s:5:"Items";s:4:"name";s:10:"step_items";s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:10:"sub_fields";a:3:{i:0;a:12:{s:3:"key";s:19:"field_57c54a2fd0452";s:5:"label";s:5:"Image";s:4:"name";s:5:"image";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:12:"column_width";s:0:"";s:11:"save_format";s:6:"object";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}i:1;a:15:{s:3:"key";s:19:"field_57c54a3bd0453";s:5:"label";s:5:"Titre";s:4:"name";s:5:"title";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:12:"column_width";s:0:"";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}i:2;a:15:{s:3:"key";s:19:"field_57c54a4ed0454";s:5:"label";s:5:"Texte";s:4:"name";s:5:"texte";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:12:"column_width";s:0:"";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:2;}}s:7:"row_min";s:1:"2";s:9:"row_limit";s:1:"4";s:6:"layout";s:3:"row";s:12:"button_label";s:18:"Ajouter une étape";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:7;}'),
(151, 42, 'field_57c54ab2d0456', 'a:8:{s:3:"key";s:19:"field_57c54ab2d0456";s:5:"label";s:4:"Aide";s:4:"name";s:0:"";s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:8;}'),
(152, 42, 'field_57c54ac6d0457', 'a:10:{s:3:"key";s:19:"field_57c54ac6d0457";s:5:"label";s:8:"Mosaique";s:4:"name";s:11:"help_mosaic";s:4:"type";s:7:"gallery";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:9;}'),
(153, 42, 'field_57c54ae7d0458', 'a:8:{s:3:"key";s:19:"field_57c54ae7d0458";s:5:"label";s:8:"Pourquoi";s:4:"name";s:0:"";s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:10;}'),
(154, 42, 'field_57c54af7d0459', 'a:13:{s:3:"key";s:19:"field_57c54af7d0459";s:5:"label";s:11:"Arguments 1";s:4:"name";s:5:"arg-1";s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:10:"sub_fields";a:1:{i:0;a:15:{s:3:"key";s:19:"field_57c54b07d045a";s:5:"label";s:4:"Item";s:4:"name";s:4:"item";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:12:"column_width";s:0:"";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}}s:7:"row_min";s:1:"2";s:9:"row_limit";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:19:"Ajouter un argument";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:11;}'),
(155, 42, 'field_57c54b1fd045b', 'a:13:{s:3:"key";s:19:"field_57c54b1fd045b";s:5:"label";s:11:"Arguments 2";s:4:"name";s:5:"arg-2";s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:10:"sub_fields";a:1:{i:0;a:15:{s:3:"key";s:19:"field_57c54b1fd045c";s:5:"label";s:4:"Item";s:4:"name";s:4:"item";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:12:"column_width";s:0:"";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}}s:7:"row_min";s:1:"2";s:9:"row_limit";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:19:"Ajouter un argument";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:12;}'),
(157, 43, '_wp_attached_file', '2016/08/constructeurs.png'),
(158, 43, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:122;s:6:"height";i:93;s:4:"file";s:25:"2016/08/constructeurs.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(159, 44, '_wp_attached_file', '2016/08/decoration.png'),
(160, 44, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:122;s:6:"height";i:93;s:4:"file";s:22:"2016/08/decoration.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(161, 45, '_wp_attached_file', '2016/08/architecture.png'),
(162, 45, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:122;s:6:"height";i:93;s:4:"file";s:24:"2016/08/architecture.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(163, 46, '_wp_attached_file', '2016/08/aide-vente.png'),
(164, 46, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:122;s:6:"height";i:93;s:4:"file";s:22:"2016/08/aide-vente.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(165, 47, '_wp_attached_file', '2016/08/immobilier.png'),
(166, 47, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:122;s:6:"height";i:93;s:4:"file";s:22:"2016/08/immobilier.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(167, 48, '_wp_attached_file', '2016/08/renovation.png'),
(168, 48, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:122;s:6:"height";i:93;s:4:"file";s:22:"2016/08/renovation.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(169, 49, '_wp_attached_file', '2016/08/tablet-sprite.png'),
(170, 49, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:244;s:6:"height";i:299;s:4:"file";s:25:"2016/08/tablet-sprite.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"tablet-sprite-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(171, 50, '_wp_attached_file', '2016/08/003.jpg'),
(172, 50, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:962;s:6:"height";i:560;s:4:"file";s:15:"2016/08/003.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:15:"003-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:15:"003-300x175.jpg";s:5:"width";i:300;s:6:"height";i:175;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:15:"003-768x447.jpg";s:5:"width";i:768;s:6:"height";i:447;s:9:"mime-type";s:10:"image/jpeg";}s:7:"gallery";a:4:{s:4:"file";s:15:"003-350x350.jpg";s:5:"width";i:350;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(173, 51, '_wp_attached_file', '2016/08/002.jpg'),
(174, 51, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:962;s:6:"height";i:560;s:4:"file";s:15:"2016/08/002.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:15:"002-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:15:"002-300x175.jpg";s:5:"width";i:300;s:6:"height";i:175;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:15:"002-768x447.jpg";s:5:"width";i:768;s:6:"height";i:447;s:9:"mime-type";s:10:"image/jpeg";}s:7:"gallery";a:4:{s:4:"file";s:15:"002-350x350.jpg";s:5:"width";i:350;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(175, 52, '_wp_attached_file', '2016/08/005.jpg'),
(176, 52, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:962;s:6:"height";i:560;s:4:"file";s:15:"2016/08/005.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:15:"005-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:15:"005-300x175.jpg";s:5:"width";i:300;s:6:"height";i:175;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:15:"005-768x447.jpg";s:5:"width";i:768;s:6:"height";i:447;s:9:"mime-type";s:10:"image/jpeg";}s:7:"gallery";a:4:{s:4:"file";s:15:"005-350x350.jpg";s:5:"width";i:350;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(177, 53, '_wp_attached_file', '2016/08/001.jpg'),
(178, 53, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:962;s:6:"height";i:560;s:4:"file";s:15:"2016/08/001.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:15:"001-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:15:"001-300x175.jpg";s:5:"width";i:300;s:6:"height";i:175;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:15:"001-768x447.jpg";s:5:"width";i:768;s:6:"height";i:447;s:9:"mime-type";s:10:"image/jpeg";}s:7:"gallery";a:4:{s:4:"file";s:15:"001-350x350.jpg";s:5:"width";i:350;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(179, 54, '_wp_attached_file', '2016/08/004.jpg'),
(180, 54, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:962;s:6:"height";i:560;s:4:"file";s:15:"2016/08/004.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:15:"004-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:15:"004-300x175.jpg";s:5:"width";i:300;s:6:"height";i:175;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:15:"004-768x447.jpg";s:5:"width";i:768;s:6:"height";i:447;s:9:"mime-type";s:10:"image/jpeg";}s:7:"gallery";a:4:{s:4:"file";s:15:"004-350x350.jpg";s:5:"width";i:350;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(181, 55, '_wp_attached_file', '2016/08/timing-19-min.png'),
(182, 55, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:305;s:6:"height";i:256;s:4:"file";s:25:"2016/08/timing-19-min.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"timing-19-min-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:25:"timing-19-min-300x252.png";s:5:"width";i:300;s:6:"height";i:252;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(183, 56, '_wp_attached_file', '2016/08/timing-18-min.png'),
(184, 56, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:295;s:6:"height";i:251;s:4:"file";s:25:"2016/08/timing-18-min.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"timing-18-min-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(185, 57, '_wp_attached_file', '2016/08/timing-06-min.png'),
(186, 57, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:295;s:6:"height";i:251;s:4:"file";s:25:"2016/08/timing-06-min.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"timing-06-min-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(187, 58, '_wp_attached_file', '2016/08/help-04.jpg'),
(188, 58, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:320;s:6:"height";i:186;s:4:"file";s:19:"2016/08/help-04.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"help-04-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"help-04-300x174.jpg";s:5:"width";i:300;s:6:"height";i:174;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(189, 59, '_wp_attached_file', '2016/08/help-03.jpg'),
(190, 59, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:320;s:6:"height";i:186;s:4:"file";s:19:"2016/08/help-03.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"help-03-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"help-03-300x174.jpg";s:5:"width";i:300;s:6:"height";i:174;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(191, 60, '_wp_attached_file', '2016/08/help-02.jpg'),
(192, 60, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:320;s:6:"height";i:186;s:4:"file";s:19:"2016/08/help-02.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"help-02-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"help-02-300x174.jpg";s:5:"width";i:300;s:6:"height";i:174;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(193, 61, '_wp_attached_file', '2016/08/help-01.jpg'),
(194, 61, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:320;s:6:"height";i:186;s:4:"file";s:19:"2016/08/help-01.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"help-01-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"help-01-300x174.jpg";s:5:"width";i:300;s:6:"height";i:174;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(195, 62, '_wp_attached_file', '2016/08/step-photo-3d.png'),
(196, 62, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:223;s:6:"height";i:158;s:4:"file";s:25:"2016/08/step-photo-3d.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"step-photo-3d-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(197, 63, '_wp_attached_file', '2016/08/step-design.png'),
(198, 63, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:210;s:6:"height";i:157;s:4:"file";s:23:"2016/08/step-design.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"step-design-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(199, 64, '_wp_attached_file', '2016/08/step-floorplan.png'),
(200, 64, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:172;s:6:"height";i:156;s:4:"file";s:26:"2016/08/step-floorplan.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"step-floorplan-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(280, 5, '_main-title', 'field_57c54784b3284'),
(282, 5, '_banner_title', 'field_57c54911d0449'),
(284, 5, '_banner_step_0_title', 'field_57c547d9d0441'),
(286, 5, '_banner_step_0_image', 'field_57c54806d0442'),
(288, 5, '_banner_step_1_title', 'field_57c547d9d0441'),
(290, 5, '_banner_step_1_image', 'field_57c54806d0442'),
(292, 5, '_banner_step_2_title', 'field_57c547d9d0441'),
(294, 5, '_banner_step_2_image', 'field_57c54806d0442'),
(296, 5, '_banner_step', 'field_57c547b1d0440'),
(298, 5, '_demo_title', 'field_57c54933d044a'),
(300, 5, '_demo_slider', 'field_57c54861d0443'),
(302, 5, '_secteurs_title', 'field_57c548aed0445'),
(304, 5, '_secterus_txt', 'field_57c54953d044b'),
(306, 5, '_secteurs_items_0_image', 'field_57c549a0d044d'),
(308, 5, '_secteurs_items_0_title', 'field_57c549b7d044e'),
(310, 5, '_secteurs_items_0_lien', 'field_57c54a63d0455'),
(312, 5, '_secteurs_items', 'field_57c54978d044c'),
(314, 5, '_step_items_0_image', 'field_57c54a2fd0452'),
(316, 5, '_step_items_0_title', 'field_57c54a3bd0453'),
(318, 5, '_step_items_0_texte', 'field_57c54a4ed0454'),
(320, 5, '_step_items_1_image', 'field_57c54a2fd0452'),
(322, 5, '_step_items_1_title', 'field_57c54a3bd0453'),
(324, 5, '_step_items_1_texte', 'field_57c54a4ed0454'),
(326, 5, '_step_items_2_image', 'field_57c54a2fd0452'),
(328, 5, '_step_items_2_title', 'field_57c54a3bd0453'),
(330, 5, '_step_items_2_texte', 'field_57c54a4ed0454'),
(332, 5, '_step_items', 'field_57c54a10d0451'),
(334, 5, '_help_mosaic', 'field_57c54ac6d0457'),
(336, 5, '_arg-1_0_item', 'field_57c54b07d045a'),
(338, 5, '_arg-1_1_item', 'field_57c54b07d045a'),
(340, 5, '_arg-1_2_item', 'field_57c54b07d045a'),
(342, 5, '_arg-1_3_item', 'field_57c54b07d045a'),
(344, 5, '_arg-1_4_item', 'field_57c54b07d045a'),
(346, 5, '_arg-1', 'field_57c54af7d0459'),
(348, 5, '_arg-2_0_item', 'field_57c54b1fd045c'),
(350, 5, '_arg-2_1_item', 'field_57c54b1fd045c'),
(352, 5, '_arg-2_2_item', 'field_57c54b1fd045c'),
(354, 5, '_arg-2_3_item', 'field_57c54b1fd045c'),
(356, 5, '_arg-2', 'field_57c54b1fd045b'),
(384, 73, '_edit_last', '1'),
(385, 73, 'field_57c559f1329a2', 'a:11:{s:3:"key";s:19:"field_57c559f1329a2";s:5:"label";s:5:"Image";s:4:"name";s:11:"secteur_img";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:11:"save_format";s:6:"object";s:12:"preview_size";s:5:"large";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(387, 73, 'position', 'acf_after_title'),
(388, 73, 'layout', 'no_box'),
(389, 73, 'hide_on_screen', ''),
(390, 73, '_edit_lock', '1472568998:1'),
(392, 74, '_wp_attached_file', '2016/08/software-architecture.jpg'),
(393, 74, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:640;s:6:"height";i:360;s:4:"file";s:33:"2016/08/software-architecture.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:33:"software-architecture-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:33:"software-architecture-300x169.jpg";s:5:"width";i:300;s:6:"height";i:169;s:9:"mime-type";s:10:"image/jpeg";}s:7:"gallery";a:4:{s:4:"file";s:33:"software-architecture-350x350.jpg";s:5:"width";i:350;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(394, 75, '_wp_attached_file', '2016/08/software-decoration.jpg') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(395, 75, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:640;s:6:"height";i:360;s:4:"file";s:31:"2016/08/software-decoration.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"software-decoration-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:31:"software-decoration-300x169.jpg";s:5:"width";i:300;s:6:"height";i:169;s:9:"mime-type";s:10:"image/jpeg";}s:7:"gallery";a:4:{s:4:"file";s:31:"software-decoration-350x350.jpg";s:5:"width";i:350;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(396, 76, '_wp_attached_file', '2016/08/software-renovation.jpg'),
(397, 76, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:640;s:6:"height";i:360;s:4:"file";s:31:"2016/08/software-renovation.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"software-renovation-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:31:"software-renovation-300x169.jpg";s:5:"width";i:300;s:6:"height";i:169;s:9:"mime-type";s:10:"image/jpeg";}s:7:"gallery";a:4:{s:4:"file";s:31:"software-renovation-350x350.jpg";s:5:"width";i:350;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(398, 77, '_wp_attached_file', '2016/08/software-builder.jpg'),
(399, 77, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:640;s:6:"height";i:360;s:4:"file";s:28:"2016/08/software-builder.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"software-builder-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"software-builder-300x169.jpg";s:5:"width";i:300;s:6:"height";i:169;s:9:"mime-type";s:10:"image/jpeg";}s:7:"gallery";a:4:{s:4:"file";s:28:"software-builder-350x350.jpg";s:5:"width";i:350;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(402, 73, 'field_57c55c7aca0ee', 'a:14:{s:3:"key";s:19:"field_57c55c7aca0ee";s:5:"label";s:8:"Soutitre";s:4:"name";s:8:"subtitle";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}'),
(420, 73, 'rule', 'a:5:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:26:"templates/page-secteur.php";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(456, 94, '_edit_last', '1'),
(457, 94, 'field_57c59061cc476', 'a:14:{s:3:"key";s:19:"field_57c59061cc476";s:5:"label";s:15:"url de l\'iframe";s:4:"name";s:10:"iframe_url";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"none";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(459, 94, 'position', 'acf_after_title'),
(460, 94, 'layout', 'no_box'),
(461, 94, 'hide_on_screen', 'a:14:{i:0;s:9:"permalink";i:1;s:11:"the_content";i:2;s:7:"excerpt";i:3;s:13:"custom_fields";i:4;s:10:"discussion";i:5;s:8:"comments";i:6;s:9:"revisions";i:7;s:4:"slug";i:8;s:6:"author";i:9;s:6:"format";i:10;s:14:"featured_image";i:11;s:10:"categories";i:12;s:4:"tags";i:13;s:15:"send-trackbacks";}'),
(462, 94, '_edit_lock', '1472564959:1'),
(463, 94, 'rule', 'a:5:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:25:"templates/page-iframe.php";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(464, 7, 'iframe_url', 'http://v3.mysketcher.com/?token=e9d92bc8ef927f14752f095956805a1029981171&locale=fr&project='),
(465, 7, '_iframe_url', 'field_57c59061cc476'),
(468, 96, '_edit_last', '1'),
(469, 96, 'field_57c592c28fafe', 'a:13:{s:3:"key";s:19:"field_57c592c28fafe";s:5:"label";s:9:"Tutoriels";s:4:"name";s:9:"tutoriels";s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:10:"sub_fields";a:2:{i:0;a:15:{s:3:"key";s:19:"field_57c592e78faff";s:5:"label";s:5:"Titre";s:4:"name";s:5:"title";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:12:"column_width";s:0:"";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}i:1;a:12:{s:3:"key";s:19:"field_57c592f48fb00";s:5:"label";s:7:"Contenu";s:4:"name";s:7:"contenu";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:12:"column_width";s:0:"";s:13:"default_value";s:0:"";s:7:"toolbar";s:4:"full";s:12:"media_upload";s:2:"no";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}}s:7:"row_min";s:0:"";s:9:"row_limit";s:0:"";s:6:"layout";s:3:"row";s:12:"button_label";s:19:"Ajouter un tutoriel";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(471, 96, 'position', 'normal'),
(472, 96, 'layout', 'no_box'),
(473, 96, 'hide_on_screen', 'a:13:{i:0;s:9:"permalink";i:1;s:7:"excerpt";i:2;s:13:"custom_fields";i:3;s:10:"discussion";i:4;s:8:"comments";i:5;s:9:"revisions";i:6;s:4:"slug";i:7;s:6:"author";i:8;s:6:"format";i:9;s:14:"featured_image";i:10;s:10:"categories";i:11;s:4:"tags";i:12;s:15:"send-trackbacks";}'),
(474, 96, '_edit_lock', '1472568630:1'),
(477, 11, '_oembed_02ad27c4e309c77a6b57edd651b2cb92', '<blockquote class="embedly-card" data-card-controls="1" data-card-align="center" data-card-chrome="0" data-card-theme="light" data-card-key="780cdfd4839d4fdd8a0eac97c7d639f7"><h4><a href="http://bunkrapp.com/present/bdkbza/?utm_medium=share#1">Copy - Premiers pas avec My Sketcher</a></h4><p>Mickaël Keromnes (mkbaa) created this presentation on Wednesday, June 17, 2015 at 2:15:57 PM GMT+00:00</p></blockquote><script async src="//cdn.embedly.com/widgets/platform.js" charset="UTF-8"></script>'),
(478, 11, '_oembed_time_02ad27c4e309c77a6b57edd651b2cb92', '1472566271'),
(485, 11, 'tutoriels_0_title', 'Premier Pas avec My Sketcher'),
(486, 11, '_tutoriels_0_title', 'field_57c592e78faff'),
(487, 11, 'tutoriels_0_contenu', '<iframe src="http://bunkrapp.com/present/bdkbza/embed/" width="512" height="352" frameborder="0" scrolling="no" allowfullscreen="allowfullscreen"></iframe>'),
(488, 11, '_tutoriels_0_contenu', 'field_57c592f48fb00'),
(489, 11, 'tutoriels', '1'),
(490, 11, '_tutoriels', 'field_57c592c28fafe'),
(491, 96, 'rule', 'a:5:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:28:"templates/page-tutoriels.php";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(504, 42, 'rule', 'a:5:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:26:"templates/page-accueil.php";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(545, 101, '_edit_last', '3'),
(610, 101, '_main-title', 'field_57c54784b3284'),
(611, 101, '_banner_step_0_title', 'field_57c547d9d0441'),
(612, 101, '_banner_step_0_image', 'field_57c54806d0442'),
(613, 101, '_banner_step_1_title', 'field_57c547d9d0441'),
(614, 101, '_banner_step_1_image', 'field_57c54806d0442'),
(615, 101, '_banner_step_2_title', 'field_57c547d9d0441'),
(616, 101, '_banner_step_2_image', 'field_57c54806d0442'),
(617, 101, '_banner_step', 'field_57c547b1d0440'),
(618, 101, '_demo_title', 'field_57c54933d044a'),
(619, 101, '_demo_slider', 'field_57c54861d0443'),
(620, 101, '_step_items_0_image', 'field_57c54a2fd0452'),
(621, 101, '_step_items_0_title', 'field_57c54a3bd0453'),
(622, 101, '_step_items_0_texte', 'field_57c54a4ed0454'),
(623, 101, '_step_items_1_image', 'field_57c54a2fd0452'),
(624, 101, '_step_items_1_title', 'field_57c54a3bd0453'),
(625, 101, '_step_items_1_texte', 'field_57c54a4ed0454'),
(626, 101, '_step_items_2_image', 'field_57c54a2fd0452'),
(627, 101, '_step_items_2_title', 'field_57c54a3bd0453'),
(628, 101, '_step_items_2_texte', 'field_57c54a4ed0454'),
(629, 101, '_step_items', 'field_57c54a10d0451'),
(630, 101, '_help_mosaic', 'field_57c54ac6d0457'),
(631, 101, '_arg-1_0_item', 'field_57c54b07d045a'),
(632, 101, '_arg-1_1_item', 'field_57c54b07d045a'),
(633, 101, '_arg-1_2_item', 'field_57c54b07d045a'),
(634, 101, '_arg-1_3_item', 'field_57c54b07d045a'),
(635, 101, '_arg-1_4_item', 'field_57c54b07d045a'),
(636, 101, '_arg-1', 'field_57c54af7d0459'),
(637, 101, '_arg-2_0_item', 'field_57c54b1fd045c'),
(638, 101, '_arg-2_1_item', 'field_57c54b1fd045c'),
(639, 101, '_arg-2_2_item', 'field_57c54b1fd045c'),
(640, 101, '_arg-2_3_item', 'field_57c54b1fd045c'),
(641, 101, '_arg-2', 'field_57c54b1fd045b'),
(643, 101, '_edit_lock', '1474358603:3'),
(645, 103, '_edit_lock', '1474358473:3'),
(646, 103, '_edit_last', '3'),
(648, 105, '_wp_page_template', 'default'),
(649, 105, '_edit_last', '3'),
(651, 105, '_edit_lock', '1474358857:3'),
(652, 107, '_menu_item_type', 'post_type'),
(653, 107, '_menu_item_menu_item_parent', '0'),
(654, 107, '_menu_item_object_id', '105'),
(655, 107, '_menu_item_object', 'page'),
(656, 107, '_menu_item_target', ''),
(657, 107, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(658, 107, '_menu_item_xfn', ''),
(659, 107, '_menu_item_url', ''),
(661, 108, '_menu_item_type', 'post_type'),
(662, 108, '_menu_item_menu_item_parent', '0'),
(663, 108, '_menu_item_object_id', '103'),
(664, 108, '_menu_item_object', 'page'),
(665, 108, '_menu_item_target', ''),
(666, 108, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(667, 108, '_menu_item_xfn', ''),
(668, 108, '_menu_item_url', ''),
(670, 109, '_menu_item_type', 'post_type'),
(671, 109, '_menu_item_menu_item_parent', '0'),
(672, 109, '_menu_item_object_id', '101'),
(673, 109, '_menu_item_object', 'page'),
(674, 109, '_menu_item_target', ''),
(675, 109, '_menu_item_classes', 'a:1:{i:0;s:9:"link-home";}'),
(676, 109, '_menu_item_xfn', ''),
(677, 109, '_menu_item_url', ''),
(679, 110, '_menu_item_type', 'custom'),
(680, 110, '_menu_item_menu_item_parent', '0'),
(681, 110, '_menu_item_object_id', '110'),
(682, 110, '_menu_item_object', 'custom'),
(683, 110, '_menu_item_target', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(684, 110, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(685, 110, '_menu_item_xfn', ''),
(686, 110, '_menu_item_url', '#pll_switcher'),
(688, 110, '_pll_menu_item', 'a:6:{s:22:"hide_if_no_translation";i:0;s:12:"hide_current";i:1;s:10:"force_home";i:0;s:10:"show_flags";i:1;s:10:"show_names";i:1;s:8:"dropdown";i:0;}'),
(689, 111, '_form_id', '1'),
(690, 111, '_seq_num', '1'),
(691, 111, '_action', 'submit'),
(692, 111, '_field_1', 'test'),
(693, 111, '_field_2', 'wab2com@gmail.com'),
(694, 111, '_field_3', 'test'),
(695, 111, '_field_4', ''),
(696, 111, '_sub_id', '111'),
(697, 112, '_form_id', '1'),
(698, 112, '_seq_num', '2'),
(699, 112, '_action', 'submit'),
(700, 112, '_field_1', 'test again'),
(701, 112, '_field_2', 'wab2com@gmail.com'),
(702, 112, '_field_3', 'test again'),
(703, 112, '_field_4', ''),
(704, 112, '_sub_id', '112'),
(705, 113, '_form_id', '1'),
(706, 113, '_seq_num', '3'),
(707, 113, '_action', 'submit'),
(708, 113, '_field_1', 'test'),
(709, 113, '_field_2', 'wab2com@gmail.com'),
(710, 113, '_field_3', 'test'),
(711, 113, '_field_4', ''),
(712, 113, '_sub_id', '113'),
(844, 127, '_edit_lock', '1474359010:3'),
(845, 127, '_edit_last', '3'),
(846, 127, '_wp_page_template', 'default'),
(847, 129, '_edit_lock', '1474358970:3'),
(848, 129, '_edit_last', '3'),
(849, 129, '_wp_page_template', 'default'),
(882, 1, '_edit_lock', '1474011310:3'),
(901, 151, '_menu_item_type', 'post_type'),
(902, 151, '_menu_item_menu_item_parent', '0'),
(903, 151, '_menu_item_object_id', '127'),
(904, 151, '_menu_item_object', 'page'),
(905, 151, '_menu_item_target', ''),
(906, 151, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(907, 151, '_menu_item_xfn', ''),
(908, 151, '_menu_item_url', ''),
(927, 154, '_menu_item_type', 'custom'),
(928, 154, '_menu_item_menu_item_parent', '0'),
(929, 154, '_menu_item_object_id', '154'),
(930, 154, '_menu_item_object', 'custom'),
(931, 154, '_menu_item_target', ''),
(932, 154, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(933, 154, '_menu_item_xfn', ''),
(934, 154, '_menu_item_url', '#pll_switcher'),
(935, 154, '_pll_menu_item', 'a:6:{s:22:"hide_if_no_translation";i:0;s:12:"hide_current";i:1;s:10:"force_home";i:0;s:10:"show_flags";i:1;s:10:"show_names";i:1;s:8:"dropdown";i:0;}'),
(937, 161, '_edit_lock', '1474358765:3'),
(938, 161, '_edit_last', '3'),
(939, 161, '_wp_page_template', 'default'),
(940, 161, '_yoast_wpseo_focuskw_text_input', 'maison 3D'),
(941, 161, '_yoast_wpseo_focuskw', 'maison 3D'),
(942, 161, '_yoast_wpseo_linkdex', '76'),
(943, 161, '_yoast_wpseo_content_score', '90'),
(954, 129, '_yoast_wpseo_focuskw_text_input', 'plan de maison'),
(955, 129, '_yoast_wpseo_focuskw', 'plan de maison'),
(956, 129, '_yoast_wpseo_linkdex', '85'),
(957, 129, '_yoast_wpseo_content_score', '90'),
(958, 127, '_yoast_wpseo_content_score', '30'),
(959, 161, '_yoast_wpseo_metadesc', 'Créez votre maison ou votre appartement en 3D, aménagez et décorez. Avec notre outil HD, visualisez instantanément votre projet comme si vous y étiez.'),
(960, 129, '_yoast_wpseo_metadesc', 'Cedreo Designer est un logiciel de création de plan de maison 3D intuitif et facile d\'utilisation. Dessinez votre plan de maison en quelques minutes.'),
(961, 180, '_edit_lock', '1474358809:3'),
(962, 180, '_edit_last', '3'),
(963, 180, '_wp_page_template', 'default'),
(964, 180, '_yoast_wpseo_focuskw_text_input', 'salle de bain en 3D'),
(965, 180, '_yoast_wpseo_focuskw', 'salle de bain en 3D'),
(966, 180, '_yoast_wpseo_linkdex', '78'),
(967, 180, '_yoast_wpseo_content_score', '90'),
(968, 180, '_yoast_wpseo_metadesc', 'Solution 3D pour visuels photoréalistes HD. Concevez votre projet de salle de bain en ligne et visitez nos bibliothèques de produits pour aménager.'),
(969, 184, '_menu_item_type', 'post_type'),
(970, 184, '_menu_item_menu_item_parent', '0'),
(971, 184, '_menu_item_object_id', '21'),
(972, 184, '_menu_item_object', 'page'),
(973, 184, '_menu_item_target', ''),
(974, 184, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(975, 184, '_menu_item_xfn', ''),
(976, 184, '_menu_item_url', ''),
(977, 184, '_menu_item_orphaned', '1474040817'),
(978, 185, '_menu_item_type', 'post_type'),
(979, 185, '_menu_item_menu_item_parent', '0'),
(980, 185, '_menu_item_object_id', '19'),
(981, 185, '_menu_item_object', 'page'),
(982, 185, '_menu_item_target', ''),
(983, 185, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(984, 185, '_menu_item_xfn', ''),
(985, 185, '_menu_item_url', ''),
(986, 185, '_menu_item_orphaned', '1474040817'),
(988, 186, '_edit_last', '3'),
(989, 186, '_yoast_wpseo_content_score', '30'),
(991, 186, '_edit_lock', '1474358618:3'),
(993, 188, '_edit_last', '3'),
(994, 188, '_yoast_wpseo_content_score', '30'),
(996, 188, '_edit_lock', '1474358394:3'),
(997, 190, '_menu_item_type', 'post_type'),
(998, 190, '_menu_item_menu_item_parent', '0') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(999, 190, '_menu_item_object_id', '186'),
(1000, 190, '_menu_item_object', 'page'),
(1001, 190, '_menu_item_target', ''),
(1002, 190, '_menu_item_classes', 'a:1:{i:0;s:10:"link-login";}'),
(1003, 190, '_menu_item_xfn', ''),
(1004, 190, '_menu_item_url', ''),
(1006, 191, '_menu_item_type', 'post_type'),
(1007, 191, '_menu_item_menu_item_parent', '0'),
(1008, 191, '_menu_item_object_id', '188'),
(1009, 191, '_menu_item_object', 'page'),
(1010, 191, '_menu_item_target', ''),
(1011, 191, '_menu_item_classes', 'a:1:{i:0;s:11:"link-signin";}'),
(1012, 191, '_menu_item_xfn', ''),
(1013, 191, '_menu_item_url', ''),
(1015, 192, '_edit_lock', '1474358787:3'),
(1016, 192, '_edit_last', '3'),
(1017, 192, '_wp_page_template', 'default'),
(1018, 192, '_yoast_wpseo_focuskw_text_input', 'cuisine 3D'),
(1019, 192, '_yoast_wpseo_focuskw', 'cuisine 3D'),
(1020, 192, '_yoast_wpseo_metadesc', 'Concevez votre plan de cuisine rapidement grâce à l\'outil de création 3D et commencez aussitôt à repenser la disposition de votre mobilier.'),
(1021, 192, '_yoast_wpseo_linkdex', '79'),
(1022, 192, '_yoast_wpseo_content_score', '90'),
(1023, 194, '_edit_lock', '1474380774:3'),
(1024, 194, '_edit_last', '3'),
(1025, 194, '_wp_page_template', 'default'),
(1026, 194, '_yoast_wpseo_focuskw_text_input', 'aménagement 3D'),
(1027, 194, '_yoast_wpseo_focuskw', 'aménagement 3D'),
(1028, 194, '_yoast_wpseo_metadesc', 'Intérieur comme extérieur, notre logiciel de maison 3D vous permet de planifier l\'aménagement de votre maison dans son intégralité.'),
(1029, 194, '_yoast_wpseo_linkdex', '79'),
(1030, 194, '_yoast_wpseo_content_score', '90'),
(1031, 196, '_edit_lock', '1474380825:3'),
(1032, 196, '_edit_last', '3'),
(1033, 196, '_wp_page_template', 'default'),
(1034, 196, '_yoast_wpseo_content_score', '90'),
(1035, 21, '_yoast_wpseo_content_score', '30'),
(1037, 21, '_yoast_wpseo_bctitle', 'Connexion'),
(1040, 37, '_yoast_wpseo_content_score', '30'),
(1041, 37, '_yoast_wpseo_meta-robots-noindex', '1'),
(1042, 37, '_yoast_wpseo_bctitle', 'Nous contacter'),
(1045, 7, '_yoast_wpseo_content_score', '30'),
(1046, 7, '_yoast_wpseo_meta-robots-noindex', '2'),
(1047, 7, '_yoast_wpseo_bctitle', 'Démo Cedreo Designer 3D'),
(1048, 19, '_yoast_wpseo_content_score', '30'),
(1050, 19, '_yoast_wpseo_bctitle', 'Inscription'),
(1051, 188, '_wp_page_template', 'default'),
(1052, 188, '_yoast_wpseo_meta-robots-noindex', '1'),
(1053, 19, '_wp_page_template', 'default'),
(1054, 19, '_yoast_wpseo_meta-robots-noindex', '1'),
(1055, 188, '_yoast_wpseo_bctitle', 'Sign up'),
(1120, 5, '_yoast_wpseo_content_score', '30'),
(1121, 5, '_yoast_wpseo_bctitle', 'Accueil'),
(1122, 101, 'main-title', 'Plans 3D, rendus intérieurs et extérieurs en haute qualité, simplement et rapidement'),
(1123, 101, 'banner_title', ''),
(1124, 101, 'banner_step_0_title', 'Dessiner votre projet'),
(1125, 101, 'banner_step_0_image', '57'),
(1126, 101, 'banner_step_1_title', 'Meubler et décorer'),
(1127, 101, 'banner_step_1_image', '56'),
(1128, 101, 'banner_step_2_title', 'Obtenez des rendus étonnants'),
(1129, 101, 'banner_step_2_image', '55'),
(1130, 101, 'banner_step', '3'),
(1131, 101, 'demo_title', 'Ces images peuvent être faites en moins de 20 minutes. Vous voulez savoir comment ?'),
(1132, 101, 'demo_slider', 'a:5:{i:0;s:2:"54";i:1;s:2:"53";i:2;s:2:"52";i:3;s:2:"51";i:4;s:2:"50";}'),
(1133, 101, 'secteurs_title', 'Facile, rapide et de haute qualité'),
(1134, 101, 'secterus_txt', 'My Sketcher est le moyen le plus facile et le meilleur de créer des modèles de maison et de plans en ligne. \r\nEn quelques clics, vous pouvez dessiner votre plan avec plus de 1000 items et matériaux et générer des rendus 3D haut de gamme.'),
(1135, 101, 'secteurs_items_0_image', ''),
(1136, 101, 'secteurs_items_0_title', ''),
(1137, 101, 'secteurs_items_0_lien', '5'),
(1138, 101, 'secteurs_items', '1'),
(1139, 101, 'step_items_0_image', '64'),
(1140, 101, 'step_items_0_title', 'Dessinez vos plans facilement et rapidement'),
(1141, 101, 'step_items_0_texte', 'Créez votre plan dans un éditeur 2D clair en intégrant des cloisonnements, des mezzanines, des pentes de toits et en ajoutant des ouvertures personnalisables.'),
(1142, 101, 'step_items_1_image', '63'),
(1143, 101, 'step_items_1_title', 'Concevez votre intérieur en quelques clics'),
(1144, 101, 'step_items_1_texte', 'Votre plan est prêt, vous pouvez le modifier avec des milliers de produits et matériaux de notre catalogue et génériques.'),
(1145, 101, 'step_items_2_image', '62'),
(1146, 101, 'step_items_2_title', 'Générez des photos 3D de haute qualité'),
(1147, 101, 'step_items_2_texte', 'Obtenez une qualité de rendu stupéfiante en moins de 1 min. Choisissez juste votre point de vue et votre environnement; nous calculons votre photo en moins de 1 min !'),
(1148, 101, 'step_items', '3'),
(1149, 101, 'help_mosaic', 'a:4:{i:0;s:2:"61";i:1;s:2:"60";i:2;s:2:"59";i:3;s:2:"58";}'),
(1150, 101, 'arg-1_0_item', 'La façon la plus facile et la plus rapide de produire des plans d\'architecte et des rendus intérieurs 3D'),
(1151, 101, 'arg-1_1_item', 'Aucune formation nécessaire'),
(1152, 101, 'arg-1_2_item', 'Pas besoin de télécharger et d\'installer quoi que ce soit'),
(1153, 101, 'arg-1_3_item', 'Options de rendu avancées pour un travail professionnel'),
(1154, 101, 'arg-1_4_item', 'Un résultat professionnel en quelques minutes'),
(1155, 101, 'arg-1', '5'),
(1156, 101, 'arg-2_0_item', 'La meilleure qualité de rendu au monde pour un logiciel de plan'),
(1157, 101, 'arg-2_1_item', '+ de 1000 articles et matériaux personnalisables de haute qualité pour personnaliser votre intérieur'),
(1158, 101, 'arg-2_2_item', 'Rendus intérieurs et extérieurs'),
(1159, 101, 'arg-2_3_item', 'Payer ce que vous utilisez'),
(1160, 101, 'arg-2', '4'),
(1161, 101, '_wp_page_template', 'templates/page-accueil.php'),
(1162, 17, '_yoast_wpseo_content_score', '30'),
(1163, 17, '_yoast_wpseo_bctitle', 'Blog'),
(1164, 103, '_wp_page_template', 'default'),
(1165, 17, '_wp_page_template', 'default'),
(1166, 103, '_yoast_wpseo_content_score', '30'),
(1167, 103, '_yoast_wpseo_bctitle', 'Blog'),
(1168, 186, '_wp_page_template', 'default'),
(1169, 186, '_yoast_wpseo_meta-robots-noindex', '1'),
(1170, 35, '_yoast_wpseo_content_score', '30') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1171, 35, '_yoast_wpseo_bctitle', 'Devenez partenaire'),
(1172, 9, '_yoast_wpseo_content_score', '30'),
(1173, 9, '_yoast_wpseo_bctitle', 'Galerie 3D idées et styles déco'),
(1174, 5, 'main-title', 'Plans 3D, rendus intérieurs et extérieurs en haute qualité, simplement et rapidement'),
(1175, 5, 'banner_title', ''),
(1176, 5, 'banner_step_0_title', 'Dessiner votre projet'),
(1177, 5, 'banner_step_0_image', '57'),
(1178, 5, 'banner_step_1_title', 'Meubler et décorer'),
(1179, 5, 'banner_step_1_image', '56'),
(1180, 5, 'banner_step_2_title', 'Obtenez des rendus étonnants'),
(1181, 5, 'banner_step_2_image', '55'),
(1182, 5, 'banner_step', '3'),
(1183, 5, 'demo_title', 'Ces images peuvent être faites en moins de 20 minutes. Vous voulez savoir comment ?'),
(1184, 5, 'demo_slider', 'a:5:{i:0;s:2:"54";i:1;s:2:"53";i:2;s:2:"52";i:3;s:2:"51";i:4;s:2:"50";}'),
(1185, 5, 'secteurs_title', 'Facile, rapide et de haute qualité'),
(1186, 5, 'secterus_txt', 'My Sketcher est le moyen le plus facile et le meilleur de créer des modèles de maison et de plans en ligne. \r\nEn quelques clics, vous pouvez dessiner votre plan avec plus de 1000 items et matériaux et générer des rendus 3D haut de gamme.'),
(1187, 5, 'secteurs_items_0_image', ''),
(1188, 5, 'secteurs_items_0_title', ''),
(1189, 5, 'secteurs_items_0_lien', '5'),
(1190, 5, 'secteurs_items', '1'),
(1191, 5, 'step_items_0_image', '64'),
(1192, 5, 'step_items_0_title', 'Dessinez vos plans facilement et rapidement'),
(1193, 5, 'step_items_0_texte', 'Créez votre plan dans un éditeur 2D clair en intégrant des cloisonnements, des mezzanines, des pentes de toits et en ajoutant des ouvertures personnalisables.'),
(1194, 5, 'step_items_1_image', '63'),
(1195, 5, 'step_items_1_title', 'Concevez votre intérieur en quelques clics'),
(1196, 5, 'step_items_1_texte', 'Votre plan est prêt, vous pouvez le modifier avec des milliers de produits et matériaux de notre catalogue et génériques.'),
(1197, 5, 'step_items_2_image', '62'),
(1198, 5, 'step_items_2_title', 'Générez des photos 3D de haute qualité'),
(1199, 5, 'step_items_2_texte', 'Obtenez une qualité de rendu stupéfiante en moins de 1 min. Choisissez juste votre point de vue et votre environnement; nous calculons votre photo en moins de 1 min !'),
(1200, 5, 'step_items', '3'),
(1201, 5, 'help_mosaic', 'a:4:{i:0;s:2:"61";i:1;s:2:"60";i:2;s:2:"59";i:3;s:2:"58";}'),
(1202, 5, 'arg-1_0_item', 'La façon la plus facile et la plus rapide de produire des plans d\'architecte et des rendus intérieurs 3D'),
(1203, 5, 'arg-1_1_item', 'Aucune formation nécessaire'),
(1204, 5, 'arg-1_2_item', 'Pas besoin de télécharger et d\'installer quoi que ce soit'),
(1205, 5, 'arg-1_3_item', 'Options de rendu avancées pour un travail professionnel'),
(1206, 5, 'arg-1_4_item', 'Un résultat professionnel en quelques minutes'),
(1207, 5, 'arg-1', '5'),
(1208, 5, 'arg-2_0_item', 'La meilleure qualité de rendu au monde pour un logiciel de plan'),
(1209, 5, 'arg-2_1_item', '+ de 1000 articles et matériaux personnalisables de haute qualité pour personnaliser votre intérieur'),
(1210, 5, 'arg-2_2_item', 'Rendus intérieurs et extérieurs'),
(1211, 5, 'arg-2_3_item', 'Payer ce que vous utilisez'),
(1212, 5, 'arg-2', '4'),
(1213, 5, '_wp_page_template', 'templates/page-accueil.php'),
(1214, 101, '_yoast_wpseo_content_score', '30'),
(1215, 101, '_yoast_wpseo_bctitle', 'Home'),
(1216, 21, '_wp_page_template', 'default'),
(1217, 21, '_yoast_wpseo_meta-robots-noindex', '1'),
(1218, 186, '_yoast_wpseo_bctitle', 'Log in'),
(1219, 127, '_yoast_wpseo_bctitle', 'Mon besoin'),
(1220, 194, '_yoast_wpseo_bctitle', 'Aménager et agencer son logement en 3D'),
(1221, 196, '_yoast_wpseo_bctitle', 'Aménagement extérieur'),
(1222, 161, '_yoast_wpseo_bctitle', 'Créer sa maison en 3D'),
(1223, 192, '_yoast_wpseo_bctitle', 'Créer sa cuisine en 3D'),
(1224, 180, '_yoast_wpseo_bctitle', 'Créer sa salle de bain en 3D'),
(1225, 129, '_yoast_wpseo_bctitle', 'Créer un plan de maison'),
(1226, 15, '_wp_page_template', 'default'),
(1227, 105, '_yoast_wpseo_content_score', '30'),
(1228, 105, '_yoast_wpseo_bctitle', 'Price'),
(1229, 196, '_yoast_wpseo_focuskw_text_input', 'aménagement extérieur'),
(1230, 196, '_yoast_wpseo_focuskw', 'aménagement extérieur'),
(1231, 196, '_yoast_wpseo_linkdex', '81'),
(1232, 196, '_yoast_wpseo_metadesc', 'Planifiez l\'aménagement 3D de vos extérieurs avec autant de soin que la décoration intérieure. Idéal pour la conception de jardin paysager et charpente.'),
(1233, 213, '_edit_lock', '1474382615:3'),
(1234, 213, '_edit_last', '3'),
(1235, 213, '_wp_page_template', 'default'),
(1236, 213, '_yoast_wpseo_focuskw_text_input', 'aménagement intérieur'),
(1237, 213, '_yoast_wpseo_content_score', '90'),
(1238, 213, '_yoast_wpseo_focuskw', 'aménagement intérieur'),
(1239, 213, '_yoast_wpseo_metadesc', 'Aménagez votre logement 3D avec Cedreo Designer. Grâce à notre catalogue riche et personnalisable, l\'agencement de vos équipements devient un jeu d\'enfant.'),
(1240, 213, '_yoast_wpseo_linkdex', '82'),
(1246, 224, '_edit_lock', '1474471272:3'),
(1247, 224, '_edit_last', '3'),
(1248, 224, '_wp_page_template', 'default'),
(1249, 224, '_yoast_wpseo_focuskw_text_input', 'décoration intérieur'),
(1250, 224, '_yoast_wpseo_focuskw', 'décoration intérieur'),
(1251, 224, '_yoast_wpseo_linkdex', '76'),
(1252, 224, '_yoast_wpseo_content_score', '90'),
(1253, 234, '_edit_lock', '1474529641:3'),
(1254, 234, '_edit_last', '3'),
(1255, 234, '_wp_page_template', 'default'),
(1256, 234, '_yoast_wpseo_content_score', '30'),
(1257, 234, '_yoast_wpseo_focuskw_text_input', 'home staging'),
(1258, 234, '_yoast_wpseo_focuskw', 'home staging'),
(1259, 234, '_yoast_wpseo_linkdex', '58'),
(1260, 243, '_edit_lock', '1474491379:1'),
(1261, 243, '_edit_last', '1'),
(1262, 243, 'field_57e2f3ff8c173', 'a:10:{s:3:"key";s:19:"field_57e2f3ff8c173";s:5:"label";s:7:"Galerie";s:4:"name";s:7:"gallery";s:4:"type";s:7:"gallery";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:12:"preview_size";s:7:"gallery";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(1264, 243, 'position', 'acf_after_title'),
(1265, 243, 'layout', 'no_box'),
(1266, 243, 'hide_on_screen', ''),
(1268, 9, 'gallery', 'a:8:{i:0;s:2:"77";i:1;s:2:"76";i:2;s:2:"75";i:3;s:2:"74";i:4;s:2:"61";i:5;s:2:"60";i:6;s:2:"59";i:7;s:2:"58";}'),
(1269, 9, '_gallery', 'field_57e2f3ff8c173'),
(1270, 243, 'rule', 'a:5:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:26:"templates/page-galerie.php";s:8:"order_no";i:0;s:8:"group_no";i:0;}') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=244 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2016-08-22 22:08:37', '2016-08-22 20:08:37', 'Bienvenue dans WordPress. Ceci est votre premier article. Modifiez-le ou supprimez-le, puis lancez-vous&nbsp;!', 'Bonjour tout le monde&nbsp;!', '', 'publish', 'open', 'open', '', 'bonjour-tout-le-monde', '', '', '2016-08-22 22:08:37', '2016-08-22 20:08:37', '', 0, 'http://cedreo-designer.com.dev/?p=1', 0, 'post', '', 1),
(5, 1, '2016-09-13 23:35:29', '2016-09-13 21:35:29', '', 'Accueil', '', 'publish', 'closed', 'closed', '', 'accueil', '', '', '2016-09-20 10:02:44', '2016-09-20 08:02:44', '', 0, 'http://cedreo-designer.com.dev/?page_id=5', 0, 'page', '', 0),
(7, 1, '2016-08-22 23:38:39', '2016-08-22 21:38:39', '', 'Démo', '', 'publish', 'closed', 'closed', '', 'demo', '', '', '2016-09-20 10:00:28', '2016-09-20 08:00:28', '', 0, 'http://cedreo-designer.com.dev/?page_id=7', 0, 'page', '', 0),
(9, 1, '2016-08-22 23:38:57', '2016-08-22 21:38:57', '', 'Galerie', '', 'publish', 'closed', 'closed', '', 'galerie', '', '', '2016-09-21 22:59:01', '2016-09-21 20:59:01', '', 0, 'http://cedreo-designer.com.dev/?page_id=9', 0, 'page', '', 0),
(11, 1, '2016-08-22 23:39:10', '2016-08-22 21:39:10', '<h2>Bienvenue sur votre espace tutoriels !</h2>\r\nRetrouvez ici des astuces et bonnes pratiques pour créer votre projet étape par étape sur My Sketcher\r\n<h2>Comment ca marche ?</h2>\r\nSur votre droite retrouvez le menu des tutos déjà disponibles : cliquez, puis faites défiler les slides à l’aide de la flèche blanche à droite du visuel.\r\n\r\nCet espace est le votre, aussi n’hésitez pas à nous contacter pour l’adapter à votre besoin !', 'Tutoriels', '', 'publish', 'closed', 'closed', '', 'tutoriels', '', '', '2016-08-30 16:26:05', '2016-08-30 14:26:05', '', 0, 'http://cedreo-designer.com.dev/?page_id=11', 0, 'page', '', 0),
(15, 1, '2016-09-13 23:39:26', '2016-09-13 21:39:26', '', 'Tarifs', '', 'publish', 'closed', 'closed', '', 'tarifs', '', '', '2016-08-22 23:39:36', '2016-08-22 21:39:36', '', 0, 'http://cedreo-designer.com.dev/?page_id=15', 0, 'page', '', 0),
(17, 1, '2016-09-13 23:39:07', '2016-09-13 21:39:07', '', 'Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2016-09-20 10:03:17', '2016-09-20 08:03:17', '', 0, 'http://cedreo-designer.com.dev/?page_id=17', 0, 'page', '', 0),
(19, 1, '2016-09-16 17:48:26', '2016-09-16 15:48:26', '', 'S\'inscrire', '', 'publish', 'closed', 'closed', '', 'sinscrire', '', '', '2016-09-20 10:01:58', '2016-09-20 08:01:58', '', 0, 'http://cedreo-designer.com.dev/?page_id=19', 0, 'page', '', 0),
(21, 1, '2016-09-16 17:47:56', '2016-09-16 15:47:56', '', 'Connexion', '', 'publish', 'closed', 'closed', '', 'connexion', '', '', '2016-09-20 10:03:50', '2016-09-20 08:03:50', '', 0, 'http://cedreo-designer.com.dev/?page_id=21', 0, 'page', '', 0),
(23, 1, '2016-08-22 23:40:13', '0000-00-00 00:00:00', '', 'Accueil', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-08-22 23:40:13', '0000-00-00 00:00:00', '', 0, 'http://cedreo-designer.com.dev/?p=23', 1, 'nav_menu_item', '', 0),
(24, 1, '2016-08-22 23:41:15', '2016-08-22 21:41:15', ' ', '', '', 'publish', 'closed', 'closed', '', '24', '', '', '2016-09-16 11:30:42', '2016-09-16 09:30:42', '', 0, 'http://cedreo-designer.com.dev/?p=24', 1, 'nav_menu_item', '', 0),
(25, 1, '2016-08-22 23:41:15', '2016-08-22 21:41:15', ' ', '', '', 'publish', 'closed', 'closed', '', '25', '', '', '2016-09-16 11:30:42', '2016-09-16 09:30:42', '', 0, 'http://cedreo-designer.com.dev/?p=25', 6, 'nav_menu_item', '', 0),
(26, 1, '2016-08-22 23:41:15', '2016-08-22 21:41:15', ' ', '', '', 'publish', 'closed', 'closed', '', '26', '', '', '2016-09-16 11:30:42', '2016-09-16 09:30:42', '', 0, 'http://cedreo-designer.com.dev/?p=26', 8, 'nav_menu_item', '', 0),
(27, 1, '2016-08-22 23:41:15', '2016-08-22 21:41:15', ' ', '', '', 'publish', 'closed', 'closed', '', '27', '', '', '2016-09-16 11:30:42', '2016-09-16 09:30:42', '', 0, 'http://cedreo-designer.com.dev/?p=27', 4, 'nav_menu_item', '', 0),
(29, 1, '2016-08-22 23:41:15', '2016-08-22 21:41:15', ' ', '', '', 'publish', 'closed', 'closed', '', '29', '', '', '2016-09-16 11:30:42', '2016-09-16 09:30:42', '', 0, 'http://cedreo-designer.com.dev/?p=29', 2, 'nav_menu_item', '', 0),
(30, 1, '2016-08-22 23:41:15', '2016-08-22 21:41:15', '', 'S\'inscrire', '', 'publish', 'closed', 'closed', '', 'sinscrire', '', '', '2016-09-16 11:30:42', '2016-09-16 09:30:42', '', 0, 'http://cedreo-designer.com.dev/?p=30', 7, 'nav_menu_item', '', 0),
(31, 1, '2016-08-22 23:41:15', '2016-08-22 21:41:15', ' ', '', '', 'publish', 'closed', 'closed', '', '31', '', '', '2016-09-16 11:30:42', '2016-09-16 09:30:42', '', 0, 'http://cedreo-designer.com.dev/?p=31', 5, 'nav_menu_item', '', 0),
(35, 1, '2016-08-25 10:19:18', '2016-08-25 08:19:18', '', 'Devenez partenaires', '', 'publish', 'closed', 'closed', '', 'devenez-partenaires', '', '', '2016-09-20 10:04:44', '2016-09-20 08:04:44', '', 0, 'http://cedreo-designer.com.dev/?page_id=35', 0, 'page', '', 0),
(37, 1, '2016-08-25 10:19:26', '2016-08-25 08:19:26', '', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2016-09-20 09:59:17', '2016-09-20 07:59:17', '', 0, 'http://cedreo-designer.com.dev/?page_id=37', 0, 'page', '', 0),
(42, 1, '2016-08-30 10:45:10', '2016-08-30 08:45:10', '', 'Page Accueil', '', 'publish', 'closed', 'closed', '', 'acf_page-accueil', '', '', '2016-08-30 16:59:17', '2016-08-30 14:59:17', '', 0, 'http://cedreo-designer.com.dev/?post_type=acf&#038;p=42', 0, 'acf', '', 0),
(43, 1, '2016-08-30 11:03:14', '2016-08-30 09:03:14', '', 'constructeurs', '', 'inherit', 'open', 'closed', '', 'constructeurs', '', '', '2016-08-30 11:03:14', '2016-08-30 09:03:14', '', 5, 'http://cedreo-designer.com.dev/app/uploads/2016/08/constructeurs.png', 0, 'attachment', 'image/png', 0),
(44, 1, '2016-08-30 11:03:14', '2016-08-30 09:03:14', '', 'decoration', '', 'inherit', 'open', 'closed', '', 'decoration', '', '', '2016-08-30 11:03:14', '2016-08-30 09:03:14', '', 5, 'http://cedreo-designer.com.dev/app/uploads/2016/08/decoration.png', 0, 'attachment', 'image/png', 0),
(45, 1, '2016-08-30 11:03:15', '2016-08-30 09:03:15', '', 'architecture', '', 'inherit', 'open', 'closed', '', 'architecture', '', '', '2016-08-30 11:03:15', '2016-08-30 09:03:15', '', 5, 'http://cedreo-designer.com.dev/app/uploads/2016/08/architecture.png', 0, 'attachment', 'image/png', 0),
(46, 1, '2016-08-30 11:03:15', '2016-08-30 09:03:15', '', 'aide-vente', '', 'inherit', 'open', 'closed', '', 'aide-vente', '', '', '2016-08-30 11:03:15', '2016-08-30 09:03:15', '', 5, 'http://cedreo-designer.com.dev/app/uploads/2016/08/aide-vente.png', 0, 'attachment', 'image/png', 0),
(47, 1, '2016-08-30 11:03:16', '2016-08-30 09:03:16', '', 'immobilier', '', 'inherit', 'open', 'closed', '', 'immobilier', '', '', '2016-08-30 11:03:16', '2016-08-30 09:03:16', '', 5, 'http://cedreo-designer.com.dev/app/uploads/2016/08/immobilier.png', 0, 'attachment', 'image/png', 0),
(48, 1, '2016-08-30 11:03:17', '2016-08-30 09:03:17', '', 'renovation', '', 'inherit', 'open', 'closed', '', 'renovation', '', '', '2016-08-30 11:03:17', '2016-08-30 09:03:17', '', 5, 'http://cedreo-designer.com.dev/app/uploads/2016/08/renovation.png', 0, 'attachment', 'image/png', 0),
(49, 1, '2016-08-30 11:03:17', '2016-08-30 09:03:17', '', 'tablet-sprite', '', 'inherit', 'open', 'closed', '', 'tablet-sprite', '', '', '2016-08-30 11:03:17', '2016-08-30 09:03:17', '', 5, 'http://cedreo-designer.com.dev/app/uploads/2016/08/tablet-sprite.png', 0, 'attachment', 'image/png', 0),
(50, 1, '2016-08-30 11:03:18', '2016-08-30 09:03:18', '', '003', '', 'inherit', 'open', 'closed', '', '003', '', '', '2016-08-30 11:03:18', '2016-08-30 09:03:18', '', 5, 'http://cedreo-designer.com.dev/app/uploads/2016/08/003.jpg', 0, 'attachment', 'image/jpeg', 0),
(51, 1, '2016-08-30 11:03:18', '2016-08-30 09:03:18', '', '002', '', 'inherit', 'open', 'closed', '', '002', '', '', '2016-08-30 11:03:18', '2016-08-30 09:03:18', '', 5, 'http://cedreo-designer.com.dev/app/uploads/2016/08/002.jpg', 0, 'attachment', 'image/jpeg', 0),
(52, 1, '2016-08-30 11:03:19', '2016-08-30 09:03:19', '', '005', '', 'inherit', 'open', 'closed', '', '005', '', '', '2016-08-30 11:03:19', '2016-08-30 09:03:19', '', 5, 'http://cedreo-designer.com.dev/app/uploads/2016/08/005.jpg', 0, 'attachment', 'image/jpeg', 0),
(53, 1, '2016-08-30 11:03:19', '2016-08-30 09:03:19', '', '001', '', 'inherit', 'open', 'closed', '', '001', '', '', '2016-08-30 11:03:19', '2016-08-30 09:03:19', '', 5, 'http://cedreo-designer.com.dev/app/uploads/2016/08/001.jpg', 0, 'attachment', 'image/jpeg', 0),
(54, 1, '2016-08-30 11:03:20', '2016-08-30 09:03:20', '', '004', '', 'inherit', 'open', 'closed', '', '004', '', '', '2016-08-30 11:03:20', '2016-08-30 09:03:20', '', 5, 'http://cedreo-designer.com.dev/app/uploads/2016/08/004.jpg', 0, 'attachment', 'image/jpeg', 0),
(55, 1, '2016-08-30 11:03:21', '2016-08-30 09:03:21', '', 'timing-19-min', '', 'inherit', 'open', 'closed', '', 'timing-19-min', '', '', '2016-08-30 11:03:21', '2016-08-30 09:03:21', '', 5, 'http://cedreo-designer.com.dev/app/uploads/2016/08/timing-19-min.png', 0, 'attachment', 'image/png', 0),
(56, 1, '2016-08-30 11:03:21', '2016-08-30 09:03:21', '', 'timing-18-min', '', 'inherit', 'open', 'closed', '', 'timing-18-min', '', '', '2016-08-30 11:03:21', '2016-08-30 09:03:21', '', 5, 'http://cedreo-designer.com.dev/app/uploads/2016/08/timing-18-min.png', 0, 'attachment', 'image/png', 0),
(57, 1, '2016-08-30 11:03:22', '2016-08-30 09:03:22', '', 'timing-06-min', '', 'inherit', 'open', 'closed', '', 'timing-06-min', '', '', '2016-08-30 11:03:22', '2016-08-30 09:03:22', '', 5, 'http://cedreo-designer.com.dev/app/uploads/2016/08/timing-06-min.png', 0, 'attachment', 'image/png', 0),
(58, 1, '2016-08-30 11:03:22', '2016-08-30 09:03:22', '', 'help-04', '', 'inherit', 'open', 'closed', '', 'help-04', '', '', '2016-08-30 11:03:22', '2016-08-30 09:03:22', '', 5, 'http://cedreo-designer.com.dev/app/uploads/2016/08/help-04.jpg', 0, 'attachment', 'image/jpeg', 0),
(59, 1, '2016-08-30 11:03:23', '2016-08-30 09:03:23', '', 'help-03', '', 'inherit', 'open', 'closed', '', 'help-03', '', '', '2016-08-30 11:03:23', '2016-08-30 09:03:23', '', 5, 'http://cedreo-designer.com.dev/app/uploads/2016/08/help-03.jpg', 0, 'attachment', 'image/jpeg', 0),
(60, 1, '2016-08-30 11:03:23', '2016-08-30 09:03:23', '', 'help-02', '', 'inherit', 'open', 'closed', '', 'help-02', '', '', '2016-08-30 11:03:23', '2016-08-30 09:03:23', '', 5, 'http://cedreo-designer.com.dev/app/uploads/2016/08/help-02.jpg', 0, 'attachment', 'image/jpeg', 0),
(61, 1, '2016-08-30 11:03:24', '2016-08-30 09:03:24', '', 'help-01', '', 'inherit', 'open', 'closed', '', 'help-01', '', '', '2016-08-30 11:03:24', '2016-08-30 09:03:24', '', 5, 'http://cedreo-designer.com.dev/app/uploads/2016/08/help-01.jpg', 0, 'attachment', 'image/jpeg', 0),
(62, 1, '2016-08-30 11:03:24', '2016-08-30 09:03:24', '', 'step-photo-3d', '', 'inherit', 'open', 'closed', '', 'step-photo-3d', '', '', '2016-08-30 11:03:24', '2016-08-30 09:03:24', '', 5, 'http://cedreo-designer.com.dev/app/uploads/2016/08/step-photo-3d.png', 0, 'attachment', 'image/png', 0),
(63, 1, '2016-08-30 11:03:25', '2016-08-30 09:03:25', '', 'step-design', '', 'inherit', 'open', 'closed', '', 'step-design', '', '', '2016-08-30 11:03:25', '2016-08-30 09:03:25', '', 5, 'http://cedreo-designer.com.dev/app/uploads/2016/08/step-design.png', 0, 'attachment', 'image/png', 0),
(64, 1, '2016-08-30 11:03:25', '2016-08-30 09:03:25', '', 'step-floorplan', '', 'inherit', 'open', 'closed', '', 'step-floorplan', '', '', '2016-08-30 11:03:25', '2016-08-30 09:03:25', '', 5, 'http://cedreo-designer.com.dev/app/uploads/2016/08/step-floorplan.png', 0, 'attachment', 'image/png', 0),
(73, 1, '2016-08-30 12:04:01', '2016-08-30 10:04:01', '', 'Page secteur', '', 'publish', 'closed', 'closed', '', 'acf_page-secteur', '', '', '2016-08-30 12:45:55', '2016-08-30 10:45:55', '', 0, 'http://cedreo-designer.com.dev/?post_type=acf&#038;p=73', 0, 'acf', '', 0),
(74, 1, '2016-08-30 12:12:43', '2016-08-30 10:12:43', '', 'software-architecture', '', 'inherit', 'open', 'closed', '', 'software-architecture', '', '', '2016-08-30 12:12:43', '2016-08-30 10:12:43', '', 0, 'http://cedreo-designer.com.dev/app/uploads/2016/08/software-architecture.jpg', 0, 'attachment', 'image/jpeg', 0),
(75, 1, '2016-08-30 12:12:45', '2016-08-30 10:12:45', '', 'software-decoration', '', 'inherit', 'open', 'closed', '', 'software-decoration', '', '', '2016-08-30 12:12:45', '2016-08-30 10:12:45', '', 0, 'http://cedreo-designer.com.dev/app/uploads/2016/08/software-decoration.jpg', 0, 'attachment', 'image/jpeg', 0),
(76, 1, '2016-08-30 12:12:47', '2016-08-30 10:12:47', '', 'software-renovation', '', 'inherit', 'open', 'closed', '', 'software-renovation', '', '', '2016-08-30 12:12:47', '2016-08-30 10:12:47', '', 0, 'http://cedreo-designer.com.dev/app/uploads/2016/08/software-renovation.jpg', 0, 'attachment', 'image/jpeg', 0),
(77, 1, '2016-08-30 12:12:50', '2016-08-30 10:12:50', '', 'software-builder', '', 'inherit', 'open', 'closed', '', 'software-builder', '', '', '2016-08-30 12:12:50', '2016-08-30 10:12:50', '', 0, 'http://cedreo-designer.com.dev/app/uploads/2016/08/software-builder.jpg', 0, 'attachment', 'image/jpeg', 0),
(80, 1, '2016-08-30 12:19:33', '2016-08-30 10:19:33', 'a:0:{}', 'polylang_mo_3', '', 'private', 'closed', 'closed', '', 'polylang_mo_3', '', '', '2016-08-30 12:19:33', '2016-08-30 10:19:33', '', 0, 'http://cedreo-designer.com.dev/?post_type=polylang_mo&p=80', 0, 'polylang_mo', '', 0),
(93, 1, '2016-08-30 13:03:37', '2016-08-30 11:03:37', 'a:0:{}', 'polylang_mo_6', '', 'private', 'closed', 'closed', '', 'polylang_mo_6', '', '', '2016-08-30 13:03:37', '2016-08-30 11:03:37', '', 0, 'http://cedreo-designer.com.dev/?post_type=polylang_mo&p=93', 0, 'polylang_mo', '', 0),
(94, 1, '2016-08-30 15:51:31', '2016-08-30 13:51:31', '', 'Page iframe', '', 'publish', 'closed', 'closed', '', 'acf_page-iframe', '', '', '2016-08-30 15:51:40', '2016-08-30 13:51:40', '', 0, 'http://cedreo-designer.com.dev/?post_type=acf&#038;p=94', 0, 'acf', '', 0),
(96, 1, '2016-08-30 16:04:16', '2016-08-30 14:04:16', '', 'Page tutoriels', '', 'publish', 'closed', 'closed', '', 'acf_page-tutoriels', '', '', '2016-08-30 16:20:03', '2016-08-30 14:20:03', '', 0, 'http://cedreo-designer.com.dev/?post_type=acf&#038;p=96', 0, 'acf', '', 0),
(101, 1, '2016-09-13 23:35:29', '2016-09-13 21:35:29', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2016-09-20 10:05:43', '2016-09-20 08:05:43', '', 0, 'https://cedreo-designer.com.dev/?page_id=101', 0, 'page', '', 0),
(103, 1, '2016-09-13 23:39:07', '2016-09-13 21:39:07', '', 'Blog (US)', '', 'publish', 'closed', 'closed', '', 'blog-us', '', '', '2016-09-20 10:03:35', '2016-09-20 08:03:35', '', 0, 'https://cedreo-designer.com.dev/?page_id=103', 0, 'page', '', 0),
(105, 1, '2016-09-13 23:39:26', '2016-09-13 21:39:26', '', 'Price', '', 'publish', 'closed', 'closed', '', 'price', '', '', '2016-09-20 10:09:59', '2016-09-20 08:09:59', '', 0, 'https://cedreo-designer.com.dev/?page_id=105', 0, 'page', '', 0),
(107, 1, '2016-09-13 23:56:42', '2016-09-13 21:56:42', ' ', '', '', 'publish', 'closed', 'closed', '', '107', '', '', '2016-09-16 17:51:34', '2016-09-16 15:51:34', '', 0, 'https://cedreo-designer.com.dev/?p=107', 2, 'nav_menu_item', '', 0),
(108, 1, '2016-09-13 23:56:42', '2016-09-13 21:56:42', ' ', '', '', 'publish', 'closed', 'closed', '', '108', '', '', '2016-09-16 17:51:34', '2016-09-16 15:51:34', '', 0, 'https://cedreo-designer.com.dev/?p=108', 3, 'nav_menu_item', '', 0),
(109, 1, '2016-09-13 23:56:42', '2016-09-13 21:56:42', ' ', '', '', 'publish', 'closed', 'closed', '', '109', '', '', '2016-09-16 17:51:34', '2016-09-16 15:51:34', '', 0, 'https://cedreo-designer.com.dev/?p=109', 1, 'nav_menu_item', '', 0),
(110, 1, '2016-09-13 23:56:42', '2016-09-13 21:56:42', '', 'Liste des langues', '', 'publish', 'closed', 'closed', '', 'liste-des-langues', '', '', '2016-09-16 17:51:34', '2016-09-16 15:51:34', '', 0, 'https://cedreo-designer.com.dev/?p=110', 6, 'nav_menu_item', '', 0),
(111, 1, '2016-09-14 09:49:05', '2016-09-14 07:49:05', '', '', '', 'publish', 'closed', 'closed', '', '111', '', '', '2016-09-14 09:49:05', '2016-09-14 07:49:05', '', 0, 'https://cedreo-designer.com.dev/nf_sub/111/', 0, 'nf_sub', '', 0),
(112, 1, '2016-09-14 09:53:21', '2016-09-14 07:53:21', '', '', '', 'publish', 'closed', 'closed', '', '112', '', '', '2016-09-14 09:53:21', '2016-09-14 07:53:21', '', 0, 'https://cedreo-designer.com.dev/nf_sub/112/', 0, 'nf_sub', '', 0),
(113, 0, '2016-09-15 11:07:57', '2016-09-15 09:07:57', '', '', '', 'publish', 'closed', 'closed', '', '113', '', '', '2016-09-15 11:07:57', '2016-09-15 09:07:57', '', 0, 'https://cedreo-designer.com.dev/nf_sub/113/', 0, 'nf_sub', '', 0),
(114, 4, '2016-09-15 11:26:48', '0000-00-00 00:00:00', '', 'Brouillon auto', '', 'auto-draft', 'open', 'open', '', '', '', '', '2016-09-15 11:26:48', '0000-00-00 00:00:00', '', 0, 'https://cedreo-designer.com.dev/?p=114', 0, 'post', '', 0),
(115, 5, '2016-09-15 11:28:55', '0000-00-00 00:00:00', '', 'Brouillon auto', '', 'auto-draft', 'open', 'open', '', '', '', '', '2016-09-15 11:28:55', '0000-00-00 00:00:00', '', 0, 'https://cedreo-designer.com.dev/?p=115', 0, 'post', '', 0),
(116, 3, '2016-09-15 11:34:34', '0000-00-00 00:00:00', '', 'Brouillon auto', '', 'auto-draft', 'open', 'open', '', '', '', '', '2016-09-15 11:34:34', '0000-00-00 00:00:00', '', 0, 'https://cedreo-designer.com.dev/?p=116', 0, 'post', '', 0),
(127, 3, '2016-09-16 09:24:43', '2016-09-16 07:24:43', '<h2>Que voulez-vous faire ?</h2>\r\nCedreo Designer est un logiciel complet de création de <strong>maison 3D en ligne</strong> pour les professionnels et les particuliers.\r\n<blockquote>\r\n<ol>\r\n 	<li>Je veux <a href="https://cedreo-designer.fr.dev/mon-besoin/dessiner-plan-maison/">créer mon plan de maison</a> pour mon nouveau logement.</li>\r\n 	<li>Je veux <a href="https://cedreo-designer.fr.dev/mon-besoin/dessiner-maison-3d/">construire ma maison 3D</a>.</li>\r\n 	<li>Je veux <a href="https://cedreo-designer.fr.dev/mon-besoin/amenagement-agencement-3d/">agencer et aménager ma maison en 3D</a>.</li>\r\n 	<li>Je veux décorer ma maison.</li>\r\n 	<li>Je veux prévisualiser la rénovation ou l\'agrandissement de ma maison actuelle.</li>\r\n</ol>\r\n</blockquote>\r\n&nbsp;\r\n\r\n&nbsp;', 'Mon besoin', '', 'publish', 'closed', 'closed', '', 'mon-besoin', '', '', '2016-09-20 10:12:31', '2016-09-20 08:12:31', '', 0, 'https://cedreo-designer.com.dev/?page_id=127', 0, 'page', '', 0),
(129, 3, '2016-09-16 09:26:01', '2016-09-16 07:26:01', '<h2>Mon plan de maison 3D en quelques minutes</h2>\r\nCedreo Designer est un <strong>logiciel de création de plan de maison 3D </strong>intuitif et facile d\'utilisation. Il vous permet de dessiner un plan de maison complet en quelques minutes et de le visualiser en 3D. Importez votre plan si vous en avez déjà un, tracez de nouveaux murs par simple clic, ajoutez vos ouvrants, créez des étages supplémentaires. Grâce aux multiples fonctionnalités du logiciel, votre <strong>plan de maison 3D</strong> est réglable dans les moindres détails. Et le petit plus : pas besoin de l\'installer. En effet, l\'outil Cedreo Designer est intégralement hébergé en ligne. Une connexion Internet suffit pour y accéder de n\'importe où.\r\n<h3>De la création à l\'agencement</h3>\r\nCedreo Designer vous accompagne tout au long de votre projet de création de maison en ligne. Une fois le plan de maison finalisé, vous pourrez passer à la visualisation de votre maison ou de votre appartement 3D. La richesse de nos bibliothèques de produits vous permet de procéder à l\'aménagement 3D de vos espaces et à sa décoration. Vous pouvez également choisir de vous concentrer sur la création 3D d\'une seule pièce si vous souhaitez agrandir ou rénover.\r\n<h3>J\'obtiens un rendu professionnel</h3>\r\nQuand votre projet est terminé, le plan de maison en ligne peut être exporté en 2D. Vous pouvez alors imprimer le fichier image, le partager avec votre famille et vos proches ou le transmettre à votre architecte ou au constructeur de maison en charge de votre projet. Pour tous vos <a href="https://cedreo-designer.fr.dev/mon-besoin/dessiner-maison-3d/">projets de maison 3D</a>, Cedreo Designer vous donne entre autres la possibilité de placer des étiquettes d\'annotation sur chaque pièce de votre plan de maison pour vous repérer dans votre futur chez vous. Le logiciel calcule automatiquement les cotes pour vous permettre d\'effectuer des mesures précises au centimètre près.\r\n\r\n<span style="font-size: inherit; line-height: 1.6;">Vous </span><span style="font-size: inherit; line-height: 1.6;">avez le droit de créer</span><span style="font-size: inherit; line-height: 1.6;"> jusqu\'à 3 projets de <strong>plan de maison gratuit</strong> avec notre Designer.</span>\r\n<blockquote>Découvrez toutes les possibilités de notre logiciel d\'architecture 3D en visitant notre <a href="https://cedreo-designer.fr.dev/galerie/">galerie d\'inspirations</a>.</blockquote>\r\n&nbsp;', 'Créer un plan de maison', '', 'publish', 'closed', 'closed', '', 'dessiner-plan-maison', '', '', '2016-09-20 10:11:32', '2016-09-20 08:11:32', '', 127, 'https://cedreo-designer.com.dev/?page_id=129', 0, 'page', '', 0),
(147, 3, '2016-09-16 09:43:56', '0000-00-00 00:00:00', '', 'Brouillon auto', '', 'auto-draft', 'open', 'open', '', '', '', '', '2016-09-16 09:43:56', '0000-00-00 00:00:00', '', 0, 'https://cedreo-designer.com.dev/?p=147', 0, 'post', '', 0),
(151, 3, '2016-09-16 11:21:24', '2016-09-16 09:21:24', ' ', '', '', 'publish', 'closed', 'closed', '', '151', '', '', '2016-09-16 11:30:42', '2016-09-16 09:30:42', '', 0, 'https://cedreo-designer.com.dev/?p=151', 3, 'nav_menu_item', '', 0),
(154, 3, '2016-09-16 11:30:19', '2016-09-16 09:30:19', '', 'Liste des langues', '', 'publish', 'closed', 'closed', '', 'liste-des-langues-2', '', '', '2016-09-16 11:30:42', '2016-09-16 09:30:42', '', 0, 'https://cedreo-designer.com.dev/liste-des-langues-2/', 9, 'nav_menu_item', '', 0),
(161, 3, '2016-09-16 15:29:44', '2016-09-16 13:29:44', '<h2>Je construis ma maison 3D</h2>\r\nLe logiciel 3D Cedreo Designer vous permet, en plus de <a href="https://cedreo-designer.fr.dev/mon-besoin/dessiner-plan-maison/">dessiner un plan de maison</a>, de créer votre maison ou votre<strong> appartement en 3D</strong> et de la visualiser instantanément comme si vous y étiez. La <strong>visite virtuelle</strong> de l\'ensemble de votre logement se trouve au bout de votre souris. Zoomez, pivotez, entrez dans les pièces, inspectez votre projet de maison 3D sous tous les angles et effectuez toutes les retouches nécessaires instantanément. Vous pouvez également vous concentrer sur un projet unique et créer votre salle de bain ou votre cuisine en 3D.\r\n\r\nOutre la construction de maison, Cedreo Designer vous propose d\'aménager votre <strong>maison 3D </strong>ou la pièce que vous avez pour projet d\'agrandir ou de rénover. Mobilier et peintures sont personnalisables à volonté pour une décoration très aboutie. Contrairement à de nombreux autres logiciels d\'architecture, notre logiciel 3D supporte également la création de toiture. Vous construisez votre nouvelle maison dans son ensemble, aménagements extérieurs inclus !\r\n<h3>Visuels photoréalistes</h3>\r\nQuoi de mieux pour conclure une visite que de prendre des photos de votre maison ou de votre appartement ? Sur Cedreo Designer, la visite virtuelle 3D répond aux mêmes exigences. En quelques secondes, vous pouvez générer des rendus haut de gamme. Il vous suffit simplement de placer l\'angle de la prise de vue dans votre <strong>maison 3D</strong>. Notre outil vous fournit automatiquement un visuel photoréaliste digne des meilleurs logiciels d\'architecture.\r\n\r\nPour encore plus de réalisme, vous sélectionnez à votre convenance l\'effet souhaité. Orientation du soleil, intérieur, extérieur, ciel d\'été, ciel du soir, environnement de campagne, rue parisienne... Le calcul de votre image HD ne prend que quelques minutes pour un résultat plus vrai que nature, le tout sans réglage supplémentaire. Vous pouvez ensuite télécharger les photos de votre maison 3D pour les conserver et comparer différentes configurations.\r\n\r\n&nbsp;\r\n\r\nVous hésitez encore ? Sachez qu\'il est possible de tester notre outil en ligne et de commencer à construire sa maison en 3D sans avoir besoin d\'ouvrir un compte. Pour vous inspirer, découvrez également tous nos visuels HD dans notre <a href="https://cedreo-designer.fr.dev/galerie/">galerie de styles</a>.', 'Créer sa maison en 3D', '', 'publish', 'closed', 'closed', '', 'dessiner-maison-3d', '', '', '2016-09-20 10:08:27', '2016-09-20 08:08:27', '', 127, 'https://cedreo-designer.com.dev/?page_id=161', 0, 'page', '', 0),
(180, 3, '2016-09-16 17:22:55', '2016-09-16 15:22:55', '<h2>Je construis mon plan 3D de salle de bain</h2>\r\nCréez votre projet de <strong>salle de bain en 3D en ligne</strong> sur Cedreo Designer. Concevez votre salle de bain en 3D et jouez avec les espaces à l\'infini. Remodelez les surfaces à loisir en abattant la cloison entre les toilettes et la salle de bain pour agrandir la pièce. Repensez la robinetterie et l\'emplacement des receveurs pour correspondre aux normes actuelles.\r\n\r\nUne fois les contours tracés, vous pouvez ensuite équiper intégralement votre salle de bain en 3D grâce à notre bibliothèque de produits. Testez la place occupée par une baignoire ou choisissez une douche parmi nos nombreux modèles, passez d\'un lavabo à un meuble à double-vasque. Gagnez du temps au moment de choisir vos accessoires en sélectionnant nos packs salle de bain. Nos bibliothèques de produits sont continuellement mises à jour en collaboration avec nos partenaires. Vous pouvez également choisir des meubles à personnaliser et en changer le revêtement et la couleur.\r\n<h2><span style="color: inherit; font-size: 1.9375rem; line-height: 1.4;">La salle de bain : un enjeu de taille pour les professionnels de l\'immobilier</span></h2>\r\nDans le cadre d\'une vente immobilière, la salle de bain a le potentiel de déclencher un coup de coeur. Qu\'il s\'agisse d\'une rénovation ou d\'un projet neuf, vous pouvez mettre toutes les chances de vente de votre côté en présentant à votre acheteur potentiel une <strong>salle de bain 3D</strong> moderne et épurée. Et pour illustrer au mieux votre projet, rien de mieux qu\'un visuel HD de qualité. Choisissez la luminosité idéale et laissez notre logiciel 3D Cedreo Designer faire le travail pour vous ! A noter que la cuisine représente aussi un enjeu stratégique.\r\n\r\nVous avez encore des doutes sur la décoration et l\'ambiance à choisir pour votre salle de bain en 3D ? Alors rendez-vous dans notre <a href="https://cedreo-designer.fr.dev/galerie/">galerie des tendances déco</a> du moment pour faire le plein d\'idées !\r\n\r\n&nbsp;', 'Créer sa salle de bain en 3D', '', 'publish', 'closed', 'closed', '', 'salle-de-bain-3d', '', '', '2016-09-20 10:09:10', '2016-09-20 08:09:10', '', 161, 'https://cedreo-designer.com.dev/?page_id=180', 0, 'page', '', 0),
(184, 1, '2016-09-16 17:46:57', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-09-16 17:46:57', '0000-00-00 00:00:00', '', 0, 'https://cedreo-designer.com.dev/?p=184', 1, 'nav_menu_item', '', 0),
(185, 1, '2016-09-16 17:46:57', '0000-00-00 00:00:00', '', 'S\'inscrire', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-09-16 17:46:57', '0000-00-00 00:00:00', '', 0, 'https://cedreo-designer.com.dev/?p=185', 1, 'nav_menu_item', '', 0),
(186, 1, '2016-09-16 17:47:56', '2016-09-16 15:47:56', '', 'Log in', '', 'publish', 'closed', 'closed', '', 'log-in', '', '', '2016-09-20 10:06:01', '2016-09-20 08:06:01', '', 0, 'https://cedreo-designer.com.dev/?page_id=186', 0, 'page', '', 0),
(188, 1, '2016-09-16 17:48:26', '2016-09-16 15:48:26', '', 'Sign up', '', 'publish', 'closed', 'closed', '', 'sign-up', '', '', '2016-09-20 10:02:16', '2016-09-20 08:02:16', '', 0, 'https://cedreo-designer.com.dev/?page_id=188', 0, 'page', '', 0),
(190, 1, '2016-09-16 17:49:22', '2016-09-16 15:49:22', ' ', '', '', 'publish', 'closed', 'closed', '', '190', '', '', '2016-09-16 17:51:34', '2016-09-16 15:51:34', '', 0, 'https://cedreo-designer.com.dev/?p=190', 5, 'nav_menu_item', '', 0),
(191, 1, '2016-09-16 17:49:22', '2016-09-16 15:49:22', '', 'Sign in', '', 'publish', 'closed', 'closed', '', '191', '', '', '2016-09-16 17:51:34', '2016-09-16 15:51:34', '', 0, 'https://cedreo-designer.com.dev/?p=191', 4, 'nav_menu_item', '', 0),
(192, 3, '2016-09-19 11:15:10', '2016-09-19 09:15:10', '<h2>Je construis ma cuisine en 3D</h2>\r\nCedreo Designer permet de créer sa <strong>cuisine 3D en ligne </strong>pour simuler vos travaux d\'aménagement et de rénovation. Concevez votre <strong>plan de cuisine</strong> rapidement grâce à l\'outil de création de pièce et commencez aussitôt à repenser la disposition de votre mobilier.\r\n\r\nLe catalogue cuisine de notre logiciel 3D peut être entièrement personnalisé selon vos préférences. Modifiez à volonté la taille, la couleur et le revêtement de tous vos éléments. Depuis le plateau jusqu\'aux poignées en passant par le caisson, les pieds et les tiroirs : tout est flexible. Rien n\'est laissé au hasard pour vous permettre de dessiner une cuisine en 3D adaptée à vos besoins. Ajustez votre plan de travail au centimètre près, calculez l\'encombrement exact de votre lave-vaisselle et démultipliez les solutions de rangement pour pouvoir y entreposer service de table et ustensiles de cuisine. Créer sa cuisine en 3D n\'a jamais été aussi simple !\r\n<h3>Les secrets d\'une cuisine 3D conviviale</h3>\r\nLa cuisine est l\'espace familial par excellence où se retrouver le matin autour d\'un bon petit-déjeuner. Qu\'elle soit grande ou petite, visualiser votre <strong>plan de cuisine en 3D</strong> vous permet d\'optimiser entièrement son agencement. Côté déco, vous cherchez à recréer une atmosphère cosy et chaleureuse ? Rien de plus facile avec Cedreo Designer. Pourquoi ne pas envisager l\'îlot central à la place de la traditionnelle table de cuisine ? <a href="https://cedreo-designer.fr.dev/galerie/">Notre galerie de styles 3D fourmille de bonnes idées déco </a>dans lesquelles puiser pour vous inspirer. Vous pouvez aussi vous tourner vers nos packs ambiance pour décorer votre cuisine 3D harmonieusement tout en gagnant du temps.\r\n\r\nEt si vous avez décidé de vous lancer dans la rénovation de votre cuisine mais que vous ne voulez pas d\'un gros chantier, le home staging peut également être un bon moyen de redonner un coup de jeune à votre pièce.\r\n<h4>Cedreo Designer pour tous vos projets de maison 3D</h4>\r\nOutre la cuisine, Cedreo Designer vous permet de construire les plans et d\'aménager en 3D toutes les pièces de votre maison. Il propose notamment la <a href="https://cedreo-designer.fr.dev/mon-besoin/dessiner-maison-3d/salle-de-bain-3d/">conception de salle de bain 3D</a> !\r\n\r\n&nbsp;', 'Créer sa cuisine en 3D', '', 'publish', 'closed', 'closed', '', 'creer-cuisine-3d', '', '', '2016-09-20 10:08:49', '2016-09-20 08:08:49', '', 161, 'https://cedreo-designer.com.dev/?page_id=192', 0, 'page', '', 0),
(194, 3, '2016-09-19 17:15:29', '2016-09-19 15:15:29', '<h2>Je réalise l\'aménagement 3D de ma maison</h2>\r\nLorsqu\'on fait l\'acquisition d\'un nouveau logement, il peut être difficile de se projeter. C\'est encore plus le cas lors d\'une rénovation. L\'aménagement 3D vous aide de vous détacher de votre vision antérieure en vous donnant des perspectives plus précises du futur look de votre maison.\r\n\r\nUne fois que vous avez créé votre <a href="https://cedreo-designer.fr.dev/mon-besoin/dessiner-plan-maison/">plan de maison en ligne</a> et que vous avez pu visualiser un premier aperçu de votre <a href="https://cedreo-designer.fr.dev/mon-besoin/dessiner-maison-3d/">maison 3D</a>, vous allez pouvoir passer à l\'aménagement en ligne de chaque pièce. Aménagement intérieur comme aménagement extérieur, Cedreo Designer vous permet de prendre en main l\'ameublement de votre maison ou de votre appartement dans son intégralité.\r\n<h3>Je teste toutes les possibilités d\'agencement</h3>\r\nAppartement, petite maison, grande maison, logement neuf, logement ancien... tous les logements ne sont pas tous aussi faciles à aménager ! Certaines pièces se prêtent à de nombreuses possibilités. D\'autres au contraire nécessitent une réflexion particulière pour optimiser les espaces. Grâce à notre <strong>logiciel d\'aménagement 3D</strong>, vous pouvez tester toutes les configurations possibles et imaginables. Le but ? Trouver la solution qui vous convient le mieux, le tout en fonction de la surface et de l\'architecture de votre chez vous. Pour mieux maîtriser et aménager vos espaces exigus, vous pouvez également consulter toutes nos <a href="https://cedreo-designer.fr.dev/galerie/">astuces déco</a> et des possibilités de rangements bien pensés. Et une fois l\'<strong>aménagement 3D de votre maison</strong> achevé, place à la décoration 3D !\r\n\r\n<span style="color: inherit; font-size: 1.9375rem; line-height: 1.4;">Le plus Cedreo Designer</span><span style="color: inherit; font-size: 1.9375rem; line-height: 1.4;"> : u</span><span style="color: inherit; font-size: 1.9375rem; line-height: 1.4;">ne base de données produits</span><span style="color: inherit; font-size: 1.9375rem; line-height: 1.4;"> </span><span style="color: inherit; font-size: 1.9375rem; line-height: 1.4;">riche</span>\r\n\r\nGrâce à un catalogue de mobilier régulièrement étoffé et mis à jour, notre logiciel 3D vous permet de planifier l\'agencement de votre maison pour tous les goûts et pour tous les styles. Nos équipes travaillent en permanence pour garantir à la communauté Cedreo Designer un service de qualité. Ainsi, nous étudions régulièrement les demandes des utilisateurs qui nous sont transmises sur notre forum. Lorsqu\'il est question d\'intégrer un nouveau produit ou un nouveau revêtement, votre avis compte !\r\n\r\n&nbsp;\r\n\r\n&nbsp;', 'Aménager et agencer son logement en 3D', '', 'publish', 'closed', 'closed', '', 'amenagement-agencement-3d', '', '', '2016-09-20 10:07:31', '2016-09-20 08:07:31', '', 127, 'https://cedreo-designer.com.dev/?page_id=194', 0, 'page', '', 0),
(196, 3, '2016-09-20 10:07:57', '2016-09-20 08:07:57', '<h2>J\'aménage mes extérieurs</h2>\r\nL\'une des particularités de Cedreo Designer, c\'est la possibilité de planifier l\'aménagement 3D des extérieurs avec autant de soin que l\'<a href="https://cedreo-designer.fr.dev/mon-besoin/amenagement-agencement-3d/amenagement-interieur/">aménagement intérieur</a>. Commencez d\'abord par délimiter le terrain autour de votre logement. Vous pourrez ensuite choisir d\'y ajouter une piscine, de la pelouse, d\'y tracer une allée ou d\'y créer une terrasse. Ce premier plan de jardin pourra ensuite être complété grâce à notre gamme de produits d\'<strong>aménagement extérieur</strong>.\r\n<h3><span style="color: inherit; font-size: 1.9375rem; line-height: 1.4;">Logiciel d\'aménagement paysager</span></h3>\r\nCedreo Designer est un outil idéal pour les particuliers et professionnels à la recherche d\'un logiciel pour paysagiste facile à utiliser. Avec ses nombreuses options, il est idéal pour la conception et l\'aménagement de jardin en 3D. Notre catalogue comprend notamment un grand nombre de plantes (murales, en pot, au sol...), d\'arbres et d\'arbustes pour arborer votre jardin en 3D. Vous pouvez également aménager votre terrasse au goût du jour grâce à notre gamme de mobilier extérieur. Pergolas, balançoires, grills et véhicules de toutes les tailles figurent dans notre base de données. Le tout est pensé pour donner une touche personnelle à votre <strong>extérieur 3D</strong>.\r\n\r\nVous recherchez une ambiance particulière ? Vous hésitez entre une terrasse en caillebotis ou en carrelage ? Entre une haie et un muret ? Tous les revêtements des éléments sont réglables, jusqu\'à la couleur des graviers de votre allée et à la forme des feuilles de votre haie. La conception de votre jardin et de vos extérieurs 3D en général.\r\n<h3><span style="color: inherit; font-size: 1.9375rem; line-height: 1.4;">Un large choix de toitures</span></h3>\r\nAvec Cedreo Designer, vous pouvez ajouter un toit à votre maison et le manipuler à votre guise. Toit classique, toit plat, monopente... Notre <strong>logiciel d\'aménagement extérieur 3D</strong> permet de réaliser un grand nombre de charpentes et de régler individuellement pignons et autres débords. Cependant, vous pouvez modeler plus que la simple charpente. Pour ceux d\'entre vous vivant dans une région avec un style architectural particulier, il est par exemple possible de réaliser des architectures complexes comprenant des colombages. En plus de pouvoir ajouter des gouttières, des cheminées et des panneaux solaires, vous avez également le choix entre plusieurs styles de tuiles : tuiles rondes, tuiles romanes, ardoise...\r\n<h3>Des rendus spécialement conçus pour l\'extérieur</h3>\r\nNotre moteur de rendu met à votre disposition un grand nombre d\'options pour les visuels HD de vos aménagements extérieurs. En fonction de l\'éclairage et de l\'entourage choisi (campagne, quartier...) pour la prise de vue, il recrée une lumière naturelle et tout un environnement autour de votre maison et de votre <strong>jardin 3D</strong>. La qualité des rendus finaux n\'en est alors que plus saisissante.', 'Logiciel d\'aménagement extérieur et jardin 3D', '', 'publish', 'closed', 'closed', '', 'logiciel-amenagement-exterieur-jardin-3d', '', '', '2016-09-20 16:16:06', '2016-09-20 14:16:06', '', 194, 'https://cedreo-designer.com.dev/?page_id=196', 0, 'page', '', 0),
(198, 3, '2016-09-20 09:50:47', '0000-00-00 00:00:00', '', 'Brouillon auto', '', 'auto-draft', 'open', 'open', '', '', '', '', '2016-09-20 09:50:47', '0000-00-00 00:00:00', '', 0, 'https://cedreo-designer.com.dev/?p=198', 0, 'post', '', 0),
(213, 3, '2016-09-20 16:12:28', '2016-09-20 14:12:28', '<h2>J\'aménage mon intérieur 3D</h2>\r\nAvec notre logiciel d\'<strong>aménagement intérieur 3D</strong>, supervisez l\'agencement de votre mobilier dans votre logement 3D. Muni du plan de votre maison, choisissez la vue 2D ou 3D pour placer les meubles et les équipements que vous désirez. Notre catalogue de produits, organisé par pièce et par catégorie, vous permet de trouver rapidement le mobilier dont vous avez besoin pour aménager vos pièces, intérieur comme <a href="https://cedreo-designer.fr.dev/mon-besoin/amenagement-agencement-3d/logiciel-amenagement-exterieur-jardin-3d/">extérieur 3D</a>.\r\n<h3>Idéal pour les pressés...</h3>\r\nLes plus pressés seront heureux de découvrir un certain nombre de raccourcis. En quelques clics, vous avez ainsi accès à nos packs-produits déjà prêts. Ensemble table et chaises pour la salle à manger, cuisine aménagée avec frigo, four encastré et îlot central, bibliothèques déjà chargées de livres et de bibelots... Nous avons pensé à vous pour vous permettre d\'<strong>agencer votre intérieur</strong> facilement. Cliquez, déposez, agencez ! Votre logement est achevé et prêt à être exporté en rendus HD en quelques minutes, montre en main.\r\n\r\nDe plus, un grand nombre d\'éléments de nos packs restent modifiables individuellement, comme la couleur des revêtements. Ainsi, vous pouvez gagner du temps dans votre aménagement intérieur sans transiger sur vos préférences en matière de décoration.\r\n<h3>Et pour les perfectionnistes !</h3>\r\nSi vous souhaitez au contraire tout paramétrer au millimètre près, vous trouverez aussi votre bonheur avec notre<strong> logiciel d\'aménagement intérieur 3D</strong>. Pour vous projeter au maximum dans votre futur logement, vous avez accès à des produits de marque. Grâce à notre partenariat avec de grands spécialistes de l\'ameublement, vous pouvez sélectionner de vrais meubles vendus en magasin.\r\n\r\nA ce catalogue s\'ajoutent des meubles génériques dessinés par nos graphistes. Ceux-ci sont parfaits si vous avez déjà des idées très précises de ce que vous souhaitez. Disponibles dans une grande variété de styles, ils peuvent être modifiés à votre convenance pour correspondre exactement à vos aspirations.', 'Logiciel d\'aménagement intérieur 3D', '', 'publish', 'closed', 'closed', '', 'amenagement-interieur', '', '', '2016-09-20 16:42:00', '2016-09-20 14:42:00', '', 194, 'https://cedreo-designer.com.dev/?page_id=213', 0, 'page', '', 0),
(224, 3, '2016-09-21 16:41:49', '2016-09-21 14:41:49', '<h2>Je décore mon intérieur 3D</h2>\r\nPour donner vie à un projet, il ne suffit pas de <a href="https://cedreo-designer.fr.dev/mon-besoin/dessiner-plan-maison/">créer son plan de maison</a> ni même simplement d\'<a href="https://cedreo-designer.fr.dev/mon-besoin/amenagement-agencement-3d/">aménager son logement</a>. La qualité de votre projet, qu\'il s\'agisse d\'une construction à neuf ou de travaux de rénovation, va aussi se traduire par la foule de petits détails qui va venir habiller et animer votre <a href="https://cedreo-designer.fr.dev/mon-besoin/dessiner-maison-3d/">maison 3D</a>. Pour y parvenir, vous pouvez faire plus qu\'intégrer des personnages.\r\n<h3>Décoration intérieur : tout est dans le détail</h3>\r\nUne partie du catalogue-produits de Cedreo Designer a ainsi été spécialement conçue pour la <strong>décoration intérieure</strong>. Un DVD qui traîne sur le canapé, un magazine ouvert sur une table, des chemises soigneusement pliées dans les placards... Grâce à ces accessoires,vous envisagez votre déco d\'intérieur sous tous ses angles. Plus encore, vous vous plongez réellement dans la vie de la maison. L\'étape déco complète l\'aménagement en présentant au propriétaire une vision en temps réel de son nouveau logement. Des étagères, un dressing spacieux, oui. Mais est-ce que ce n\'est pas encore mieux si vous lui montrez tout ce qu\'il peut vraiment y ranger ? La touche déco donne de la valeur ajoutée à l\'ensemble de votre projet. Et pas besoin pour cela d\'y passer des heures. Comme c\'est le cas pour l\'aménagement, le catalogue déco regorge d\'éléments près à l\'intégration !\r\n<h3>Le logiciel parfait pour les architectes d\'intérieur</h3>\r\nCet éventail de possibilités fait de Cedreo Designer un excellent logiciel pour les spécialistes de l\'<strong>architecture d\'intérieur</strong> et du <a href="https://cedreo-designer.fr.dev/mon-besoin/decoration-interieur-3d/logiciel-home-staging/">home staging</a>. Sans compter la grande marge de manoeuvre que permet Cedreo dans l\'ajustement du mobilier pour ceux qui préfèrent un réglage en toute liberté !\r\n\r\nNotre logiciel vous permet d\'exporter des perspectives de haute qualité de votre déco intérieur, et ceci en quelques minutes seulement. Pour cela, vous réalisez simplement le cadrage de votre prise de vue et la luminosité souhaitée. Pour un rendu parfait, nous vous conseillons d\'opter pour une scène d\'intérieur. Notre moteur de rendu se chargera de tous les calculs : ombres portées, reflets, textures. L\'architecte décorateur à la recherche d\'un simulateur de déco 3D pourra ainsi produire des rendus impressionnants de l\'avant et après décoration intérieur.', 'Réaliser sa décoration intérieur 3D', '', 'publish', 'closed', 'closed', '', 'decoration-interieur-3d', '', '', '2016-09-21 17:23:10', '2016-09-21 15:23:10', '', 127, 'https://cedreo-designer.com.dev/?page_id=224', 0, 'page', '', 0),
(229, 1, '2016-09-21 12:38:04', '0000-00-00 00:00:00', '', 'Brouillon auto', '', 'auto-draft', 'open', 'open', '', '', '', '', '2016-09-21 12:38:04', '0000-00-00 00:00:00', '', 0, 'https://cedreo-designer.com.dev/?p=229', 0, 'post', '', 0),
(234, 3, '2016-09-21 17:15:56', '2016-09-21 15:15:56', '<h2>Je réalise mon home staging virtuel</h2>\r\nLe <strong>home staging</strong>, ou <strong>valorisation immobilière</strong>, consiste à mettre en valeur un bien immobilier destiné à être vendu ou loué.Le principe du home staging est de provoquer un coup de coeur chez un acquéreur potentiel.\r\n\r\nCette pratique a récemment été popularisée par un certain nombre d\'émissions consacrées à la vente d\'appartements et de maisons. Il suffit parfois de peu de choses pour montrer le potentiel d\'une maison. Afin de limiter les frais de redécoration, elle passe notamment par le <strong>relooking</strong> d\'une partie du mobilier existant et par l\'ajout de petits éléments destinés à faire ressortir les qualités d\'une pièce ou d\'un espace.\r\n\r\nEt si je relookais mon vieux buffet ?\r\n\r\nFaire du neuf avec du moins neuf, jouer sur le caractère vintage de certains meubles pour leur redonner du cachet. C\'est l\'un des principes fondateurs de la valorisation immobilière. Si vous avez vous aussi décidé de vous lancer dans la rénovation d\'une pièce, un coup de pinceau sur vos anciens équipements peut tout changer.', 'Logiciel de home staging', '', 'publish', 'closed', 'closed', '', 'logiciel-home-staging', '', '', '2016-09-21 17:28:44', '2016-09-21 15:28:44', '', 224, 'https://cedreo-designer.com.dev/?page_id=234', 0, 'page', '', 0),
(243, 1, '2016-09-21 22:57:04', '2016-09-21 20:57:04', '', 'Page Galerie', '', 'publish', 'closed', 'closed', '', 'acf_page-galerie', '', '', '2016-09-21 22:58:30', '2016-09-21 20:58:30', '', 0, 'https://cedreo-designer.com.dev/?post_type=acf&#038;p=243', 0, 'acf', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(1, 3, 0),
(1, 4, 0),
(1, 5, 0),
(5, 3, 0),
(5, 10, 0),
(7, 3, 0),
(8, 5, 0),
(8, 7, 0),
(9, 3, 0),
(11, 3, 0),
(15, 3, 0),
(15, 12, 0),
(17, 3, 0),
(17, 11, 0),
(19, 3, 0),
(19, 15, 0),
(21, 3, 0),
(21, 14, 0),
(24, 2, 0),
(25, 2, 0),
(26, 2, 0),
(27, 2, 0),
(29, 2, 0),
(30, 2, 0),
(31, 2, 0),
(35, 3, 0),
(37, 3, 0),
(42, 3, 0),
(43, 3, 0),
(44, 3, 0),
(45, 3, 0),
(46, 3, 0),
(47, 3, 0),
(48, 3, 0),
(49, 3, 0),
(50, 3, 0),
(51, 3, 0),
(52, 3, 0),
(53, 3, 0),
(54, 3, 0),
(55, 3, 0),
(56, 3, 0),
(57, 3, 0),
(58, 3, 0),
(59, 3, 0),
(60, 3, 0),
(61, 3, 0),
(62, 3, 0),
(63, 3, 0),
(64, 3, 0),
(73, 3, 0),
(74, 3, 0),
(75, 3, 0),
(76, 3, 0),
(77, 3, 0),
(101, 6, 0),
(101, 10, 0),
(103, 6, 0),
(103, 11, 0),
(105, 6, 0),
(105, 12, 0),
(107, 13, 0),
(108, 13, 0),
(109, 13, 0),
(110, 13, 0),
(114, 6, 0),
(115, 6, 0),
(116, 6, 0),
(127, 3, 0),
(129, 3, 0),
(147, 6, 0),
(151, 2, 0),
(154, 2, 0),
(161, 3, 0),
(180, 3, 0),
(186, 6, 0),
(186, 14, 0),
(188, 6, 0),
(188, 15, 0),
(190, 13, 0),
(191, 13, 0),
(192, 3, 0),
(194, 3, 0),
(196, 3, 0),
(198, 6, 0),
(213, 3, 0),
(224, 3, 0),
(229, 6, 0),
(234, 3, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'nav_menu', '', 0, 9),
(3, 3, 'language', 'a:3:{s:6:"locale";s:5:"fr_FR";s:3:"rtl";i:0;s:9:"flag_code";s:2:"fr";}', 0, 43),
(4, 4, 'term_language', '', 0, 1),
(5, 5, 'term_translations', 'a:2:{s:2:"fr";i:1;s:2:"en";i:8;}', 0, 2),
(6, 6, 'language', 'a:3:{s:6:"locale";s:5:"en_US";s:3:"rtl";i:0;s:9:"flag_code";s:2:"us";}', 0, 5),
(7, 7, 'term_language', '', 0, 1),
(8, 8, 'category', '', 0, 0),
(10, 10, 'post_translations', 'a:2:{s:2:"en";i:101;s:2:"fr";i:5;}', 0, 2),
(11, 11, 'post_translations', 'a:2:{s:2:"en";i:103;s:2:"fr";i:17;}', 0, 2),
(12, 12, 'post_translations', 'a:2:{s:2:"en";i:105;s:2:"fr";i:15;}', 0, 2),
(13, 13, 'nav_menu', '', 0, 6),
(14, 14, 'post_translations', 'a:2:{s:2:"en";i:186;s:2:"fr";i:21;}', 0, 2),
(15, 15, 'post_translations', 'a:2:{s:2:"en";i:188;s:2:"fr";i:19;}', 0, 2) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_termmeta`
#
INSERT INTO `wp_termmeta` ( `meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES
(1, 3, 'autodescription-term-settings', 'a:0:{}'),
(2, 2, 'autodescription-term-settings', 'a:0:{}'),
(3, 6, 'autodescription-term-settings', 'a:0:{}'),
(4, 5, 'autodescription-term-settings', 'a:0:{}') ;

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Non classé', 'non-classe', 0),
(2, 'navigation principale', 'navigation-principale', 0),
(3, 'Français', 'fr', 0),
(4, 'Français', 'pll_fr', 0),
(5, 'pll_57c55db5e40ed', 'pll_57c55db5e40ed', 0),
(6, 'English', 'en', 1),
(7, 'English', 'pll_en', 0),
(8, 'Non classé', 'non-classe-en', 0),
(10, 'pll_57d8712258de8', 'pll_57d8712258de8', 0),
(11, 'pll_57d871fc29604', 'pll_57d871fc29604', 0),
(12, 'pll_57d8720ea1c3c', 'pll_57d8720ea1c3c', 0),
(13, 'navigation US', 'navigation-us', 0),
(14, 'pll_57dc142c9f359', 'pll_57dc142c9f359', 0),
(15, 'pll_57dc144aca4ce', 'pll_57dc144aca4ce', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'wadmin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'false'),
(10, 1, 'wp_capabilities', 'a:13:{s:13:"administrator";b:1;s:26:"wpcf_custom_post_type_view";b:1;s:26:"wpcf_custom_post_type_edit";b:1;s:33:"wpcf_custom_post_type_edit_others";b:1;s:25:"wpcf_custom_taxonomy_view";b:1;s:25:"wpcf_custom_taxonomy_edit";b:1;s:32:"wpcf_custom_taxonomy_edit_others";b:1;s:22:"wpcf_custom_field_view";b:1;s:22:"wpcf_custom_field_edit";b:1;s:29:"wpcf_custom_field_edit_others";b:1;s:25:"wpcf_user_meta_field_view";b:1;s:25:"wpcf_user_meta_field_edit";b:1;s:32:"wpcf_user_meta_field_edit_others";b:1;}'),
(11, 1, 'wp_user_level', '10'),
(12, 1, 'dismissed_wp_pointers', 'pll_lgt'),
(13, 1, 'show_welcome_panel', '0'),
(14, 1, 'session_tokens', 'a:3:{s:64:"141bdbcb251fb8e5ec1c80cb087143931d57a8b901dc90515ed6b2ed8a9a7c64";a:4:{s:10:"expiration";i:1474627083;s:2:"ip";s:14:"92.139.193.163";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36";s:5:"login";i:1474454283;}s:64:"7dee72e60e3212734ea3b926552e0cb50fe6e5fbaa63c5cf2a246196e07d36c1";a:4:{s:10:"expiration";i:1474633215;s:2:"ip";s:14:"92.139.193.163";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36";s:5:"login";i:1474460415;}s:64:"21a0b4a4061a74011e81da6c7aeeba60b0ef1bb1ab75faf09934f8303176de4d";a:4:{s:10:"expiration";i:1475739568;s:2:"ip";s:14:"92.139.193.163";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36";s:5:"login";i:1474529968;}}'),
(15, 1, 'wp_dashboard_quick_press_last_post_id', '229'),
(16, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:15:"title-attribute";i:2;s:3:"xfn";i:3;s:11:"description";}'),
(17, 1, 'metaboxhidden_nav-menus', 'a:2:{i:0;s:12:"add-post_tag";i:1;s:15:"add-post_format";}'),
(18, 1, 'nav_menu_recently_edited', '13'),
(19, 1, 'closedpostboxes_page', 'a:2:{i:0;s:10:"wpseo_meta";i:1;s:10:"members-cp";}'),
(20, 1, 'metaboxhidden_page', 'a:11:{i:0;s:6:"acf_42";i:1;s:7:"acf_243";i:2;s:6:"acf_94";i:3;s:6:"acf_73";i:4;s:12:"postimagediv";i:5;s:6:"acf_96";i:6;s:10:"postcustom";i:7;s:16:"commentstatusdiv";i:8;s:11:"commentsdiv";i:9;s:7:"slugdiv";i:10;s:9:"authordiv";}'),
(21, 1, 'wp_user-settings', 'libraryContent=browse&editor=tinymce&hidetb=1'),
(22, 1, 'wp_user-settings-time', '1472554741'),
(23, 1, 'closedpostboxes_toolset_page_wpcf-edit-type', 'a:1:{i:0;s:12:"types_labels";}'),
(24, 1, 'metaboxhidden_toolset_page_wpcf-edit-type', 'a:1:{i:0;s:12:"field_groups";}'),
(25, 1, 'closedpostboxes_secteur', 'a:0:{}'),
(26, 1, 'metaboxhidden_secteur', 'a:2:{i:0;s:6:"acf_42";i:1;s:7:"slugdiv";}'),
(27, 1, '_types_feedback_dont_show_until', '1480337449'),
(28, 2, 'nickname', 'mk'),
(29, 2, 'first_name', 'Mickaël'),
(30, 2, 'last_name', 'Keromnes'),
(31, 2, 'description', ''),
(32, 2, 'rich_editing', 'true'),
(33, 2, 'comment_shortcuts', 'false'),
(34, 2, 'admin_color', 'fresh'),
(35, 2, 'use_ssl', '0'),
(36, 2, 'show_admin_bar_front', 'false'),
(37, 2, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(38, 2, 'wp_user_level', '10'),
(39, 2, 'dismissed_wp_pointers', ''),
(40, 2, 'user_lang', '0'),
(41, 2, 'description_fr', ''),
(42, 3, 'nickname', 'kgodin'),
(43, 3, 'first_name', 'Kim'),
(44, 3, 'last_name', 'Godin'),
(45, 3, 'description', ''),
(46, 3, 'rich_editing', 'true'),
(47, 3, 'comment_shortcuts', 'false'),
(48, 3, 'admin_color', 'fresh'),
(49, 3, 'use_ssl', '0'),
(50, 3, 'show_admin_bar_front', 'true'),
(51, 3, 'wp_capabilities', 'a:1:{s:6:"editor";b:1;}'),
(52, 3, 'wp_user_level', '7'),
(53, 3, 'dismissed_wp_pointers', 'pll_lgt'),
(54, 4, 'nickname', 'cherry'),
(55, 4, 'first_name', 'Charlotte'),
(56, 4, 'last_name', 'Henry'),
(57, 4, 'description', ''),
(58, 4, 'rich_editing', 'true'),
(59, 4, 'comment_shortcuts', 'false'),
(60, 4, 'admin_color', 'fresh'),
(61, 4, 'use_ssl', '0'),
(62, 4, 'show_admin_bar_front', 'true'),
(63, 4, 'wp_capabilities', 'a:1:{s:6:"editor";b:1;}'),
(64, 4, 'wp_user_level', '7'),
(65, 4, 'dismissed_wp_pointers', ''),
(66, 4, 'default_password_nag', ''),
(67, 4, 'session_tokens', 'a:2:{s:64:"9116ce11194503e0c451b3902540825f2c38746c6896f701b94f93c75b8e5ba7";a:4:{s:10:"expiration";i:1475141207;s:2:"ip";s:13:"46.218.194.82";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36";s:5:"login";i:1473931607;}s:64:"f75f86d88df5f3bc33bb32d8b7540aeb8f5f3cdf0d01696a2b59dcec7e5082ca";a:4:{s:10:"expiration";i:1474185830;s:2:"ip";s:13:"46.218.194.82";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36";s:5:"login";i:1474013030;}}'),
(68, 4, 'wp_dashboard_quick_press_last_post_id', '114'),
(69, 5, 'nickname', 'editeur'),
(70, 5, 'first_name', ''),
(71, 5, 'last_name', ''),
(72, 5, 'description', ''),
(73, 5, 'rich_editing', 'true'),
(74, 5, 'comment_shortcuts', 'false'),
(75, 5, 'admin_color', 'fresh'),
(76, 5, 'use_ssl', '0'),
(77, 5, 'show_admin_bar_front', 'true'),
(78, 5, 'wp_capabilities', 'a:1:{s:6:"editor";b:1;}'),
(79, 5, 'wp_user_level', '7'),
(80, 5, 'dismissed_wp_pointers', 'pll_lgt'),
(82, 5, 'wp_dashboard_quick_press_last_post_id', '115'),
(83, 3, 'default_password_nag', ''),
(84, 3, 'session_tokens', 'a:1:{s:64:"f779ad0059dcfc86393ccacdb8a741877a4f9ff83c9d2787498fcd297d96760b";a:4:{s:10:"expiration";i:1475141673;s:2:"ip";s:13:"46.218.194.82";s:2:"ua";s:120:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36";s:5:"login";i:1473932073;}}'),
(85, 3, 'wp_dashboard_quick_press_last_post_id', '116'),
(86, 3, 'closedpostboxes_page', 'a:0:{}'),
(87, 3, 'metaboxhidden_page', 'a:9:{i:0;s:6:"acf_42";i:1;s:6:"acf_94";i:2;s:6:"acf_73";i:3;s:6:"acf_96";i:4;s:10:"postcustom";i:5;s:16:"commentstatusdiv";i:6;s:11:"commentsdiv";i:7;s:7:"slugdiv";i:8;s:9:"authordiv";}'),
(88, 3, 'wp_user-settings', 'mfold=o&hidetb=1&editor_plain_text_paste_warning=1'),
(89, 3, 'wp_user-settings-time', '1474017535'),
(90, 3, 'user_lang', '0'),
(91, 3, 'description_fr', ''),
(93, 5, 'nav_menu_recently_edited', '2'),
(94, 5, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(95, 5, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:19:"pll_lang_switch_box";i:1;s:12:"add-post_tag";i:2;s:15:"add-post_format";}'),
(96, 5, 'session_tokens', 'a:1:{s:64:"73501c4ac7d87567e078ec313b21fff4aa144ae977e312fb0c9f4346143236e4";a:4:{s:10:"expiration";i:1474186574;s:2:"ip";s:13:"109.218.238.5";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36";s:5:"login";i:1474013774;}}'),
(97, 1, 'closedpostboxes_toplevel_page_theseoframework-settings', 'a:2:{i:0;s:31:"autodescription-schema-settings";i:1;s:34:"autodescription-webmaster-settings";}'),
(98, 1, 'metaboxhidden_toplevel_page_theseoframework-settings', 'a:0:{}'),
(99, 3, 'nav_menu_recently_edited', '2'),
(100, 3, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(101, 3, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:19:"pll_lang_switch_box";i:1;s:12:"add-post_tag";i:2;s:15:"add-post_format";}'),
(102, 1, 'wp_yoast_notifications', 'a:1:{i:0;a:2:{s:7:"message";s:203:"Ne ratez pas vos erreurs d’exploration : <a href="https://cedreo-designer.com.dev/wp/wp-admin/admin.php?page=wpseo_search_console&tab=settings">connectez-vous avec votre Google Search Console ici</a>.";s:7:"options";a:8:{s:4:"type";s:7:"warning";s:2:"id";s:17:"wpseo-dismiss-gsc";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:14:"manage_options";s:16:"capability_check";s:3:"all";}}}') ;
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(103, 1, 'wpseo_ignore_tour', '1'),
(105, 3, 'wp_yoast_notifications', 'a:1:{i:0;a:2:{s:7:"message";s:203:"Ne ratez pas vos erreurs d’exploration : <a href="https://cedreo-designer.com.dev/wp/wp-admin/admin.php?page=wpseo_search_console&tab=settings">connectez-vous avec votre Google Search Console ici</a>.";s:7:"options";a:8:{s:4:"type";s:7:"warning";s:2:"id";s:17:"wpseo-dismiss-gsc";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:14:"manage_options";s:16:"capability_check";s:3:"all";}}}'),
(106, 3, 'wpseo-dismiss-gsc', 'seen'),
(107, 1, 'wpseo-dismiss-gsc', 'seen') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'wadmin', '$2y$10$mKKoGovTgps1OTClMmYDMOsuv3U.utf27IFxWHqzNo9csKsw40P.6', 'wadmin', 'wab2com@gmail.com', '', '2016-08-22 20:08:37', '', 0, 'wadmin'),
(2, 'mk', '$2y$10$tOPDAsptasWlsFCXHb9K4eUrMxC9zW16TSDTxhn13oDa299uB5wpm', 'mk', 'mk@cedreo.com', 'http://www.cedreo-interactive.com', '2016-09-02 09:44:34', '1472809475:$P$Bd7UHVVzZXb7L6fuBuuqM7PN4gCxOO/', 0, 'Mickaël Keromnes'),
(3, 'kgodin', '$2y$10$vnhL0iDWimKGPfG0lm7NrusY18PqfSlv8GEszoi7QFB.RDPsHjy3.', 'kgodin', 'kgodin@cedreo.com', 'http://cedreo-interactive.com', '2016-09-15 09:10:25', '', 0, 'Kim Godin'),
(4, 'cherry', '$2y$10$Uk.GNV0SoMoYFiAkrMDtY.l1/zWSdyrzEQJKP2h.S78f8kymC9VAS', 'cherry', 'cherry@cedreo.com', 'http://cedreo-interactive.com', '2016-09-15 09:11:15', '', 0, 'Charlotte Henry'),
(5, 'editeur', '$2y$10$NSUKU/XcAuZm3F5veRqF7uV5QFhGqLChpOm25sU2ZX649mGjQaTEm', 'editeur', 'editeur@cedreo-designer.com', '', '2016-09-15 09:28:35', '', 0, 'editeur') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

